package main

import (
	"fmt"
	"test/swig"
)


func main() {
	fmt.Println("--------------------------------")
	fmt.Println("New and Use C++ Struct In Golang")
	//创建一个 DCTMcsInfo 结构体实例(非字节对齐)
	cgoDCTMCsInfo := kdvtest.NewDCTMcsInfo("path/to/log", uint8(8), uint(1<<20))
    defer kdvtest.DeleteDCTMcsInfo(cgoDCTMCsInfo)
	//打印结构体的字段值
	fmt.Println("LogPath:", cgoDCTMCsInfo.GetM_LogPath())
	fmt.Println("LogFileNum:", cgoDCTMCsInfo.GetM_byLogFileNum())
	fmt.Println("FileSize:", cgoDCTMCsInfo.GetM_dwFileSize())
	//使用结构体
	kdvtest.McsdllInit(cgoDCTMCsInfo, uint16(8888))


	//C结构体数组转换测试
	fmt.Println()
	fmt.Println("--------------------------------")
	fmt.Println("New and RW C++ Array In Golang")
	confTmpTable := kdvtest.NewDCTConfTable()
	defer kdvtest.DeleteDCTConfTable(confTmpTable)

	cgoArrayData:= kdvtest.New_DCTConfE164InfoArray(2)
	defer kdvtest.Delete_DCTConfE164InfoArray(cgoArrayData)

	confTmpTable.SetConfNum(2)
	confTmpTable.SetConfTable(cgoArrayData,2)

	confTmpData0 := kdvtest.DCTConfE164InfoArray_getitem(confTmpTable.GetConfTable(),0)
	confTmpData0.SetM_achConfName("name1")

	confTmpData1 := kdvtest.DCTConfE164InfoArray_getitem(confTmpTable.GetConfTable(),1)
	confTmpData1.SetM_achConfName("name2")

	fmt.Println("confTmpData0: ",confTmpData0.GetM_achConfName())
	fmt.Println("confTmpData1: ",confTmpData1.GetM_achConfName())


	//C++回调转换测试
	fmt.Println()
	fmt.Println("--------------------------------")
	fmt.Println("New and Use C++ CallBack In Golang")
	goCMcsCallback := kdvtest.NewGoMcsCallback()
	goCaller := kdvtest.NewCMcsCBCaller()
	goCaller.SetCallback(goCMcsCallback)
	defer kdvtest.DeleteGoMcsCallback(goCMcsCallback)
	defer kdvtest.DeleteCMcsCBCaller(goCaller)

	var idx int
	fmt.Printf("mcusdkCallBackFunc: %v %v\n", goCMcsCallback, &goCMcsCallback)
	kdvtest.ConnectMcsServerReq("a","b","c", goCMcsCallback, &idx)
	kdvtest.ConnectMcsServerReq("a","b","c", goCMcsCallback, &idx)
}
