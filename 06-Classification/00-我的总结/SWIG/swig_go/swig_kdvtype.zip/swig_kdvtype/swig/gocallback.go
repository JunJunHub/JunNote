package kdvtest

import "C"
import "fmt"

//GoMcsCallback 异步通知回调
type GoMcsCallback interface {
    CMcsCBHandler
    deleteCallback()
    IsGoCallback()
}

type goMcsCallback struct {
    CMcsCBHandler
}

func (p *goMcsCallback) deleteCallback() {
    DeleteDirectorCMcsCBHandler(p.CMcsCBHandler)
}

func (p *goMcsCallback) IsGoCallback() {}


type overwrittenMethodsOnCallback struct {
    p CMcsCBHandler
}

//CBHandle
//@事件ID
//@消息体  -- 指针
//@消息长度
func (p *overwrittenMethodsOnCallback) CBHandle(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) (_swig_ret uint16) {
    fmt.Println("Recv C++ CallBackMsg:", dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

    return
}


//NewGoMcsCallback 创建GOLANG实现的CallBack
func NewGoMcsCallback() GoMcsCallback {
    om := &overwrittenMethodsOnCallback{}
    p := NewDirectorCMcsCBHandler(om)
    om.p = p

    return &goMcsCallback{CMcsCBHandler: p}
}

//DeleteGoMcsCallback 销毁GOLANG实现的CallBack
func DeleteGoMcsCallback(p GoMcsCallback) {
    p.deleteCallback()
}


