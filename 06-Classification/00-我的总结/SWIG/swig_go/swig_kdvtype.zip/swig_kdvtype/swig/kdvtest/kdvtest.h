#ifndef _KDV_TEST_H_
#define _KDV_TEST_H_

#include "kdvtype.h"
#include <cstring>
#include <cstdio>

#ifdef WIN32
    #pragma comment( lib, "ws2_32.lib" )
    #pragma pack( push )
    #pragma pack( 1 )
    #define window( x )	x
    #define PACKED
    #pragma pack( pop )
#else
    #include <netinet/in.h>
    #define window( x )

    #if defined(__ETI_linux__)
        #define PACKED
    #else
        //TODO add by lyj
        //SWIG 不支持 __attribute__((__packed__)) 语法, 可以通过 #pragma pack(1) 设置1字节对齐, //恢复默认对齐 #pragma pack()
        #pragma pack(1)
	    #define PACKED
        //#define PACKED __attribute__((__packed__)) //取消编译器字节对齐优化
    #endif
#endif




//字节未对齐的数据结构
//cgo中使用这种数据结构要确保和编译C++动态库时采用相同的字节对齐方式
struct DCTMcsInfo {
	DCTMcsInfo(s8* szLogPath, u8 byFileNum=8, u32 dwFileSize=1<<20)
	{
		DCTMcsInfo();
        memcpy(m_LogPath, szLogPath, strlen(szLogPath) + 1 ) ;
		m_byLogFileNum = byFileNum;
		m_dwFileSize = dwFileSize;
	}
	DCTMcsInfo()
	{
        memset(this, 0, sizeof(DCTMcsInfo));
	}

    s8 m_LogPath[260];  //日志文件路径和名称
    u8 m_byLogFileNum;	//日志文件个数
	u32 m_dwFileSize;	//单个日志文件大小
};


//会议E164号和会议名称
struct DCTConfE164Info
{
	s8 m_achConfInfo[1024];
    // add by jianghuan [2013-11-14] 添加会议名称
    s8 m_achConfName[1024];    //会议名
public:
    DCTConfE164Info()
    {
        memset(m_achConfInfo, 0, sizeof(m_achConfInfo));
        memset(m_achConfName, 0, sizeof(m_achConfName));
    }
    void Print() const
    {
        printf("stuct: DCTConfE164Info\n");
        printf("E164:%s\n", m_achConfInfo);
        printf("ConfName:%s\n", m_achConfName);
    }
};

//会议列表---（平台状态上报）
struct DCTConfTable
{
public:
    s32  m_nConfNum;                          //会议个数
    DCTConfE164Info m_dctConfE164Info[1024];  //会议名称列表
    u32  m_dwReserve;                         //保留

public:
    DCTConfTable()
    {
        memset(this, 0, sizeof(DCTConfTable));
    }

    void SetConfTable(DCTConfE164Info *ptConfE164Info, u8 byMtNum)
    {
        if (NULL != ptConfE164Info)
        {
            byMtNum = (byMtNum<1024) ? byMtNum:1024;
            for (s32 nIndex = 0; nIndex < byMtNum; nIndex++)
            {
                memcpy(m_dctConfE164Info[nIndex].m_achConfInfo,
					   ptConfE164Info[nIndex].m_achConfInfo, sizeof(ptConfE164Info->m_achConfInfo));
                memcpy(m_dctConfE164Info[nIndex].m_achConfName,
					   ptConfE164Info[nIndex].m_achConfName, sizeof(ptConfE164Info->m_achConfName));
            }
        }
    }
    DCTConfE164Info* GetConfTable() {return m_dctConfE164Info;}

    void SetConfNum(s32 nConfNum) {m_nConfNum = nConfNum;}
    u32 GetConfNum() const {return m_nConfNum;}

    void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
    u32    GetReserve() const {return m_dwReserve;}

    void Print() const
    {
        printf("struct: DCTConfTable:\n");
        printf("ConfE164Info---");
        for (s32 nIndex = 0; nIndex < m_nConfNum; nIndex++)
        {
            m_dctConfE164Info[nIndex].Print();
        }
        printf("ConfNumL: %d\n", m_nConfNum);
    }
    void Clear()
    {
        memset(this, 0, sizeof(DCTConfTable));
    }
};

//C++回调类(纯虚函数)
class CMcsCBHandler
{
public:
    virtual ~CMcsCBHandler() {}

	/*=============================================================================
	函 数 名： CBHandle
    功    能：
    算法实现：
    全局变量：
    参    数： u32 dwEventId      消息号;
		       u32 dwMsgBody      消息体;
		       u32 dwMsgLength    消息体大小;
		       u32 nMcuIndex      MCU索引号;
	=============================================================================*/
	virtual u16 CBHandle(u32 dwEventId, uintptr_t dwMsgBody, u32 dwMsgLength, u32 nMcuIndex) = 0;
};

//SWIG转C++回调定义的Caller类
class CMcsCBCaller {
private:
	CMcsCBHandler *_callback;
public:
	CMcsCBCaller(): _callback(0) {}
	~CMcsCBCaller() { delCallback(); }
	void delCallback() { delete _callback; _callback = 0; }
	void setCallback(CMcsCBHandler *cb) { delCallback(); _callback = cb; }
	u16 call(u32 dwEventId, uintptr_t dwMsgBody, u32 dwMsgLength, u32 nMcuIndex) {
	    if (_callback) {
	        return _callback->CBHandle(dwEventId, dwMsgBody, dwMsgLength, nMcuIndex);
	    } else {
	        return 0;
	    }
	}
};

//C++ 宏
#define DC_MCS_MONITOR_BASE_PORT (u16)7200// 起始侦听端口

//C++ 常量
const u16 PORT_NMC = 60000;

//C++函数指针类型
typedef u16 (*PCBHandle)(u32 dwEventId, uintptr_t dwMsgBody, u32 dwMsgLength, u32 nMcuIndex);



//C++接口定义
u16 McsdllInit(const DCTMcsInfo& mcsInfo, u16 wMonitorBasePort = DC_MCS_MONITOR_BASE_PORT);
u16 ConnectMcsServerReq(const s8* pchServerIP, const s8* pchUserName, const s8* pchPwd,
									CMcsCBHandler *pCBHanlder, s32 &nIndex);


#endif//_KDV_TEST_H_
