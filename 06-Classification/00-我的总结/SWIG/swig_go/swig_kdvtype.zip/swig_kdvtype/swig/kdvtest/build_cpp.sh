g++ -c kdvtest.cpp
ar crs libkdvtest.a kdvtest.o
