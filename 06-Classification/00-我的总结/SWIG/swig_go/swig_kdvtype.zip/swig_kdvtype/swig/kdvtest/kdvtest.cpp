#include "kdvtest.h"


u16 McsdllInit(const DCTMcsInfo& mcsInfo, u16 wMonitorBasePort)
{
    printf("****sizeof(DCTMcsInfo)=%ld\n", sizeof(DCTMcsInfo));
    printf("****McsdllInit IN Param DCTMcsInfo={%s, %d, %d} wMonitorBasePort=%d, const PORT_NMC=%d\n",
            mcsInfo.m_LogPath, mcsInfo.m_byLogFileNum, mcsInfo.m_dwFileSize, wMonitorBasePort, PORT_NMC);
    return 0;
}
typedef signed int          s32;
u16 ConnectMcsServerReq(const s8* pchServerIP, const s8* pchUserName, const s8* pchPwd, CMcsCBHandler *pCBHandler, s32 &nIndex)
{
    printf("****pCBHandler IN: pCBHandler: %p\n", pCBHandler);
    if (pCBHandler != nullptr) {
        printf("****pCBHandler call\n");
        pCBHandler->CBHandle(1, 0, 1, 1);
    }
    pCBHandler->CBHandle(2, 0, 2, 2);
    printf("****pCBHandler OUT\n");

    //c 侧返回-1，测试转为 golang 侧int值为 65535
    nIndex = -1;
    return 0;
}