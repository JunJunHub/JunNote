#swig convert
swig -c++ -go -intgosize 64 -cgo kdvtest.i

#cgo LDFLAGS: -L./kdvtest/ -lkdvtest
#cgo CPPFLAGS: -Wno-unused-result -Wno-write-strings -Wno-attributes       #-Wno-attributes 字节对齐
sed -i '/#undef intgo/ a\#cgo LDFLAGS: -L./kdvtest/ -lkdvtest' kdvtest.go
sed -i '/#undef intgo/ a\#cgo CPPFLAGS: -Wno-attributes' kdvtest.go

#build test
go mod init hello
go build .
rm go.mod
