#ifndef _MCSSTRUCT_H_
#define _MCSSTRUCT_H_

#include "kdvtype.h"
#include "dcconst.h"
#include "mcsdllconst.h"

#ifdef _WIN32
extern "C" __declspec(dllexport) void Sdk_Printf(char* p, ...);
#else
extern "C" void Sdk_Printf(char* p, ...);
#endif

class CKdvDecoder;
//编码方式
enum EmEnCodingForm
{
	em_START = 0,
	em_Utf8		,
	em_GBK
};
#define MIN(a,b) ((a)<(b)?(a):(b))
// 版本信息控制，根据控制加载不同的mcs版本
struct DCTMcsInfo {
	DCTMcsInfo(s8* szLogPath, u8 byFileNum=8, u32 dwFileSize=1<<20)
	{
		DCTMcsInfo() ;
        memcpy(m_LogPath, szLogPath, strlen(szLogPath) + 1 ) ;
		m_byLogFileNum = byFileNum;
		m_dwFileSize = dwFileSize;
	}
	
	DCTMcsInfo()
	{
        memset(this, 0, sizeof(DCTMcsInfo));
	}
	
    s8 m_LogPath[260];     //add by jianghuan 2014-4-3 增加日志文件路径和名称
	u8 m_byLogFileNum;	//日志文件个数
	u32 m_dwFileSize;	//单个日志文件大小
}
PACKED;


//CPS外设
typedef enum
{
	emEQP_TYPE_MIXER    = 1,    //混音器
	emEQP_TYPE_VMP      = 2,    //图像合成器
	emEQP_TYPE_RECORDER = 3,    //录像机
	emEQP_TYPE_BAS      = 4,    //码流适配器
	emEQP_TYPE_TVWALL   = 5,    //电视墙
	emEQP_TYPE_DCS      = 6,    //数据服务器
	emEQP_TYPE_PRS      = 7,    //包重传
	emEQP_TYPE_FILEENC  = 8,    //文件编码器
	emEQP_TYPE_VMPTW    = 9,     //图像合成电视墙
	emEQP_TYPE_HDU      = 10,   //高清电视墙[11/11/2014 panyingnan]
	emEQP_TYPE_HDU2     = 15    //高清数字电视墙二代
}EmEqpType;


typedef enum
{
	emCONFCALLMODENONE  = 0, //手动呼叫
	emCONFCALLMODETIMER = 2  //定时呼叫
};

// 高清电视墙状态 [4/16/2014 panyingnan]
typedef enum 
{
	// 修改状态定义，迁移到8000A后，状态数值改变 [11/7/2014 panyingnan]
// 	eIDLE   = 0, //空闲
// 	eREADY  = 1, //准备
// 	eNORMAL = 2,  //运行,表示HDU设备在运行
// 	eRUNNING= 3,  //表示HDU的某个通道正在编码使用 [nizhijun 2010/10/27] add
// 	eWAITSTART = 4,
// 	eWAITSTOP  = 5
	eIDLE        = 0,   //空闲
	eREADY       = 2,   //准备(界面会判断状态大于1时显示HDU通道上线)
	eWAITSTART   = 3,	//等待开始
	eWAITSTOP    = 4,	//等待关闭
	eWAITCHGMODE = 5,	//等待风格切换
	eRUNNING     = 6    //表示HDU的某个通道正在编码使用

}EHduChnStatus;

// 录像机通道状态 [6/11/2014 panyingnan]
typedef enum 
{
	STATE_IDLE       = 0,	  /*表明是一个未用通道*/
		
		STATE_RECREADY   = 11,	  /*准备录像状态  */
		STATE_RECORDING  = 12,	  /*正在录像  */
		STATE_RECPAUSE   = 13,	  /*暂停录像状态*/
		
		STATE_PLAYREADY  = 21,	  /*准备播放状态 */
		STATE_PLAYREADYPLAY = 22,   /*作好播放准备状态*/
		STATE_PLAYING    = 23,	  /*正在或播放*/
		STATE_PLAYPAUSE  = 24,	  /*暂停播放*/
		STATE_FF         = 25,	  /*快进(仅播放通道有效)*/
		STATE_FB         = 26	  /*快退(仅播放通道有效)*/
}ERecChnnlState;

/*Rec通道类型定义*/
typedef enum 
{
	TYPE_UNUSE      =  0,	/*未始用的通道*/
		TYPE_RECORD     =  1,	/*录像通道  */   
		TYPE_PLAY       =  2	/*播放通道  */
}ERecChnnlType;

//录像设备类型
typedef enum 
{
	emRecPlayDev = 0,   //录放像机
	emVRS = 1		    //录播服务器
}ERecDvcType;

//录像方式
typedef enum 
{
	MODE_SKIPFRAME = 0,//抽帧录像
	MODE_REALTIME  = 1  //实时录像
}ERecMode;

//会议支持的媒体
struct DCTCapSupport
{
public:
	u8  m_byDStreamType;              //VIDEO_DSTREAM_H263PLUS(0),VIDEO_DSTREAM_MAIN(1),VIDEO_DSTREAM_H263PLUS_H239(2)
	                                  //VIDEO_DSTREAM_H263_H239(3),VIDEO_DSTREAM_H264_H239(4),VIDEO_DSTREAM_H264(5)
	u16	m_wDstreamCapMaxBitRate;      //双流能力,最高位标识HP/BP属性,为1标识HP,为0表示BP
	u8	m_byDstreamCapMediaType;      //双流能力,视频类型
	u8	m_byDstreamCapResolution;     //双流能力,分辨率 VIDEO_FORMAT_AUTO,...
	u8	m_byDstreamCapFrameRate;      //双流能力,帧率 MPI，对于H.264则是FPS
	u8	m_byDstreamCapIsH239Type;     //双流能力,是否支持H239
	u16	m_wMainVideoMaxBitRate;       //主视频同时能力,最高位标识HP/BP属性，为1标识HP，为0表示BP
	u8	m_byMainVideoMediaType;       //主视频同时能力,视频类型
	u8	m_byMainVideoResolution;      //主视频同时能力,分辨率 VIDEO_FORMAT_AUTO,...
	u8	m_byMainVideoFrameRate;       //主视频同时能力,帧率 MPI，对于H.264则是FPS
	u8  m_byMainAudioMediaType;       //主音频同时能力,音频类型
	u16	m_wSecondVideoMaxBitRate;     //辅视频同时能力,最高位标识HP/BP属性，为1标识HP，为0表示BP
	u8	m_bySecondVideoMediaType;     //辅视频同时能力,视频类型
	u8	m_bySecondVideoResolution;    //辅视频同时能力,分辨率 VIDEO_FORMAT_AUTO,...
	u8	m_bySecondVideoFrameRate;     //辅视频同时能力，帧率 MPI，对于H.264则是FPS
	u8  m_bySecondAudioMediaType;	  //辅音频同时能力，音频类型
	u32	m_dwReserve;                  //保留

public:
	DCTCapSupport() 
	{ 
		memset(this, 0, sizeof(DCTCapSupport));
		Clear();
	}

	void Clear()
	{
		//m_byDStreamType = DC_VIDEO_DSTREAM_MAIN;
		m_byDStreamType = DC_VIDEO_DSTREAM_H264_H239;
		m_byDstreamCapMediaType = DC_MEDIA_TYPE_NULL;
		m_byDstreamCapResolution = DC_VIDEO_FORMAT_NULL;
		m_byMainVideoMediaType = DC_MEDIA_TYPE_NULL;
		m_byMainVideoResolution = DC_VIDEO_FORMAT_NULL;
		m_byMainAudioMediaType = DC_MEDIA_TYPE_NULL;
		m_bySecondVideoMediaType = DC_MEDIA_TYPE_NULL;
		m_bySecondVideoResolution = DC_VIDEO_FORMAT_NULL;
		m_bySecondAudioMediaType = DC_MEDIA_TYPE_NULL;
		m_byDstreamCapIsH239Type = TRUE;
	}

	void    SetDStreamType(u8 byDStreamType); //仅会控使用    
    u8      GetDStreamType() const { return m_byDStreamType; } //仅会控使用

	void    SetDStreamMaxBitRate(u16 wMaxRate) 
	{ 
		u16 wTmpBitRate = ntohs(m_wDstreamCapMaxBitRate);
		wTmpBitRate = (wTmpBitRate & 0x8000) | (wMaxRate & 0x7FFF);
		m_wDstreamCapMaxBitRate = htons(wTmpBitRate);
	}
	u16     GetDStreamMaxBitRate() const 
	{ 
		u16 wTmpBitRate = ntohs(m_wDstreamCapMaxBitRate);
		wTmpBitRate = wTmpBitRate & 0x7FFF;
		return wTmpBitRate; 
	}

	void    SetDStreamMediaType(u8 byMediaType) {m_byDstreamCapMediaType = byMediaType;} //仅MCU内部使用
    u8      GetDStreamMediaType() const {return m_byDstreamCapMediaType;}

	void    SetDStreamResolution(u8 byRes) {m_byDstreamCapResolution = byRes;}
	u8      GetDStreamResolution() const {return m_byDstreamCapResolution;}

    void    SetDStreamFrameRate(u8 byFrameRate)  {m_byDstreamCapFrameRate = byFrameRate;}
    u8      GetDStreamFrameRate() const {return m_byDstreamCapFrameRate;}

	void    SetDStreamSupportH239(BOOL32 bSupport) { m_byDstreamCapIsH239Type = (bSupport ? 1:0); } //仅MCU内部使用
    BOOL32  IsDStreamSupportH239() const { return (0 != m_byDstreamCapIsH239Type); } //第二路视频是否支持H239

	void    SetMainVideoMaxBitRate(u16 wMaxRate) 
	{ 
		u16 wTmpBitRate = ntohs(m_wMainVideoMaxBitRate);
		wTmpBitRate = (wTmpBitRate & 0x8000) | (wMaxRate & 0x7FFF);
		m_wMainVideoMaxBitRate = htons(wTmpBitRate);
	}
	u16     GetMainVideoMaxBitRate() const 
	{ 
		u16 wTmpBitRate = ntohs(m_wMainVideoMaxBitRate);
		wTmpBitRate = wTmpBitRate & 0x7FFF;
		return wTmpBitRate; 
	}
	
	void    SetMainVideoMediaType(u8 byMediaType) {m_byMainVideoMediaType = byMediaType;} //仅MCU内部使用
	u8      GetMainVideoMediaType() const {return m_byMainVideoMediaType;}

	void    SetMainVideoResolution(u8 byRes) { m_byMainVideoResolution = byRes; }
    u8      GetMainVideoResolution(void) const { return m_byMainVideoResolution; }

    void    SetMainVideoFrameRate(u8 byFrameRate)  {m_byMainVideoFrameRate = byFrameRate;}
    u8      GetMainVideoFrameRate() const {return m_byMainVideoFrameRate;}

	void      SetMainAudioMediaType(u8 byAudioMediaType) {m_byMainAudioMediaType = byAudioMediaType;}
	u8      GetMainAudioMediaType() const {return m_byMainAudioMediaType;}

	void    SetSecondVideoMaxBitRate(u16 wMaxRate) 
	{ 
		u16 wTmpBitRate = ntohs(m_wSecondVideoMaxBitRate);
		wTmpBitRate = (wTmpBitRate & 0x8000) | (wMaxRate & 0x7FFF);
		m_wSecondVideoMaxBitRate = htons(wTmpBitRate);
	}
	u16     GetSecondVideoMaxBitRate() const 
	{ 
		u16 wTmpBitRate = ntohs(m_wSecondVideoMaxBitRate);
		wTmpBitRate = wTmpBitRate & 0x7FFF;
		return wTmpBitRate; 
	}
	
	void    SetSecondVideoMediaType(u8 byMediaType) {m_bySecondVideoMediaType = byMediaType;} //仅MCU内部使用
	u8      GetSecondVideoMediaType() const {return m_bySecondVideoMediaType;}
	
	void    SetSecondVideoResolution(u8 byRes) {m_bySecondVideoResolution = byRes;}
    u8      GetSecondVideoResolution() const {return m_bySecondVideoResolution;}
	
    void    SetSecondVideoFrameRate(u8 byFrameRate)  {m_bySecondVideoFrameRate = byFrameRate;}
    u8      GetSecondVideoFrameRate() const {return m_bySecondVideoFrameRate;}
	
	void      SetSecondAudioMediaType(u8 byAudioMediaType) {m_bySecondAudioMediaType = byAudioMediaType;}
	u8      GetSecondAudioMediaType() const {return m_bySecondAudioMediaType;} 

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}
	void Print() const
	{
		Sdk_Printf("struct: DCTCapSupport\n");
		Sdk_Printf("DStreamType: %u, DStreamCapMaxBitRate: %u, DStreamCapMediaType: %u\n",
			m_byDStreamType, GetDStreamMaxBitRate(), m_byDstreamCapMediaType);
		Sdk_Printf("DStreamResolution: %u, DStreamCapFrameRate: %u, DStreamIsH329Type: %u\n", 
			m_byDstreamCapResolution, m_byDstreamCapFrameRate, m_byDstreamCapIsH239Type);
		Sdk_Printf("MainVideoMaxBitRate: %u, MainVideoMediaType: %u, MainVideoResolution: %u\n",
			GetMainVideoMaxBitRate(), m_byMainVideoMediaType, m_byMainVideoResolution);
		Sdk_Printf("MainVideoFrameRate: %u, MainAudioMediaType: %u\n", m_byMainVideoFrameRate, m_byMainAudioMediaType);
		Sdk_Printf("SecondVideoMaxBitRate: %u, SecondVideoMediaType: %u, SecondVideoResolution: %u\n",
			GetSecondVideoMaxBitRate(), m_bySecondVideoMediaType, m_bySecondVideoResolution);
		Sdk_Printf("SecondVideoFrameRate; %u, SecondAudioMediaType: %u\n", 
			m_bySecondVideoFrameRate, m_bySecondAudioMediaType);
	}
}
PACKED;


//会议属性
struct DCTConfAttrb
{
public:
	u8   m_byEncryptMode;       //会议加密模式: 0-不加密, 1-des加密,2-aes加密
	u8   m_byOpenMode;          //会议开放方式: 0-不开放,拒绝列表以外的终端 1-根据密码加入 2-完全开放
	u8   m_byPrsMode;           //丢包重传方式: 0-不重传 1-重传
	u8   m_byDiscussConf;       //是否讨论会议: 0-不是讨论会议(演讲会议) 1-讨论会议 (这一字段仅用来控制会议开始后是否启动混音)
	u8   m_byAllInitDumb;       //终端入会后是否初始哑音 0-不哑音 1-哑音
	u8   m_byDualMode;          //会议的双流发起方式: 0-发言人 1-任意终端
	u8   m_byVideoMode;         //会议视频模式: 0-速度优先 1-画质优先   
	u8   m_byCascadeMode;       //会议级连方式: 0-不支持合并级联, 1-支持合并级联
	u8   m_bySpeakerSrc;		//发言人的源:   0-看自己 1-看主席 2-看上一次发言人 
	u32  m_dwReserve;           //保留
	
public:
	DCTConfAttrb()
	{
		memset(this, 0, sizeof(DCTConfAttrb));
		Clear();
	}
	
	void Clear()
	{
		m_byOpenMode = DC_CONF_OPENMODE_OPEN;
		m_byDualMode = DC_CONF_DUALMODE_EACHMTATWILL;
	}
	
	void   SetEncryptMode(u8 byEncryptMode){m_byEncryptMode = byEncryptMode;} 
    u8     GetEncryptMode() const {return m_byEncryptMode;}
	
	void   SetOpenMode(u8 byOpenMode){m_byOpenMode = byOpenMode;} 
    u8     GetOpenMode() const {return m_byOpenMode;}
	
	void   SetPrsMode(u8 byResendPack){m_byPrsMode = byResendPack;}
	u8   IsResendLosePack() const{return m_byPrsMode;}
	
	void   SetDiscussConf(u8 byDiscussConf){m_byDiscussConf = byDiscussConf;}
	u8   IsDiscussConf() const{return m_byDiscussConf;}
	
	void   SetAllInitDumb(u8 byAllInitDumb){m_byAllInitDumb = byAllInitDumb;} 
    u8   IsAllInitDumb() const {return m_byAllInitDumb;}
	
	void   SetDualMode(u8 byDualMode){m_byDualMode = byDualMode;}
	u8	   GetDualMode() const {return m_byDualMode;}
	
	void   SetQualityPri(u8 byQualityPri){m_byVideoMode = byQualityPri;} 
    u8   IsQualityPri() const {return m_byVideoMode;}

	void   SetSupportCascade(BOOL32 bCascadeMode){ m_byCascadeMode = (bCascadeMode==TRUE?1:0); }
	BOOL32   IsSupportCascade( void ) const { return (m_byCascadeMode != 0 );}

	void   SetSpeakerSrc( u8 bySpeakerSrc ){ m_bySpeakerSrc = bySpeakerSrc;} 
	u8     GetSpeakerSrc( void ) const { return m_bySpeakerSrc; }

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}

	void Print() const
	{
		Sdk_Printf("struct: DCTConfAttrb\n");
		Sdk_Printf("EncryptMode: %u, OpenMode: %u, PrsMode: %u, DiscussConf: %u\n", 
			m_byEncryptMode, m_byOpenMode, m_byPrsMode, m_byDiscussConf); 
		Sdk_Printf("AllInitDumb: %u, DualMode: %u, VideoMode: %u\n", 
			m_byAllInitDumb, m_byDualMode, m_byVideoMode);
		Sdk_Printf("bCascadeMode: %d\n", m_byCascadeMode);
		Sdk_Printf("m_bySpeakerSrc: %d\n", m_bySpeakerSrc);

	}
}
PACKED;

//会议扩展属性
struct DCTConfAttrbEx
{
public:
	u8   m_byAutoRec;				//是否会议开始自动录像：0-不支持，1-支持，默认取0
	u8   m_byPublishMode;			//发布模式，默认取0
	u8   m_byIsRecDStream;			//是否录双流，默认取0
	u8   m_byIsAutoVac;				//是否自动语音激励，默认取0
	u32	 m_dwSndSpyBandWidth;		//会议支持发送的总带宽
	u8	 m_byIsSupportMultiSpy;		//会议是否支持多回传(0:不支持1:支持)
	u8   m_byIsSupportUploadSrc;	//会议是否支持上传源(0:不支持,1:支持)
	u32	 m_dwReserve;				//保留
	
public:
	DCTConfAttrbEx()
    {
        memset(this, 0, sizeof(DCTConfAttrbEx));
		Clear();
    }
	void Clear()
	{
		m_byPublishMode = DC_PUBLISH_MODE_NONE;
	}
	
	void     SetAutoRec(BOOL32 bEnableAuto) {m_byAutoRec = bEnableAuto ?  1 : 0;}
    BOOL32   IsAutoRec() const {return (m_byAutoRec == 1);}
	
	void SetPublishMode(u8 byMode)  {m_byPublishMode = byMode;}
	u8 GetPublishMode() const{return m_byPublishMode;}
	
	void SetIsRecDStream(BOOL32 bRecDStream){m_byIsRecDStream = (bRecDStream ? 1:0);}
	BOOL32 IsRecDStream() const {return (m_byIsRecDStream != 0);}
	
	void SetIsAutoVac(BOOL32 bAutoVac){m_byIsAutoVac = (bAutoVac ? 1:0);}
	BOOL32 IsAutoVac() const {return (m_byIsAutoVac != 0);}

	void  SetSndSpyBandWidth( u32 dwSndSpyBandWidth ){ m_dwSndSpyBandWidth = htonl(dwSndSpyBandWidth); } 
	u32   GetSndSpyBandWidth() const { return ntohl(m_dwSndSpyBandWidth); }

	void  SetSupportMultiSpy( BOOL32 bIsSupport ){ m_byIsSupportMultiSpy = (bIsSupport ? 1 : 0); }
	BOOL32 IsSupportMultiSpy() const { return (1 == m_byIsSupportMultiSpy); }

	void  SetSupportUploadSrc( BOOL32 bIsSupport ){ m_byIsSupportUploadSrc = (bIsSupport ? 1 : 0); }
	BOOL32 IsSupportUploadSrc() const { return (1 == m_byIsSupportUploadSrc); }
	
	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}
	void Print() const
	{
		Sdk_Printf("struct: DCTConfAttrbEx:\n");
		Sdk_Printf("AutoRec: %u, PublishMode: %u, IsRecDStream: %u, IsAutoVac: %u\n",
			m_byAutoRec, m_byPublishMode, m_byIsRecDStream, m_byIsAutoVac);
		Sdk_Printf("dwSndSpyBandWidth: %u, IsSupportMultiSpy: %d, IsSupportUploadSrc: %d\n", 
			m_dwSndSpyBandWidth, m_byIsSupportMultiSpy, m_byIsSupportUploadSrc);
	}
}
PACKED;

//受邀终端信息
struct DCTCallMtInfo
{
	s8 m_achMtInfo[DC_MAXLEN_ALIAS];					    //终端E164号
	u16 m_wCallRate;										//终端的码率
public:
	DCTCallMtInfo()
	{
		memset(m_achMtInfo, 0, sizeof(m_achMtInfo));
		m_wCallRate = 0;
	}
	void Print() const
	{
		Sdk_Printf("struct: DCTCallMtInfo\n");
		Sdk_Printf("MtInfo: %s, CallBitrate: %u\n", m_achMtInfo, m_wCallRate);
	}
}
PACKED;

struct DCTMediaEncrypt
{
protected:
	u8  m_byEncryptMode;         //加密模式 : CONF_ENCRYPTMODE_NONE,CONF_ENCRYPTMODE_DES, CONF_ENCRYPT_AES
	s32 m_nKeyLen;               //加密key的长度
	u8  m_abyEncKey[MAXLEN_KEY]; //加密key
	u8  m_byReserve;             //保留
public:
	DCTMediaEncrypt()
	{
		Reset();
	}
	void Reset()
	{
		memset( &m_abyEncKey, 0, MAXLEN_KEY );
		m_byEncryptMode = CONF_ENCRYPTMODE_NONE;
		m_nKeyLen = 0;
	}

	void SetEncryptMode(u8 byEncMode)
	{
		m_byEncryptMode = byEncMode;
	}
	u8  GetEncryptMode()
	{
		return m_byEncryptMode;
	}
	void SetEncryptKey(u8 *pbyKey, s32 nLen)
	{
		m_nKeyLen = (nLen > MAXLEN_KEY ? MAXLEN_KEY : nLen);
		if(m_nKeyLen > 0)
			memcpy(m_abyEncKey, pbyKey, m_nKeyLen); 
		m_nKeyLen = htonl(m_nKeyLen);
	}

	void GetEncryptKey(u8 *pbyKey, s32* pnLen)
	{
		if(pnLen != NULL) *pnLen = ntohl(m_nKeyLen);
		if(pbyKey != NULL) memcpy(pbyKey, m_abyEncKey, ntohl(m_nKeyLen));
	}
}
PACKED;

//会议信息
struct DCTConfInfo
{
public:
	s8              m_achConfName[DC_MAXLEN_CONFNAME+1];    //会议名
	s8              m_achConfE164[DC_MAXLEN_ConfE164+1];    //会议的E164号码
    //modify by jianghuan 增加主席和发言人 2014-6-25
    s8              m_achChairE164[DC_MAXLEN_ConfE164+1];   //主席的E164号码
    s8              m_achSpeakerE164[DC_MAXLEN_ConfE164+1]; //发言人的E164号码
	u16             m_wBitRate;                             //会议码率(单位:Kbps,1K=1024)
	u16             m_wDuration;                            //持续时间(分钟)，0表示不自动停止
	u8              m_byDStreamScale;                       //双流百分比
	DCTCapSupport   m_dctCapSupport;                        //会议支持的媒体
	DCTConfAttrb    m_dctConfAttrb;                         //会议属性
	DCTConfAttrbEx  m_dctConfAttrbEx;                       //会议扩展属性
	u8              m_byTalkHoldTime;                       //最小发言持续时间(单位:秒)
	//modify by wq[2013-5-14]
	DCTCallMtInfo   m_dctMtInfo[DC_MAXNUM_CONF_MT];         //终端列表
	u8              m_byMtNum;                              //终端数量
	u8              m_byForce;                              //是否强拆 
	//modify end wq[2013-5-14]
	u16             m_wSecBitRate;							//双速会议的第2码率(单位:Kbps,为0表示是单速会议)
	DCTMediaEncrypt m_dctMediaKey;							//加密密钥
	u32	            m_dwReserve;                            //保留
public:
	DCTConfInfo()
    { 
        memset(this, 0, sizeof(DCTConfInfo)); 
        m_dctCapSupport.Clear(); 
        m_dctConfAttrbEx.Clear();
		m_dctConfAttrb.Clear();
		m_byTalkHoldTime = 5;
    }

	void   SetConfName(s8* pchConfName);
    const s8* GetConfName()  const {return m_achConfName;}

	void   SetConfE164(s8* pchConfE164);
    const s8* GetConfE164()  const {return m_achConfE164;}

	void   SetBitRate(u16 wBitRate){m_wBitRate = htons(wBitRate);} 
    u16    GetBitRate() const {return ntohs(m_wBitRate);}

	void   SetDuration(u16 wDuration){m_wDuration = htons(wDuration);} 
    u16    GetDuration() const {return ntohs(m_wDuration);}

	void   SetDStreamScale(u8 byDStreamScale) {m_byDStreamScale = byDStreamScale;}
	u8     GetDStreamScale() const 
    { 
        u8 byScale = m_byDStreamScale;
        if (byScale > DC_MAXNUM_DSTREAM_SCALE || byScale < DC_MINNUM_DSTREAM_SCALE)
        {
            byScale = DC_DEF_DSTREAM_SCALE;
        }       
        
        return byScale; 
    }

	void   SetCapSupport(DCTCapSupport tCapSupport){m_dctCapSupport = tCapSupport;} 
    DCTCapSupport GetCapSupport() const {return m_dctCapSupport;}
    
	void   SetConfAttrb(DCTConfAttrb tConfAttrb){m_dctConfAttrb = tConfAttrb;} 
    DCTConfAttrb  GetConfAttrb() const {return m_dctConfAttrb;}

	void         SetConfAttrbEx(DCTConfAttrbEx tAttrbEx) {m_dctConfAttrbEx = tAttrbEx;}
    DCTConfAttrbEx GetConfAttrbEx() const {return m_dctConfAttrbEx;}

	void   SetTalkHoldTime(u8  byTalkHoldTime){m_byTalkHoldTime = byTalkHoldTime;} 
    u8     GetTalkHoldTime() const {return m_byTalkHoldTime;}

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}

    void SetMtNum(u8 byMtNum){ m_byMtNum = byMtNum;}
    u8 GetMtNum()const {return m_byMtNum;}
    
    void SetIsForce(u8 byForce){m_byForce = byForce;}
	u8 GetIsForce()const {return m_byForce;}

	void   SetSecBitRate(u16 wSecBitRate){ m_wSecBitRate = htons(wSecBitRate);} 
	u16    GetSecBitRate( void ) const { return ntohs(m_wSecBitRate); }

	DCTMediaEncrypt GetMediaKey(void) const { return m_dctMediaKey; };
	void SetMediaKey(DCTMediaEncrypt tMediaEncrypt){ memcpy(&m_dctMediaKey, &tMediaEncrypt, sizeof(tMediaEncrypt));}

	void Print() const
	{
		Sdk_Printf("struct: DCTConfInfo\n");
		Sdk_Printf("ConfName: %s\n", m_achConfName);
		Sdk_Printf("ConfE164: %s\n", m_achConfE164);
		Sdk_Printf("BitRate: %u\n", GetBitRate());
		Sdk_Printf("SecBitRate: %u\n", GetSecBitRate());
		Sdk_Printf("Duration: %u\n", m_wDuration);
		Sdk_Printf("DStreamScale: %u\n", m_byDStreamScale);
		Sdk_Printf("CapSupport--- ");
		m_dctCapSupport.Print();
		Sdk_Printf("ConfAttrb--- ");
		m_dctConfAttrb.Print();
		Sdk_Printf("ConfAttrbEx--- ");
		m_dctConfAttrbEx.Print();
		Sdk_Printf("TalkHoldTime: %u\n", m_byTalkHoldTime);
		Sdk_Printf("MtInfo---\n");
		s32 nLoop = 0;
		if (m_byMtNum > 0)
		{
			while(nLoop < m_byMtNum)
			{
				m_dctMtInfo[nLoop].Print();
				nLoop++;
			}
		}
		Sdk_Printf("MtNum: %u\n", m_byMtNum);
		Sdk_Printf("Force: %u\n", m_byForce);
	}
}
PACKED;

/*====================================================================
函数名      ：SetConfName
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：s8* pchConfName, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
====================================================================*/
inline void DCTConfInfo::SetConfName(s8* pchConfName)
{
	if(pchConfName != NULL)
	{
		strncpy(m_achConfName, pchConfName, sizeof(m_achConfName));
		m_achConfName[sizeof( m_achConfName ) - 1] = '\0';
	}
	else
	{
		memset(m_achConfName, 0, sizeof(m_achConfName));
	}
}

/*====================================================================
函数名      ：SetConfE164
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：LPCSTR lpszConfE164, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
====================================================================*/
inline void DCTConfInfo::SetConfE164(s8* pchConfE164)
{
	memset(m_achConfE164, 0, sizeof( m_achConfE164 ));
	if(pchConfE164 != NULL)
	{
		strncpy(m_achConfE164, pchConfE164, sizeof(m_achConfE164));
		m_achConfE164[sizeof( m_achConfE164 ) - 1] = '\0';
	}
}
//录像机别名
struct DCTRecName
{
    s8 m_achRecName[DC_MAXLEN_EQP_ALIAS];
public:
	DCTRecName()
	{
		memset(m_achRecName, 0, sizeof(m_achRecName));
	}
	void Print()
	{
		Sdk_Printf("stuct: DCTRecName\n");
		Sdk_Printf("RecName: %s", m_achRecName);
	}
}
PACKED;

//终端别名
struct DCTMtInfo
{
	s8 m_achMtInfo[DC_MAXLEN_ALIAS];
	u8 m_bySubType;		//终端子类型：3.MT  4.上级MCU  5.下级mcu
	u16 m_wMcuIdx;		//终端所属Mcu的index值
	
public:
	DCTMtInfo()
	{
		memset(m_achMtInfo, 0, sizeof(m_achMtInfo));
		m_bySubType = DC_MT_TYPE_NONE;
		m_wMcuIdx = DC_INVALID_MCUIDX;
	}
	void Print()
	{
		Sdk_Printf("struct: DCTMtInfo\n");
		Sdk_Printf("MtAlias: %s\n", m_achMtInfo);
		Sdk_Printf("MtSubType: %d, McuIdx: %u\n", m_bySubType, m_wMcuIdx);
	}
}
PACKED;

struct DCTMtOnlineInfo
{
	DCTMtInfo m_tMtInfo;
	s8 m_achConfInfo[DC_MAXLEN_ConfE164 + 1];
	u8 m_byOnline;
	u8 m_byReason;

public:
	DCTMtOnlineInfo()
	{
		memset(m_achConfInfo, 0, sizeof(m_achConfInfo));
		m_byOnline = 0;
		m_byReason = DC_MTLEFT_REASON_NONE;
	}
}PACKED;

//add [2019.4.3 liudawei]
struct DCTMtApplyInfo
{
	DCTMtInfo m_tMtInfo;
	s8 m_achConfInfo[DC_MAXLEN_ConfE164 + 1];

public:
	DCTMtApplyInfo()
	{
		memset(m_achConfInfo, 0, sizeof(m_achConfInfo));
	}
}PACKED;

struct DCTMtBitrate:public DCTMtInfo
{
protected:
	u16     m_wSendBitRate;              //终端发送码率(单位:Kbps,1K=1024)
	u16     m_wRecvBitRate;              //终端接收码率(单位:Kbps,1K=1024)
	u16     m_wH239SendBitRate;          //终端第二路视频发送码率(单位:Kbps,1K=1024)
	u16     m_wH239RecvBitRate;          //终端第二路视频接收码率(单位:Kbps,1K=1024)

public:
	DCTMtBitrate() { memset(this, 0, sizeof(DCTMtBitrate)); }
	void   SetSendBitRate(u16  wSendBitRate){ m_wSendBitRate = htons(wSendBitRate);} 
	u16    GetSendBitRate( void ) const { return ntohs(m_wSendBitRate); }
	void   SetRecvBitRate(u16  wRecvBitRate){ m_wRecvBitRate = htons(wRecvBitRate);} 
	u16    GetRecvBitRate( void ) const { return ntohs(m_wRecvBitRate); }
	void   SetH239SendBitRate(u16  wH239SendBitRate){ m_wH239SendBitRate = htons(wH239SendBitRate);} 
	u16    GetH239SendBitRate( void ) const { return ntohs(m_wH239SendBitRate); }
	void   SetH239RecvBitRate(u16  wH239RecvBitRate){ m_wH239RecvBitRate = htons(wH239RecvBitRate);} 
	u16    GetH239RecvBitRate( void ) const { return ntohs(m_wH239RecvBitRate); }

	void Print()
	{
		Sdk_Printf("struct: DCTMtBitrate\n");
		Sdk_Printf("MtAlias: %s\n", m_achMtInfo);
		Sdk_Printf("MtSubType: %d, McuIdx: %u\n", m_bySubType, m_wMcuIdx);
		Sdk_Printf("SendBitRate: %hu\n", GetSendBitRate());
		Sdk_Printf("RecvBitRate: %hu\n", GetRecvBitRate());
		Sdk_Printf("H239SendBitRate: %hu\n", GetH239SendBitRate());
		Sdk_Printf("H239RecvBitRate: %hu\n", GetH239RecvBitRate());
	}
}PACKED;

struct DCTMtBitrateInfo
{
	s8 m_achConfE164[DC_MAXLEN_ConfE164 + 1];
	u32 m_dwMtNum;
	DCTMtBitrate* m_pMtBitrates;

public:
	DCTMtBitrateInfo() { memset(this, 0, sizeof(DCTMtBitrateInfo)); }
	void Print()
	{
		Sdk_Printf("struct: DCTMtBitrateInfo\n");
		Sdk_Printf("ConfE164: %s\n", m_achConfE164);
		Sdk_Printf("MtNum: %u\n", m_dwMtNum);
		for (u32 i=0; i<m_dwMtNum; i++) 
		{
			m_pMtBitrates[i].Print();
		}
	}
}PACKED;

struct DCTMtCallFailedReason
{
	DCTMtInfo m_tMtInfo;
	s8 m_achConfInfo[DC_MAXLEN_ConfE164 + 1];
	u8 m_byReason;

public:
	DCTMtCallFailedReason()
	{
		memset(m_achConfInfo, 0, sizeof(m_achConfInfo));
		m_byReason = DC_MTCALLFAILED_REASON_NONE;
	}
}PACKED;


struct DCTMtAudMuteNotify
{
	DCTMtInfo m_tMtInfo;
	s8 m_achConfInfo[DC_MAXLEN_ConfE164+1];
	u8 byEnable;		//1:静音/哑音 0：取消静音/哑音
	u8 byMuteType;		//1:静音  2：哑音 

public:
	DCTMtAudMuteNotify()
	{
		memset(&m_tMtInfo, 0, sizeof(DCTMtInfo));
		memset(m_achConfInfo, 0, sizeof(m_achConfInfo));
		byEnable = 0;
		byMuteType = 0;
	}

	void Print()
	{
		Sdk_Printf("stuct: DCTMtAudMuteNotify\n");
		m_tMtInfo.Print();
		Sdk_Printf("Confe164: %s, byEnable: %u, byMuteType = %d \n", m_achConfInfo, byEnable, byMuteType);
	}
}
PACKED;


//终端参数
struct DCTMtParam : public DCTMtInfo
{
	u8 m_byVideoType; //0表示主视频，1表示辅视频
	BOOL32 bUsed;
public:
	DCTMtParam()
	{
		m_byVideoType = emDCMainVideo;
		bUsed = FALSE;
	}
	void Print()
	{
		Sdk_Printf("stuct: DCTMtParam\n");
		Sdk_Printf("byVideoTye: %u, bUsed = %d \n", m_byVideoType, bUsed);
	}
}
PACKED;

//画面合成成员
struct DCTVmpMember
{
public:
	DCTMtInfo m_tMtInfo;
	u8 m_byMemberType; //画面合成成员类型：1--VMP_MEMBERTYPE_MCSSPEC, 2--VMP_MEMBERTYPE_SPEAKER...

public:
	DCTVmpMember()
	{
		memset(&m_tMtInfo, 0, sizeof(DCTMtInfo));
		m_byMemberType = VMP_MEMBERTYPE_NULL;
	}

	void Print()
	{
		Sdk_Printf("DCTVmpMember--------: \n");
		Sdk_Printf("member type: %d\n", m_byMemberType);
		Sdk_Printf("member info :");
		m_tMtInfo.Print();
	}

}
PACKED;

//画面合成参数
struct DCTVMPParam
{
public:
	u8 m_byVMPBrdst;                                  //合成图像是否向终端广播 0-否 1-是 
	u8 m_byVMPAuto;                                   //是否是自动画面合成 0-否 1-是
	u8 m_byVMPStyle;                                  //画面合成风格
	DCTVmpMember m_aMtParam[DC_MAXNUM_VMP_MEMBER];    //画面合成成员
	u32	m_dwReserve;                                  //保留

public:
	DCTVMPParam()
	{
		memset(this, 0, sizeof(DCTVMPParam));
	}

	void   SetVMPBrdst(u8 byVMPBrdst){m_byVMPBrdst = byVMPBrdst;} 
    u8   IsVMPBrdst() const {return m_byVMPBrdst;}

	void   SetVMPAuto(u8 byVMPAuto){m_byVMPAuto = byVMPAuto;} 
    u8   IsVMPAuto() const {return m_byVMPAuto;}

	void   SetVMPStyle(u8 byVMPStyle){m_byVMPStyle = byVMPStyle;} 
    u8     GetVMPStyle() const {return m_byVMPStyle;}

// 	void   SetVmpMember(DCTMtInfo* ptMtInfo, u8 byMtNum)
// 	{
// 		if (NULL != ptMtInfo)
// 		{
// 			memset(m_aMtInfo, 0, sizeof(m_aMtInfo));
// 			byMtNum = MIN(byMtNum, DC_MAXNUM_VMP_MEMBER);
// 		    memcpy(m_aMtInfo, ptMtInfo, byMtNum * sizeof(DCTMtInfo));
// 		}
// 	}
	//画面合成器可以选择视频类型(主流/辅流)
	void   SetVmpMember(DCTVmpMember* ptMtParam, u8 byMtNum)
	{
		if (NULL != ptMtParam)
		{
			memset(m_aMtParam, 0, sizeof(m_aMtParam));
			byMtNum = MIN(byMtNum, DC_MAXNUM_VMP_MEMBER);
			s32 nNum = 0;
			for (; nNum < byMtNum; nNum += 1)
			{
				memcpy(m_aMtParam[nNum].m_tMtInfo.m_achMtInfo, ptMtParam[nNum].m_tMtInfo.m_achMtInfo, sizeof(ptMtParam[nNum].m_tMtInfo.m_achMtInfo));
				m_aMtParam[nNum].m_tMtInfo.m_bySubType = ptMtParam[nNum].m_tMtInfo.m_bySubType;
				m_aMtParam[nNum].m_tMtInfo.m_wMcuIdx   = ptMtParam[nNum].m_tMtInfo.m_wMcuIdx;
				m_aMtParam[nNum].m_byMemberType = ptMtParam[nNum].m_byMemberType;
			}	
		}
	}
	DCTVmpMember* GetVmpMember() {return m_aMtParam;}

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}

	void Print()
	{
		Sdk_Printf("struct: DCTVMPParam\n");
		Sdk_Printf("VMPBrdst: %u, VMPAuto: %u, VMPStyle: %u\n", m_byVMPBrdst, m_byVMPAuto, m_byVMPStyle);
		Sdk_Printf("VmpMember---\n ");
		s32 nLoop = 0;
		while(nLoop < DC_MAXNUM_VMP_MEMBER)
		{
			if (0 != strlen(m_aMtParam[nLoop].m_tMtInfo.m_achMtInfo))
			{
				m_aMtParam[nLoop].Print();
			}
			nLoop++;
		}
	}
}
PACKED;

//会议基本状态
struct DCTConfGeneralStatus
{
public:
	u8 m_byTakeMode;               //会议举行方式: 0-预约 1-即时 2-会议模板 3-虚拟即时会议 4-虚拟会议模板
	u8 m_byRegToGK;                //会议注册GK情况: 0-会议未在GK上注册 1-会议在GK上成功注册
	u8 m_byLockMode;               //会议锁定方式: 0-不锁定,所有会控可见可操作 1-根据密码操作此会议 2-某个会议控制台锁定
	DCTMtInfo m_dctSpeakerMtInfo;  //发言终端
	s8 m_achConfE164[DC_MAXLEN_ConfE164+1];    //会议的E164号码
	u32	m_dwReserve;               //保留

public:
	DCTConfGeneralStatus()
	{
		memset(this, 0, sizeof(DCTConfGeneralStatus));
	}

	void   SetTakeMode(u8 byTakeMode){m_byTakeMode = byTakeMode | (m_byTakeMode & 0x80);} 
    u8     GetTakeMode() const {return (m_byTakeMode & 0x0F);}

	void   SetRegToGK(u8 byRegToGK){m_byRegToGK = byRegToGK;}
	u8   IsRegToGK() const {return m_byRegToGK;}

	void   SetLockMode(u8 byLockMode){m_byLockMode = byLockMode;} 
    u8     GetLockMode() const {return m_byLockMode;}

    void   SetSpeaker(DCTMtInfo dctSpeakerMtInfo) {m_dctSpeakerMtInfo = dctSpeakerMtInfo;}
	DCTMtInfo    GetSpeaker() const {return m_dctSpeakerMtInfo;}

	void   SetConfE164(const s8* pchConfE164);
    const s8* GetConfE164()  const {return m_achConfE164;}

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}

	void Print()
	{
		Sdk_Printf("struct: struct DCTConfGeneralStatus:\n");
		Sdk_Printf("TakeMode: %u\n", m_byTakeMode);
		Sdk_Printf("RegToGK: %u\n", m_byRegToGK);
		Sdk_Printf("LockMode: %u\n", m_byLockMode);
		if (0 != strlen(m_dctSpeakerMtInfo.m_achMtInfo))
		{
			Sdk_Printf("SpeakerInfo---");
			m_dctSpeakerMtInfo.Print();
		}
		Sdk_Printf("ConfE164: %s", m_achConfE164);
	}
}
PACKED;

//会议画面合成状态
struct DCTConfVmpStatus
{
public:
	u8  m_byVMPAuto;                             //是否是自动画面合成 0-否 1-是
	u8  m_byVMPBrdst;                            //合成图像是否向终端广播 0-否 1-是
	u8  m_byVMPStyle;                            //画面合成风格
	u8  m_byVMPSchemeId;                         //合成风格方案编号,最大支持5套方案,1-5
	u8  m_byVMPMode;                             //图像复合方式: 0-不图像复合 1-会控或主席控制图像复合 
	                                             //2-自动图像复合(动态分屏与设置成员)
	u8  m_byRimEnabled;                          //是否使用边框: 0-不使用(默认) 1-使用;
							                     //本字段目前只对方案0有效, 其他方案暂不涉及本字段的设置和判断
	DCTVmpMember m_aMtInfo[DC_MAXNUM_VMP_MEMBER];   //画面合成成员
	s8 m_achConfE164[DC_MAXLEN_ConfE164+1];      //会议的E164号码
	s8 m_achVmpAlias[DC_MAXLEN_EQP_ALIAS];		 //画面合成器别名
	u16 m_wEqpId;								 //外设id
	u32	m_dwReserve;                             //保留

public:
	DCTConfVmpStatus()
	{
		memset(this, 0, sizeof(DCTConfVmpStatus));
	}

	void   SetVMPAuto(u8 byVMPAuto){m_byVMPAuto = byVMPAuto;} 
    u8   IsVMPAuto() const {return m_byVMPAuto;}

	void   SetVMPBrdst(u8 byVMPBrdst){m_byVMPBrdst = byVMPBrdst;} 
    u8   IsVMPBrdst() const {return m_byVMPBrdst;}

	void   SetVMPStyle(u8 byVMPStyle){m_byVMPStyle = byVMPStyle;} 
    u8     GetVMPStyle() const {return m_byVMPStyle;}

	void   SetVMPSchemeId(u8 bySchemeId) {m_byVMPSchemeId = bySchemeId;}
    u8     GetVMPSchemeId() const {return m_byVMPSchemeId;}

    void   SetVMPMode(u8 byVMPMode){m_byVMPMode = byVMPMode;} 
    u8     GetVMPMode() const {return m_byVMPMode;}

	void   SetIsRimEnabled(u8 byEnabled){m_byRimEnabled = byEnabled;}
	u8 GetIsRimEnabled() const {return m_byRimEnabled;}

	void   SetVmpMember(DCTVmpMember* ptMtInfo, u8 byMtNum)
	{
		if (NULL != ptMtInfo)
		{
			memset(m_aMtInfo, 0, sizeof(m_aMtInfo));
			byMtNum = MIN(byMtNum, DC_MAXNUM_VMP_MEMBER);
			memcpy(m_aMtInfo, ptMtInfo, byMtNum * sizeof(DCTVmpMember));
		}
	}
	DCTVmpMember* GetVmpMember() {return m_aMtInfo;}

	void   SetConfE164(const s8* pchConfE164);
    const s8* GetConfE164()  const {return m_achConfE164;}

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}
       u8     GetMaxMemberNum( void ) const 
	{
		u8   byMaxMemNum = 1;

		switch( m_byVMPStyle ) 
		{
		case VMP_STYLE_ONE:
			byMaxMemNum = 1;
			break;
		case VMP_STYLE_VTWO:
		case VMP_STYLE_HTWO:
			byMaxMemNum = 2;
			break;
		case VMP_STYLE_THREE:
			byMaxMemNum = 3;
			break;
		case VMP_STYLE_FOUR:
			byMaxMemNum = 4;
			break;
		case VMP_STYLE_SIX:
        case VMP_STYLE_SIX_L2UP_S4DOWN:
		case VMP_STYLE_SIX_DIVIDE:
			byMaxMemNum = 6;
			break;
		case VMP_STYLE_EIGHT:
			byMaxMemNum = 8;
			break;
		case VMP_STYLE_NINE:
			byMaxMemNum = 9;
			break;
		case VMP_STYLE_TEN:
        case VMP_STYLE_TEN_H:
		case VMP_STYLE_TEN_M:
			byMaxMemNum = 10;
			break;
		case VMP_STYLE_THIRTEEN:
		case VMP_STYLE_THIRTEEN_M:
			byMaxMemNum = 13;
			break;
		case VMP_STYLE_SIXTEEN:
			byMaxMemNum = 16;
			break;
		case VMP_STYLE_SPECFOUR:
			byMaxMemNum = 4;
			break;
		case VMP_STYLE_SEVEN:
			byMaxMemNum = 7;
			break;
        case VMP_STYLE_FOURTEEN:
            byMaxMemNum = 14;
            break;
		case VMP_STYLE_FIFTEEN:
			byMaxMemNum = 15;
			break;
		case VMP_STYLE_TWENTY:
			byMaxMemNum = 20;
			break;
		case VMP_STYLE_TWENTYFIVE:
			byMaxMemNum = 25;
			break;
		default:
			byMaxMemNum = 1;
			break;
		}
		return byMaxMemNum;
	}

	void Print()
	{
		Sdk_Printf("Conf.%s    VmpStatus:\n", m_achConfE164);
		Sdk_Printf("VMPAlias	: %s\n", m_achVmpAlias);
		Sdk_Printf("VMPEqpId	: %d\n", m_wEqpId);
		Sdk_Printf("VMPMode		: %u\n", GetVMPMode());
		Sdk_Printf("VMPAuto     : %u\n", m_byVMPAuto);
		Sdk_Printf("VMPBrdst    : %u\n", m_byVMPBrdst);
		Sdk_Printf("VMPStyle    : %u\n", m_byVMPStyle);
		Sdk_Printf("VMPSchemeId : %u\n", m_byVMPSchemeId);
		Sdk_Printf("RimEnabled  : %u\n", m_byRimEnabled);
		s32 nLoop = 0;
		Sdk_Printf("VMPParamInfo-------------------------\n");
		while(nLoop < GetMaxMemberNum()/*DC_MAXNUM_VMP_MEMBER*/)
		{
			/*if (0 != strlen(m_aMtInfo[nLoop].m_achMtInfo))*/
			{
				Sdk_Printf("Vmp member %d:\n", nLoop);
				m_aMtInfo[nLoop].Print();
			}
			nLoop++;
		}
	}
}
PACKED;


struct DCTVmpStatusList
{
public:
	DCTVmpStatusList()
	{
		memset(this, 0, sizeof(DCTVmpStatusList));
	}

	void SetVmpNum(u32 dwVmpNum)
	{
		m_dwVmpNum = MIN(dwVmpNum, DC_MAX_VMP_NUM);
	}

	u32 GetVmpNum()
	{
		return m_dwVmpNum;
	}

	void SetVmpStatus(u32 dwVmpIdx, DCTConfVmpStatus tVmpStatus)
	{
		if ( dwVmpIdx < DC_MAX_VMP_NUM )
		{
			m_atVmpStatus[dwVmpIdx] = tVmpStatus;
		}
	}

	DCTConfVmpStatus *GetVmpStatus(u32 dwVmpIdx)
	{
		if ( dwVmpIdx < DC_MAX_VMP_NUM )
		{
			return &m_atVmpStatus[dwVmpIdx];
		}

		return NULL;
	}

	void Print()
	{
		Sdk_Printf("———————VmpStatusList<%d>———————\n", GetVmpNum());
		for (u32 nIdx = 0; nIdx < GetVmpNum(); nIdx++)
		{
			m_atVmpStatus[nIdx].Print();
		}
	}
private:
	u32 m_dwVmpNum;
	DCTConfVmpStatus m_atVmpStatus[DC_MAX_VMP_NUM];
}
PACKED;


//会议混音状态
struct DCTConfMixStatus
{
public:
	u8  m_byMixMode;                              //混音模式：mcuNoMix - 不混音,mcuWholeMix - 全体混音,mcuPartMix - 定制混音
	u8  m_byMtNum;                                //参加混音的成员数量(混音深度)-----智能混音时无效
	DCTMtInfo m_aMtInfo[DC_MAXNUM_MIXING_MEMBER]; //混音成员，mcs中最大混音深度10，mcs中最大混音深度64----智能混音时无效
	s8 m_achConfE164[DC_MAXLEN_ConfE164+1];       //会议的E164号码
	u32	m_dwReserve;                              //保留

public:
	DCTConfMixStatus()
	{
		memset(this, 0, sizeof(DCTConfMixStatus));
	}

	void   SetMixModeParam(u8 byMixMode) {m_byMixMode = byMixMode;}
	u8     GetMixModeParam() const {return m_byMixMode;}
	void SetMixMemberNum(u8 byMixNum) {m_byMtNum = byMixNum;}
	u8   GetMixMemberNum() const {return m_byMtNum;}

	void   SetMixMember(DCTMtInfo* ptMtInfo, u8 byMtNum)
	{
		if (NULL != ptMtInfo)
		{
			memset(m_aMtInfo, 0, sizeof(m_aMtInfo));
			byMtNum = MIN(byMtNum, DC_MAXNUM_MIXING_MEMBER);
			memcpy(m_aMtInfo, ptMtInfo, byMtNum * sizeof(DCTMtInfo));
		}
	}
	DCTMtInfo* GetMixMember() {return m_aMtInfo;}

	void   SetConfE164(const s8* pchConfE164);
    const s8* GetConfE164()  const {return m_achConfE164;}

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}
	void Print()
	{
		Sdk_Printf("Conf.%s MixStatus:\n", m_achConfE164);
		Sdk_Printf("MixMode: %u\n", m_byMixMode);
		Sdk_Printf("MtNum: %u\n", m_byMtNum);
		Sdk_Printf("Mixing MtInfo---\n");
		s32 nLoop = 0;
		if (m_byMtNum > 0)
		{
			while(nLoop < DC_MAXNUM_MIXING_MEMBER)
			{
				if (0 != strlen(m_aMtInfo[nLoop].m_achMtInfo))
				{
					m_aMtInfo[nLoop].Print();
				}
				nLoop++;
			}
		}
	}
}
PACKED;

//会议广播源状态
struct DCTConfBrdstStatus
{	
public:
	DCTConfBrdstStatus()
	{
		memset(this, 0, sizeof(DCTConfBrdstStatus));
	}
	
	void   SetConfE164(const s8* pchConfE164);
    const s8* GetConfE164()  const {return m_achConfE164;}

	void   SetMixMode(u8 byMixMode) {m_byMixMode = byMixMode;}
	u8     GetMixMode() const {return m_byMixMode;}

	void   SetVMPBrdst(u8 byVMPBrdst){m_byVMPBrdst = byVMPBrdst;} 
    u8	   IsVMPBrdst() const {return m_byVMPBrdst;}

	void   SetSpecMt(u8 bySpecMt){m_bySpecMt = bySpecMt;} 
    u8	   IsSpecMt() const {return m_bySpecMt;}
	
	void Print()
	{
		Sdk_Printf("Conf.%s BrdstStatus:\n", m_achConfE164);
		Sdk_Printf("VMPBrdst: %u\n", m_byVMPBrdst);
		Sdk_Printf("MixMode: %u\n", m_byMixMode);
		Sdk_Printf("SpecMt: %u\n", m_bySpecMt);
	}


private:
	s8  m_achConfE164[DC_MAXLEN_ConfE164+1];      //会议的E164号码
	u8  m_byVMPBrdst;                             //合成图像是否向终端广播 0-否 1-是
	u8  m_byMixMode;                              //混音模式：mcuNoMix - 0(不混音),mcuWholeMix - 1(全体混音),mcuPartMix - 2(定制混音)
	u8  m_bySpecMt;                               //发言人是否指定：m_bySpecMt - 0(未指定), m_bySpecMt - 1(指定)
}
PACKED;




//获取会议录像/放像进度信息
struct DCTConfRecProgStatus
{
public:
	u32  m_dwCurProg;     //当前进度
	u32  m_dwTotalTime;   //总长度，仅在放像时有效
	s8 m_achConfE164[DC_MAXLEN_ConfE164+1];       //会议的E164号码
	u32	 m_dwReserve;     //保留

public:
	DCTConfRecProgStatus()
	{
		memset(this, 0, sizeof(DCTConfRecProgStatus));
	}

	//设置当前进度位置（单位：秒）
	void SetCurProg(u32 dwCurProg)	{m_dwCurProg = htonl(dwCurProg);}
	//获取当前进度位置（单位：秒）
	u32  GetCurProg() const	{return ntohl(m_dwCurProg);}

	//设置总长度，仅对放像有效（单位：秒）
	void SetTotalTime(u32 dwTotalTime)	{m_dwTotalTime = htonl(dwTotalTime);}
	//获取总长度，仅对放像有效（单位：秒）
	u32  GetTotalTime() const {return ntohl(m_dwTotalTime);}

	void   SetConfE164(const s8* pchConfE164);
    const s8* GetConfE164()  const {return m_achConfE164;}

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}

	void Print()
	{
 		Sdk_Printf("struct: DCTConfRecProgStatus:\n");
		Sdk_Printf("CurProg: %u, TotalTime: %u, ConfE164: %s\n", m_dwCurProg, m_dwTotalTime, m_achConfE164);
	}
}
PACKED;

struct DCTRecProg
{
public:
	enum EM_REC_TYPE
	{
		TYPE_CONFREC, 
		TYPE_MTREC
	};
	u32 m_dwCurProg;
	s8 m_achConfE164[DC_MAXLEN_ConfE164 + 1];
	EM_REC_TYPE m_emRecType;
	DCTMtInfo m_tMtInfo;

public:
	DCTRecProg()
	{
		memset(this, 0, sizeof(DCTRecProg));
	}

	//设置当前进度位置（单位：秒）
	void SetCurProg(u32 dwCurProg)	{m_dwCurProg = htonl(dwCurProg);}
	//获取当前进度位置（单位：秒）
	u32  GetCurProg() const	{return ntohl(m_dwCurProg);}

	void SetConfE164(const s8* pchConfE164);
	const s8* GetConfE164() const {return m_achConfE164;}

	void Print()
	{
		Sdk_Printf("struct: DCTRecProg\n");
		Sdk_Printf("CurProg: %u, ConfE164: %s, RecType: %s\n", m_dwCurProg, m_achConfE164, 
			(m_emRecType == TYPE_CONFREC) ? "ConfRec" : "MtRec");
		m_tMtInfo.Print();
	}
}PACKED;

//时间结构重新定义
struct DCTkdvTime
{
public:
	u16 m_wYear;//年
	u8  m_byMonth;//月
	u8  m_byMDay;//日
	u8  m_byHour;//时
	u8  m_byMinute;//分
	u8  m_bySecond;//秒

	DCTkdvTime()
    {
        memset(this, 0, sizeof(DCTkdvTime));
    }

	void Print()
	{
		Sdk_Printf("struct: DCTkdvTime\n");
		Sdk_Printf("Year: %u, Month: %u, Day: %u, Hour: %u, Minute: %u, Second: %u\n", 
			m_wYear, m_byMonth, m_byMDay, m_byHour, m_byMinute, m_bySecond);
	}
}
PACKED;

#ifdef _AFXDLL
struct DCTDecoderObj
{
public:
    DCTDecoderObj()
    {
        memset(this, 0, sizeof(DCTDecoderObj));
    }
    void Print()
    {
        //Sdk_Printf("\tCKdvDecoder:   0x%x\n", m_pcDecoder);
        //Sdk_Printf("\tCCodecStatic:  0x%x\n", m_pcMonitorWnd);
        //Sdk_Printf("\tAudio?         %s\n",   m_bAudio ? "TRUE" : "FALSE");
      //  Sdk_Printf("\tMute?          %s\n",   m_bMute ? "TRUE" : "FALSE");
        //Sdk_Printf("\tReal?          %s\n",   m_bReal ? "TRUE" : "FALSE");


		Sdk_Printf("################################\n");
		//Sdk_Printf("\tm_achConfE164         %s\n", m_achConfE164);
//         Sdk_Printf("\tCConfId:       ");
//         m_cConfId.Print();
//         Sdk_Printf("\tTMt wMtId:     0x%x\n", CMtUtility::GetwID(m_tMt));        
		
    }

public:
	s8  m_achConfE164[DC_MAXLEN_ConfE164+1];        //会议的E164号码   
	DCTMtInfo		m_tMt;				//终端
	BOOL32			m_bAudio;			//是否支持音频
    BOOL32			m_bMute;			//监控静音
	BOOL32			m_bReal;			//TRUE-实时监控，FALSE-只收关键帧
	CKdvDecoder		*m_pcDecoder;		//解码器

	HWND			m_pcMonitorWnd;		//监视窗口句柄
}PACKED;

#endif

//会议列表中会议信息
struct DCTConfInfoInConfTable
{
public:
	u8  m_byTakeMode;                               //会议举行方式: 0-预约 1-即时 2-会议模板 3-虚拟即时会议 4-虚拟会议模板
	u8  m_byRegToGK;                                //会议注册GK情况: 0-会议未在GK上注册 1-会议在GK上成功注册
	u8  m_byLockMode;                               //会议锁定方式: 0-不锁定,所有会控可见可操作 1-根据密码操作此会议 2-某个会议控制台锁定
    u8  m_byRecordMode;                             //会议录像方式: (BIT:0-6)0-不录像 1-录像 2-录像暂停; BIT7 = 0 实时 1抽帧录像[6/3/2014 panyingnan]
	s8  m_achConfName[DC_MAXLEN_CONFNAME+1];        //会议名
	s8  m_achConfE164[DC_MAXLEN_ConfE164+1];        //会议的E164号码       
	u8/*s8*/  m_abyConfId[DC_MAXLEN_CONFID];        //会议ID,只能数字//修改类型为u8 [5/19/2014 panyingnan]    
	u8  m_byEncryptMode;                            //会议加密模式: 0-不加密, 1-des加密,2-aes加密
	DCTCapSupport m_dctCapSupport;                  //会议支持的媒体
	u16  m_wBitRate;                                //持续时间(分钟)，0表示不自动停止
	DCTkdvTime m_dctStartTime;                      //开始时间，控制台填0为立即开始
	u16  m_wDuration;                               //持续时间(分钟)，0表示不自动停止
	DCTMtInfo m_dctSpeakerMtInfo;                   //发言终端  
	DCTMtInfo m_dctChairMtInfo;                     //主席终端
	DCTMtInfo m_aMtInfo[DC_MAXNUM_CONF_MT];         //受邀终端列表    
	DCTMtInfo m_aJoinedMtInfo[DC_MAXNUM_CONF_MT];   //与会终端列表
	u16  m_wMtNum;                                  //受邀终端个数
	u8 	 m_byForceRcvSpeaker;						//强制收看发言: 0-不强制收看发言人 1-强制收看发言人
	u32	m_dwReserve;                                //保留

public:
	DCTConfInfoInConfTable()
	{
		memset(this, 0, sizeof(DCTConfInfoInConfTable));
	}

	void   SetTakeMode(u8 byTakeMode){m_byTakeMode = byTakeMode | (m_byTakeMode & 0x80);} 
    u8     GetTakeMode() const {return (m_byTakeMode & 0x0F);}

	void   SetRegToGK(u8 byRegToGK){m_byRegToGK = byRegToGK;}
	u8   IsRegToGK() const {return m_byRegToGK;}

	void   SetLockMode(u8 byLockMode){m_byLockMode = byLockMode;} 
    u8     GetLockMode() const {return m_byLockMode;}

	void   SetConfName(s8* pchConfName);
    const s8* GetConfName()  const {return m_achConfName;}

	void   SetConfE164(s8* pchConfE164);
    const s8* GetConfE164()  const {return m_achConfE164;}

	void   SetConfId(u8* pchConfId, u8 byLen);
    const  u8* GetConfId()  const {return m_abyConfId;}

	void   SetEncryptMode(u8 byEncryptMode){m_byEncryptMode = byEncryptMode;} 
    u8     GetEncryptMode() const {return m_byEncryptMode;}

	void   SetCapSupport(DCTCapSupport tCapSupport){m_dctCapSupport = tCapSupport;} 
    DCTCapSupport GetCapSupport() const {return m_dctCapSupport;}

	void   SetBitRate(u16 wBitRate){m_wBitRate = htons(wBitRate);} 
    u16    GetBitRate() const {return ntohs(m_wBitRate);}
	
	void   SetKdvStartTime(DCTkdvTime tStartTime){m_dctStartTime = tStartTime;}
	DCTkdvTime GetKdvStartTime() const {return(m_dctStartTime);}
    
	void   SetDuration(u16 wDuration){m_wDuration = htons(wDuration);} 
    u16    GetDuration() const {return ntohs(m_wDuration);}

	void   SetSpeaker(DCTMtInfo dctSpeakerMtInfo) {m_dctSpeakerMtInfo = dctSpeakerMtInfo;}
	DCTMtInfo    GetSpeaker() const {return m_dctSpeakerMtInfo;}

	void   SetChair(DCTMtInfo dctChairMtInfo) {m_dctChairMtInfo = dctChairMtInfo;}
	DCTMtInfo    GetChair() const {return m_dctChairMtInfo;}
	
	void   SetForceRcvSpeaker(u8   byForceRcvSpeaker){ m_byForceRcvSpeaker = byForceRcvSpeaker;} 
	BOOL32   IsForceRcvSpeaker( void ) const { return m_byForceRcvSpeaker == 0 ? FALSE : TRUE; }

	void   SetConfMember(DCTMtInfo* ptMtInfo, u8 byMtNum)
	{
		if (NULL != ptMtInfo)
		{
			memset(m_aMtInfo, 0, sizeof(m_aMtInfo));
			byMtNum = MIN(byMtNum, DC_MAXNUM_CONF_MT);
			memcpy(m_aMtInfo, ptMtInfo, byMtNum * sizeof(DCTMtInfo));
		}
	}
	DCTMtInfo* GetConfMember() {return m_aMtInfo;}
	
	void   SetJoinedMember(DCTMtInfo* ptMtInfo, u8 byMtNum)
	{
		if (NULL != ptMtInfo)
		{
			memset(m_aJoinedMtInfo, 0, sizeof(m_aJoinedMtInfo));
			byMtNum = MIN(byMtNum, DC_MAXNUM_CONF_MT);
			memcpy(m_aJoinedMtInfo, ptMtInfo, byMtNum * sizeof(DCTMtInfo));
		}
	}
	DCTMtInfo* GetJoinedMember() {return m_aJoinedMtInfo;}

	void SetMtNum(u16 wMtNum) {m_wMtNum = wMtNum;}
	u16 GetMtNum() const {return m_wMtNum;}

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}
	// add [6/3/2014 panyingnan]
	void   SetRecordMode(u8   byRecordMode)
	{   byRecordMode   &= 0x7f ;
	   m_byRecordMode &= 0x80 ;
	   m_byRecordMode |= byRecordMode;
	} 
	 u8     GetRecordMode( void ) const { return m_byRecordMode&0x7f; }
	   
	 //判断当前是否在抽帧录像，若是返回TRUE否则返回FALSE
	 BOOL32   IsRecSkipFrame() const{ return m_byRecordMode&0x80 ? TRUE:FALSE;}
	 //bSkipFrame = TRUE 设置当前为抽帧录像,否则实时录像
	 void   SetRecSkipFrame(BOOL32 bSkipFrame)
	 {
		if(bSkipFrame)
		   m_byRecordMode |=0x80;
		else 
		   m_byRecordMode &=0x7f;
	}
	//end add

	void Print()
	{
		Sdk_Printf("struct: DCTConfInfoInConfTable\n");
		Sdk_Printf("TakeMode: %u\n", m_byTakeMode);
		Sdk_Printf("IsForceRcvSpeaker: %d\n", m_byForceRcvSpeaker);
		Sdk_Printf("RegToGK: %u\n", m_byRegToGK);
		Sdk_Printf("LockMode: %u\n", m_byLockMode);
		Sdk_Printf("RecordMode: %u\n", GetRecordMode());
		Sdk_Printf("ConfName: %s\n", m_achConfName);
		Sdk_Printf("ConfE164: %s\n", m_achConfE164);
		Sdk_Printf("ConfId:");
		for(s32 nIdx = 0; nIdx <DC_MAXLEN_CONFID; nIdx++ )
		{
            Sdk_Printf("%d", m_abyConfId[nIdx]);
		}
		//Sdk_Printf("ConfId: %d\n", m_abyConfId);
		Sdk_Printf("EncryptMode: %u\n", m_byEncryptMode);
		Sdk_Printf("CapSupport---");
		m_dctCapSupport.Print();
		Sdk_Printf("BitRate: %u\n", GetBitRate()/*m_wBitRate*/);
		Sdk_Printf("StartTime---");
		m_dctStartTime.Print();
		if (0 != strlen(m_dctSpeakerMtInfo.m_achMtInfo))
		{
			Sdk_Printf("SpeakerMt---");
			m_dctSpeakerMtInfo.Print();
		}
		if (0 != strlen(m_dctChairMtInfo.m_achMtInfo))
		{
			Sdk_Printf("ChairMt---");
			m_dctChairMtInfo.Print();
		}
		s32 nLoop = 0;
		if (m_wMtNum > 0)
		{
			while(nLoop < DC_MAXNUM_CONF_MT)
			{
				if (0 != strlen(m_aMtInfo[nLoop].m_achMtInfo))
				{
					Sdk_Printf("MtInConf---");
					m_aMtInfo[nLoop].Print();
				}
				nLoop++;
			}
		}
		nLoop = 0;
		while(nLoop < DC_MAXNUM_CONF_MT)
		{
			if (0 != strlen(m_aJoinedMtInfo[nLoop].m_achMtInfo))
			{
				Sdk_Printf("MtJoinedConf---");
				m_aJoinedMtInfo[nLoop].Print();
			}
			nLoop++;
		}
		Sdk_Printf("MtNum(InConf): %u\n", m_wMtNum);
	}
}
PACKED;

struct DCTMtStatus
{
public:
    //modify by wq[2013-5-14]
    //BOOL32 m_bOnline;      //终端是否在线
    u8 m_byMtStatus;         //终端状态(0:不在线,1:在线)
    u8 m_byQuiet;         //是否静音       
    u8 m_byDumb;          //是否哑音
    u8 m_byCurVideo;         //当前视频源
	u8 m_byCurAudio;	     //当前音频源
    u8 m_byInputVolume;      //输入音量
    u8 m_byOutputVolume;     //输出音量
    //Add by wq[2013-5-14]
    u8  m_byHasMatrix;       //是否有矩阵
    u8  m_byIsEnableFECC;    //是否能遥控摄像头
    u8  m_byInMixing;        //是否正在参加混音
    u8  m_byInVmp;           //是否在画面合成 注：mcslib中无此字段
    u8  m_byInTvWall;        //终端是否正在电视墙中 // 此处表示高清电视墙HDU表示 [4/2/2014 panyingnan]
    u8  m_byVideoFreeze;     //是否冻结图像
    u8  m_byRec;             //是否在录像(主流和音频)
    u8  m_byRecSec;          //是否在录双流 Add by wq[2013-11-12] add dual record status
    u8  m_bySendAudio;       //是否正在传送音频
    u8  m_bySendVideo;       //是否正在传送视频
    u8  m_byReceiveVideo;    //是否正在接收视频
    u8  m_byReceiveAudio;    //是否正在接收音频
    u8  m_byRcvVideo2;       //是否在接收第二视频
    u8  m_bySndVideo2;       //是否在发送第二视频
    //Modify by jianghuan[2013-11-20] 增加主流和辅流选看通道
    DCTMtParam m_dctMainVideoMtInfo;   //选看的主视频终端
    DCTMtParam m_dctSecVideoMtInfo;    //选看的辅视频终端
    DCTMtInfo  m_dctAudMtInfo;         //选看的音频终端
    u8 m_byVmpMtInfo;                  //是否选看VMP 0没有选看 1主通道 2辅流选看
    u8 m_byMixerMtInfo;                //是否选听混音 0没有选听 1选听
                                       /*
                                       DCTMtInfo m_dctMainVideoMtInfo;   //选看的主视频终端
                                       DCTMtInfo m_dctSecVideoMtInfo;    //选看的辅视频终端
                                       DCTMtInfo m_dctAudMtInfo;         //选看的音频终端
    */
    DCTMtInfo m_dctMtInfo;            //该终端E164号
    s8  m_achConfE164[DC_MAXLEN_ConfE164+1];    //会议的E164号码
	
	u8		m_byCallMode;			//呼叫终端方式：0-手动呼叫 1-呼叫一次 2-定时呼叫
	u16     m_wSendBitRate;			//发送码率(单位:Kbps)
	u16     m_wRecvBitRate;			//接收码率(单位:Kbps)
	u16		m_wCallBitRate;			//呼叫码率(单位:Kbps)

	s8		m_achVideoSrc[DC_MAXLEN_ALIAS];		//当前接收的视频源
	s8		m_achAudioSrc[DC_MAXLEN_ALIAS];		//当前接收的音频源

    //End by wq[2013-5-14]
	u8      m_byMtBoardType;        //终端的板卡类型(DC_MT_BOARD_WIN, DC_MT_BOARD_8010 等)
    u32 m_dwReserve;         //保留

public:
	DCTMtStatus()
	{
		memset(this, 0, sizeof(DCTMtStatus));
	}

	//modify by wq[2013-5-14]
// 	void   SetOnline(BOOL32 bOnline){m_bOnline = bOnline;}
// 	BOOL32   IsOnline() const {return m_bOnline == 0 ? FALSE : TRUE;}
	void   SetMtStatus(u8 byMtStatus){m_byMtStatus = byMtStatus;}
	u8   GetMtStatus() const {return m_byMtStatus;}

	void   SetQuiet(u8 byQuiet){m_byQuiet = byQuiet;} 
    u8   IsDecoderMute() const {return m_byQuiet;}

	void   SetDumb(u8 byDumb){m_byDumb = byDumb;} 
    u8   IsDumb() const {return m_byDumb;}

	void   SetCurVideo(u8 byCurVideo){m_byCurVideo = byCurVideo;} 
    u8     GetCurVideo() const {return m_byCurVideo;}

	void   SetCurAudio(u8 byCurAudio){ m_byCurAudio = byCurAudio;} 
	u8     GetCurAudio( void ) const { return m_byCurAudio; } 

	void   SetSndVideo2(u8 bySend) {m_bySndVideo2 = bySend;}
	u8   IsSndVideo2() const {return m_bySndVideo2;}

	void   SetInputVolume(u8 byInputVolume){m_byInputVolume = byInputVolume;} 
    u8     GetInputVolume() const {return m_byInputVolume;}

	void   SetOutputVolume(u8 byOutputVolume){m_byOutputVolume = byOutputVolume;} 
    u8     GetOutputVolume() const {return m_byOutputVolume;}

	void   SetConfE164(const s8* pchConfE164);
    const s8* GetConfE164()  const {return m_achConfE164;}

	void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
	u32	   GetReserve() const {return m_dwReserve;}

	void Print( void ) const
	{
		Sdk_Printf("Mt E164: %s, subtype:%d, mcuidx:%u\n",
			m_dctMtInfo.m_achMtInfo, m_dctMtInfo.m_bySubType, m_dctMtInfo.m_wMcuIdx);
		Sdk_Printf("m_byMtStatus: %u\n", m_byMtStatus);
		Sdk_Printf("m_byQuiet: %u\n", m_byQuiet);
		Sdk_Printf("m_byDumb: %u\n", m_byDumb);
		Sdk_Printf("m_byCurVideo: %u\n", m_byCurVideo);
		Sdk_Printf("m_byCurAudio: %u\n", m_byCurAudio);
		Sdk_Printf("m_byInputVolume: %u\n", m_byInputVolume);
		Sdk_Printf("m_byOutputVolume: %u\n", m_byOutputVolume);
		Sdk_Printf("m_byHasMatrix: %u\n", m_byHasMatrix);
		Sdk_Printf("m_byIsEnableFECC: %u\n", m_byIsEnableFECC);
		Sdk_Printf("m_byInMixing: %u\n", m_byInMixing);
		Sdk_Printf("m_byInVmp: %u\n", m_byInVmp);
		Sdk_Printf("m_byInTvWall: %u\n", m_byInTvWall);
		Sdk_Printf("m_byVideoFreeze: %u\n", m_byVideoFreeze);
		Sdk_Printf("m_byRec: %u\n", m_byRec);
		Sdk_Printf("m_bySendAudio: %u\n", m_bySendAudio);
		Sdk_Printf("m_bySendVideo: %u\n", m_bySendVideo);
		Sdk_Printf("m_byReceiveVideo: %u\n", m_byReceiveVideo);
		Sdk_Printf("m_byReceiveAudio: %u\n", m_byReceiveAudio);
		Sdk_Printf("m_byRcvVideo2: %u\n", m_byRcvVideo2);
		Sdk_Printf("m_bySndVideo2: %u\n", m_bySndVideo2);
		Sdk_Printf("Seeing mt of main video is %s\n", m_dctMainVideoMtInfo.m_achMtInfo);
		Sdk_Printf("Seeing mt of second video is %s\n", m_dctSecVideoMtInfo.m_achMtInfo);
		Sdk_Printf("Lestening mt is %s\n", m_dctAudMtInfo.m_achMtInfo);

		Sdk_Printf("CallMode: %d\n", m_byCallMode);
		Sdk_Printf("CallBitRate: %u\n", m_wCallBitRate);
		Sdk_Printf("RecvBitRate: %u\n", m_wRecvBitRate);
		Sdk_Printf("SendBitRate: %u\n", m_wSendBitRate);
		Sdk_Printf("VideoSrc: %s\n", m_achVideoSrc);
		Sdk_Printf("AudioSrc: %s\n", m_achAudioSrc);
		Sdk_Printf("byVmpMtInfo: %d\n", m_byVmpMtInfo);
		Sdk_Printf("byMixerMtInfo: %d\n", m_byMixerMtInfo);
		Sdk_Printf("Conf E164: %s\n", m_achConfE164);
		Sdk_Printf("m_byMtBoardType: %hhu\n", m_byMtBoardType);
	}	
}
PACKED;

struct DCTConfMode
{
protected:
	u8     m_byAudioMixMode;    //混音方式:     0-不混音 1-正在进行某种混音(广播)[远程医疗]2---混音(不广播)add by pyn[2013.05.07]
	
public:
	DCTConfMode()
	{
		memset(this, 0, sizeof(DCTConfMode));
	}
	void   SetAudioMixMode(BOOL32 bAudioMixMode){ m_byAudioMixMode = bAudioMixMode;} 
    BOOL32   IsAudioMixMode() const { return m_byAudioMixMode == 0 ? FALSE : TRUE; }
}
PACKED;


/*=============================================================================
函 数 名： SetDStreamType
功    能： 设置双流参数
算法实现： 
全局变量： 
参    数： u8 byDStreamType 双流类型
返 回 值： 
----------------------------------------------------------------------
修改记录：
日  期      版本        修改人        走读人         修改内容
2013/4/18   1.0         王强                         创建 
=============================================================================*/
inline void DCTCapSupport::SetDStreamType( u8 byDStreamType ) 
{
    m_byDStreamType = byDStreamType;
    
    switch(byDStreamType)
    {
    case DC_VIDEO_DSTREAM_MAIN:
        m_byDstreamCapMediaType = m_byMainVideoMediaType;
        m_byDstreamCapIsH239Type = FALSE;
        break;
    case DC_VIDEO_DSTREAM_H263PLUS:
        m_byDstreamCapMediaType = MEDIA_TYPE_H263PLUS;
        m_byDstreamCapIsH239Type = FALSE;
        break;
    case DC_VIDEO_DSTREAM_H263PLUS_H239:
        m_byDstreamCapMediaType = MEDIA_TYPE_H263PLUS;
        m_byDstreamCapIsH239Type = TRUE;
        break;
    case DC_VIDEO_DSTREAM_H263_H239:
        m_byDstreamCapMediaType = MEDIA_TYPE_H263;
        m_byDstreamCapIsH239Type = TRUE;
        break;
    case DC_VIDEO_DSTREAM_H264_H239:
        m_byDstreamCapMediaType = MEDIA_TYPE_H264;
        m_byDstreamCapIsH239Type = TRUE;
        break;
    case DC_VIDEO_DSTREAM_H264:
        m_byDstreamCapMediaType = MEDIA_TYPE_H264;
        m_byDstreamCapIsH239Type = FALSE;
        break;
    default:
        break;
    }
}


/*====================================================================
函数名      ：SetConfName
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：s8* pchConfName, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
====================================================================*/
inline void DCTConfInfoInConfTable::SetConfName(s8* pchConfName)
{
	if(pchConfName != NULL)
	{
		strncpy(m_achConfName, pchConfName, sizeof(m_achConfName));
		m_achConfName[sizeof( m_achConfName ) - 1] = '\0';
	}
	else
	{
		memset(m_achConfName, 0, sizeof(m_achConfName));
	}
}

/*====================================================================
函数名      ：SetConfE164
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：LPCSTR lpszConfE164, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
====================================================================*/
inline void DCTConfInfoInConfTable::SetConfE164(s8* pchConfE164)
{
	memset(m_achConfE164, 0, sizeof( m_achConfE164 ));
	if(pchConfE164 != NULL)
	{
		strncpy(m_achConfE164, pchConfE164, sizeof(m_achConfE164));
		m_achConfE164[sizeof( m_achConfE164 ) - 1] = '\0';
	}
}

/*====================================================================
函数名      ：SetConfE164
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：LPCSTR lpszConfE164, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2024/05/08   1.0       李永军                     创建
====================================================================*/
inline void DCTConfBrdstStatus::SetConfE164(const s8* pchConfE164)
{
	memset(m_achConfE164, 0, sizeof( m_achConfE164 ));
	if(pchConfE164 != NULL)
	{
		strncpy(m_achConfE164, pchConfE164, sizeof(m_achConfE164));
		m_achConfE164[sizeof( m_achConfE164 ) - 1] = '\0';
	}
}

/*====================================================================
函数名      ：SetConfId
功能        ：设置会议ID
算法实现    ：
引用全局变量：
输入参数说明：s8* pchConfId 会议ID
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
2014/05/15  1.0         潘迎男                   修改会议ID的类型
====================================================================*/
inline void DCTConfInfoInConfTable::SetConfId(u8* pbyConfId, u8 byLen)
{
// 	if(pchConfId != NULL)
// 	{
// 		strncpy(m_abyConfId, pchConfId, sizeof(m_abyConfId));
// 		m_abyConfId[sizeof(m_abyConfId) - 1] = '\0';
// 	}
// 	else
// 	{
// 		memset(m_abyConfId, 0, sizeof(m_abyConfId));
// 	}

	byLen = MIN(sizeof(m_abyConfId), byLen);
	memset(m_abyConfId, 0, sizeof(m_abyConfId));
	memcpy( m_abyConfId, pbyConfId, byLen );

	/*return byLen;*/
}

/*====================================================================
函数名      ：SetConfE164
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：LPCSTR lpszConfE164, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
====================================================================*/
inline void DCTConfGeneralStatus::SetConfE164(const s8* pchConfE164)
{
	memset(m_achConfE164, 0, sizeof( m_achConfE164 ));
	if(pchConfE164 != NULL)
	{
		strncpy(m_achConfE164, pchConfE164, sizeof(m_achConfE164));
		m_achConfE164[sizeof( m_achConfE164 ) - 1] = '\0';
	}
}

/*====================================================================
函数名      ：SetConfE164
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：LPCSTR lpszConfE164, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
====================================================================*/
inline void DCTConfVmpStatus::SetConfE164(const s8* pchConfE164)
{
	memset(m_achConfE164, 0, sizeof( m_achConfE164 ));
	if(pchConfE164 != NULL)
	{
		strncpy(m_achConfE164, pchConfE164, sizeof(m_achConfE164));
		m_achConfE164[sizeof( m_achConfE164 ) - 1] = '\0';
	}
}

/*====================================================================
函数名      ：SetConfE164
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：LPCSTR lpszConfE164, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
====================================================================*/
inline void DCTConfMixStatus::SetConfE164(const s8* pchConfE164)
{
	memset(m_achConfE164, 0, sizeof( m_achConfE164 ));
	if(pchConfE164 != NULL)
	{
		strncpy(m_achConfE164, pchConfE164, sizeof(m_achConfE164));
		m_achConfE164[sizeof( m_achConfE164 ) - 1] = '\0';
	}
}

/*====================================================================
函数名      ：SetConfE164
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：LPCSTR lpszConfE164, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
====================================================================*/
inline void DCTConfRecProgStatus::SetConfE164(const s8* pchConfE164)
{
	memset(m_achConfE164, 0, sizeof( m_achConfE164 ));
	if(pchConfE164 != NULL)
	{
		strncpy(m_achConfE164, pchConfE164, sizeof(m_achConfE164));
		m_achConfE164[sizeof( m_achConfE164 ) - 1] = '\0';
	}
}

/*====================================================================
函数名      ：SetConfE164
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：LPCSTR lpszConfE164, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2019/4/11   1.0         liudawei                 创建
====================================================================*/
inline void DCTRecProg::SetConfE164(const s8* pchConfE164)
{
	memset(m_achConfE164, 0, sizeof( m_achConfE164 ));
	if(pchConfE164 != NULL)
	{
		strncpy(m_achConfE164, pchConfE164, sizeof(m_achConfE164));
		m_achConfE164[sizeof( m_achConfE164 ) - 1] = '\0';
	}
}

/*====================================================================
函数名      ：SetConfE164
功能        ：设置别名
算法实现    ：
引用全局变量：
输入参数说明：LPCSTR lpszConfE164, 别名
返回值说明  ：字符串指针
----------------------------------------------------------------------
修改记录    ：
日  期      版本        修改人       走读人      修改内容
2013/4/18   1.0         王强                     创建
====================================================================*/
inline void DCTMtStatus::SetConfE164(const s8* pchConfE164)
{
	memset(m_achConfE164, 0, sizeof( m_achConfE164 ));
	if(pchConfE164 != NULL)
	{
		strncpy(m_achConfE164, pchConfE164, sizeof(m_achConfE164));
		m_achConfE164[sizeof( m_achConfE164 ) - 1] = '\0';
	}
}

// 双流结构体（目前未使用） [5/17/2013 yinyujie]
struct DCTSendDualStreamReq
{
    s8 m_pchConfE164ID[MAXLEN_E164 + 1];
    DCTMtInfo m_dctMtInfo;
    BOOL32 m_bSend;
    void print()
    {
        Sdk_Printf("struct: DCTSendDualStreamReq:\n");
        Sdk_Printf("ConfE164ID:%s\n", m_pchConfE164ID);
        m_dctMtInfo.Print();
        Sdk_Printf("m_bSend:%d\n", m_bSend);
    }
}
PACKED;

// struct DCTRecStatus 
// {
// public:
//     BOOL32 m_bOnline;
//     s8     m_achAlias[DC_MAXLEN_EQP_ALIAS];
// 	
// public:
//     DCTRecStatus()
//     {
//         memset(this, 0, sizeof(DCTRecStatus));
//     }
// 	
// 	void print(void) const
//     {
//         Sdk_Printf("m_bOnline: %u\n", m_bOnline);
// 		Sdk_Printf("m_achAlias: %s\n", m_achAlias);
//     }
// }
// PACKED;

//终端参数
struct DCTMtParambyMcs
{
	s8 m_achMtInfo[DC_MAXLEN_ALIAS];
	u8 m_byVideoType; //0表示主视频，1表示辅视频
public:
	DCTMtParambyMcs()
	{
		memset(m_achMtInfo, 0, sizeof(m_achMtInfo));
		m_byVideoType = emDCMainVideo;
	}
	void Print()
	{
		Sdk_Printf("stuct: DCTMtParambyMcs\n");
		Sdk_Printf("MtInfo: %s, byVideoTye: %u\n", m_achMtInfo, m_byVideoType);
	}
}
PACKED;

//画面合成成员上报
struct DCTVmpMemberNfy
{
public:
	DCTMtParambyMcs dctMtParam[DC_MAXNUM_VMP_MEMBER];
	s8 m_achConfE164[MAXLEN_E164+1];
public:
	DCTVmpMemberNfy()
	{
		memset(m_achConfE164, 0, sizeof(m_achConfE164));
	}
	void print(void) const
	{
		Sdk_Printf("m_achConfE164 = %s\n", m_achConfE164);
	}
};

//终端别名
struct DCTMtInfobyXml
{
	s8 m_achMtInfo[DC_MAXLEN_ALIAS];
public:
	DCTMtInfobyXml()
	{
		memset(m_achMtInfo, 0, sizeof(m_achMtInfo));
	}
	void Print()
	{
		Sdk_Printf("stuct: DCTMtInfo\n");
		Sdk_Printf("MtInfo: %s", m_achMtInfo);
	}
}
PACKED;

//终端参数
struct DCTMtParambyXml
{
	s8 m_achMtInfo[DC_MAXLEN_ALIAS];
	u8 m_byVideoType; //0表示主视频，1表示辅视频
public:
	DCTMtParambyXml()
	{
		memset(m_achMtInfo, 0, sizeof(m_achMtInfo));
		m_byVideoType = emDCMainVideo;
	}
	void Print()
	{
		Sdk_Printf("stuct: DCTMtParambyXml\n");
		Sdk_Printf("MtInfo: %s, byVideoTye: %u\n", m_achMtInfo, m_byVideoType);
	}
}
PACKED;
//终端状态上报
struct DCTMTStatusCfgNfy
{
public:
    s8 m_achMTE164[MAXLEN_E164+1];
    s8 m_achConfE164[MAXLEN_E164+1];

    u8 m_byMainVidIsSend;                       //主流是否发送
    u8 m_byMainVidIsRecv;                       //主流是否接收
    u8 m_bySecVidIsSend;                        //辅流是否发送
    u8 m_bySecVidIsRecv;                        //辅流是否接收
    u8 m_byAudIsSend;                           //音频是否发送
    u8 m_byAudIsRecv;                           //音频是否接收

    u8 m_byStatus;                              //上报状态
    u8 m_byHasMatrix;                           //上报矩阵信息
    u8 m_byFecc;                                //上报远遥情况
    u8 m_byInMixer;                             //上报混音器状态
    u8 m_byInVmp;                               //上报画面合成器状态
    u8 m_byInHdu;                               //上报电视墙信息
    u8 m_byVideoFreeze;                         //上报视频冻结
    u8 m_byInputMutu;                           //上报哑音
    u8 m_byoutputMute;                          //上报静音
    u8 m_byRec;                                 //上报终端录像
	u8 m_byRecSec;                              //上报终端录双流 //Add by wq[2013-11-12] add dual record status
    u8 m_byInputVolume;                         //上报输入音量
    u8 m_byOutputVolume;                        //上报输出音量
    //Modify by jianghuan[2013-11-20] 增加主流和辅流选看通道
    DCTMtParambyXml m_dctMainVideoMtInfo;   //选看的主视频终端
    DCTMtParambyXml m_dctSecVideoMtInfo;    //选看的辅视频终端
    DCTMtInfobyXml  m_dctAudMtInfo;         //选看的音频终端
    u8 m_byVmpMtInfo;                  //是否选看VMP 0没有选看 1主通道 2辅流选看
    u8 m_byMixerMtInfo;                //是否选听Mixer 0没有选听 1选听
    /*
    s8 m_achmvidsrcE164[MAXLEN_E164+1];         //上报主流选看的终端E164
    s8 m_achsvidsrcE164[MAXLEN_E164+1];         //上报辅流选看的终端E164
    s8 m_achaudsrcE164[MAXLEN_E164+1];          //上报选听的终端E164
    */
public:
    DCTMTStatusCfgNfy()
    {
        memset(m_achMTE164, 0, sizeof(m_achMTE164));
        memset(m_achConfE164, 0, sizeof(m_achConfE164));

        m_byMainVidIsSend = 0;
        m_byMainVidIsRecv = 0;
        m_bySecVidIsSend = 0;
        m_bySecVidIsRecv = 0;
        m_byAudIsSend = 0;
        m_byAudIsRecv = 0;
        m_byStatus = 0; 
        m_byHasMatrix = 0;
        m_byFecc = 0;
        m_byInMixer = 0;
        m_byInVmp = 0;
        m_byInHdu = 0;
        m_byVideoFreeze = 0;
        m_byInputMutu = 0;
        m_byoutputMute = 0;
        m_byRec = 0;
		m_byRecSec = 0;
        m_byInputVolume = 0;
        m_byOutputVolume = 0;
        m_byVmpMtInfo = 0;
        m_byMixerMtInfo = 0;
    }

    void print( void )
    {
        Sdk_Printf("m_achMTE164: %s\n", m_achMTE164);
        Sdk_Printf("m_achConfE164: %s\n", m_achConfE164);
        Sdk_Printf("m_byMainVidIsSend: %u\n", m_byMainVidIsSend);
        Sdk_Printf("m_byMainVidIsRecv: %u\n", m_byMainVidIsRecv);
        Sdk_Printf("m_bySecVidIsSend: %u\n", m_bySecVidIsSend);
        Sdk_Printf("m_bySecVidIsRecv: %u\n", m_bySecVidIsRecv);
        Sdk_Printf("m_byAudIsSend: %u\n", m_byAudIsSend);
        Sdk_Printf("m_byAudIsRecv: %u\n", m_byAudIsRecv);
        Sdk_Printf("m_byStatus: %u\n", m_byStatus);
        Sdk_Printf("m_byHasMatrix: %u\n", m_byHasMatrix);
        Sdk_Printf("m_byFecc: %u\n", m_byFecc);
        Sdk_Printf("m_byInMixer: %u\n", m_byInMixer);
        Sdk_Printf("m_byInVmp: %u\n", m_byInVmp);
        Sdk_Printf("m_byInHdu: %u\n", m_byInHdu);
        Sdk_Printf("m_byVideoFreeze: %u\n", m_byVideoFreeze);
        Sdk_Printf("m_byInputMutu: %u\n", m_byInputMutu);
        Sdk_Printf("m_byoutputMute: %u\n", m_byoutputMute);
        Sdk_Printf("m_byRec: %u\n", m_byRec);
		Sdk_Printf("m_byRecSec: %u\n", m_byRecSec);
        Sdk_Printf("m_byInputVolume: %u\n", m_byInputVolume);
        Sdk_Printf("m_byOutputVolume: %u\n", m_byOutputVolume);
        //Modify by jianghuan[2013-11-20] 增加主流和辅流选看通道
        m_dctMainVideoMtInfo.Print();
        m_dctSecVideoMtInfo.Print();
        m_dctAudMtInfo.Print();
        Sdk_Printf("m_byVmpMtInfo: %u\n", m_byVmpMtInfo);
        Sdk_Printf("m_byMixerMtInfo: %u\n", m_byMixerMtInfo);
        /*
        Sdk_Printf("m_achmvidsrcE164: %s\n", m_achmvidsrcE164);
        Sdk_Printf("m_achsvidsrcE164: %s\n", m_achsvidsrcE164);
        Sdk_Printf("m_achaudsrcE164: %s\n", m_achaudsrcE164);
        */
    }
}
PACKED;

//终端在线状态 
typedef enum
{
	MT_OFFLINE = 0,				//下线
	MT_ONLINE = 1,				//在线
	MT_IDLE  = 2,				//空闲
	MT_BUSY = 3,				//忙
}MT_STATUS;

//终端信息状态
struct DCTMTStatusnfy
{
public:
	s8 m_achMTE164[MAXLEN_E164+1];
	u8 m_byMtStatus;
public:
	DCTMTStatusnfy()
	{
		m_byMtStatus = MT_OFFLINE;
		memset(m_achMTE164, 0, sizeof(m_achMTE164));
	}

	void print( void ) const
	{
		Sdk_Printf("m_achMTE164: %s\n", m_achMTE164);
		Sdk_Printf("m_byMtStatus: %u\n", m_byMtStatus);
	}
}
PACKED;

//会议状态上报  模板会议和及时会议共用此结构体
struct DCTConfStatusNfy
{
public:
	s8 m_achConfE164[MAXLEN_E164+1];
	s8 m_achConfName[DC_MAXLEN_CONFNAME+1];
	s8 m_achChairman[MAXLEN_E164+1];
	s8 m_achSpeakerman[MAXLEN_E164+1];
	u8 m_byIsRecNotify;
    u8 m_byTakeMode;            //会议方式 1表示及时会议 2表示模板会议 add by jianghuan 2014-5-21 
	u8 m_byMTCount;
	DCTMTStatusnfy m_dctmts[MAX_CONFMT_NUM];
public:
	DCTConfStatusNfy()
	{
		memset(m_achConfE164, 0, sizeof(m_achConfE164));
		memset(m_achConfName, 0, sizeof(m_achConfName));
		memset(m_achChairman, 0, sizeof(m_achChairman));
		memset(m_achSpeakerman, 0, sizeof(m_achSpeakerman));
		m_byIsRecNotify = 0;
		m_byMTCount = 0;
        m_byTakeMode = CONF_TAKEMODE_ONGOING;
	}

	void print( void ) const
	{
		Sdk_Printf("m_achConfE164: %s\n", m_achConfE164);
		Sdk_Printf("m_achTypeName: %s\n", m_achConfName);
		Sdk_Printf("m_achChairman: %s\n", m_achChairman);
		Sdk_Printf("m_achSpeakerman: %s\n", m_achSpeakerman);
		Sdk_Printf("m_byIsRecNotify: %u\n", m_byIsRecNotify);
        Sdk_Printf("m_byTakeMode: %d\n", m_byTakeMode);
		Sdk_Printf("m_byMTCount: %u\n", m_byMTCount);

		u8 byActualNum = 0;
		byActualNum = MIN(m_byMTCount, MAX_CONFMT_NUM);
		u8 byNum = 0;
		for (; byNum < byActualNum; byNum += 1)
		{
			Sdk_Printf("m_dctmts[%u].m_achMTE164: %s\n", byNum, m_dctmts[byNum].m_achMTE164);
			Sdk_Printf("m_dctmts[%u].m_byMtStatus: %u\n", byNum, m_dctmts[byNum].m_byMtStatus);
		}
	}
}
PACKED;

//会议E164号和会议名称
struct DCTConfE164Info
{
	s8 m_achConfInfo[DC_MAXLEN_ConfE164+1];
    // add by jianghuan [2013-11-14] 添加会议名称
    s8 m_achConfName[MAXLEN_CONFNAME+1];    //会议名
public:
    DCTConfE164Info()
    {
        memset(m_achConfInfo, 0, sizeof(m_achConfInfo));
        memset(m_achConfName, 0, sizeof(m_achConfName));
    }
    void Print() const 
    {
        Sdk_Printf("stuct: DCTConfE164Info\n");
        Sdk_Printf("E164:%s\n", m_achConfInfo);
        Sdk_Printf("ConfName:%s\n", m_achConfName);
    }
}
PACKED;

//会议E164号
struct DCTConfE164
{
    s8 m_achConfInfo[DC_MAXLEN_ConfE164+1];
public:
    DCTConfE164()
    {
        memset(m_achConfInfo, 0, sizeof(m_achConfInfo));
    }
    void Print() const 
    {
        Sdk_Printf("stuct: DCTConfE164\n");
        Sdk_Printf("E164:%s\n", m_achConfInfo);
    }
}
PACKED;

//会议错误
struct DCTConfError
{
	s8 m_achConfE164[DC_MAXLEN_ConfE164+1];
	u32 m_dwErrorCode;
public:
	DCTConfError()
	{
		memset(this, 0, sizeof(DCTConfError));
	}
	void Print() const 
	{
		Sdk_Printf("struct: DCTConfError\n");
		Sdk_Printf("E164:%s, error id:%u\n", m_achConfE164, m_dwErrorCode);
	}
}
PACKED;

//会议列表---（平台状态上报）
struct DCTConfTable
{
public:
    s32  m_nConfNum;                                        //会议个数
    DCTConfE164Info m_dctConfE164Info[DC_MAXNUM_MCU_CONF];  //会议名称列表
    u32  m_dwReserve;                                       //保留
    
public:
    DCTConfTable()
    {
        memset(this, 0, sizeof(DCTConfTable));
    }
    
    void   SetConfTable(DCTConfE164Info *ptConfE164Info, u8 byMtNum)
    {
        if (NULL != ptConfE164Info)
        {
            byMtNum = MIN(byMtNum, DC_MAXNUM_MCU_CONF);
            for (s32 nIndex = 0; nIndex < byMtNum; nIndex++)
            {
                memcpy(m_dctConfE164Info[nIndex].m_achConfInfo, 
					   ptConfE164Info[nIndex].m_achConfInfo, sizeof(ptConfE164Info->m_achConfInfo));
                memcpy(m_dctConfE164Info[nIndex].m_achConfName,
					   ptConfE164Info[nIndex].m_achConfName, sizeof(ptConfE164Info->m_achConfName));
            }
        }
    }
    DCTConfE164Info* GetConfTable() {return m_dctConfE164Info;}
    
    void SetConfNum(s32 nConfNum) {m_nConfNum = nConfNum;}
    u32 GetConfNum() const {return m_nConfNum;}
    
    void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
    u32    GetReserve() const {return m_dwReserve;}
    
    void Print() const
    {
        Sdk_Printf("struct: DCTConfTable:\n");
        Sdk_Printf("ConfE164Info---");
        for (s32 nIndex = 0; nIndex < m_nConfNum; nIndex++)
        {
            m_dctConfE164Info[nIndex].Print();
        }
        Sdk_Printf("ConfNumL: %d\n", m_nConfNum);
    }
    void Clear()
    {
        memset(this, 0, sizeof(DCTConfTable));
    }
}
PACKED;

//与会终端列表---[12/16/2014 张秋悦]
struct DCTJoinedMtTable
{
public:
    s32  m_nJoinedMtNum;                       //与会终端个数
    DCTMtInfo m_dctMtInfo[DC_MAXNUM_CONF_MT];  //与会终端列表
    
public:
    DCTJoinedMtTable()
    {
        memset(this, 0, sizeof(DCTJoinedMtTable));
    }
    
    void   SetJoinedMtTable(DCTMtInfo *m_pdctMtInfo, u8 byJoinedMtNum)
    {
        if (NULL != m_dctMtInfo)
        {
            byJoinedMtNum = MIN(byJoinedMtNum, DC_MAXNUM_MCU_CONF);
            for (s32 nIndex = 0; nIndex < byJoinedMtNum; nIndex++)
            {
                memcpy(m_dctMtInfo[nIndex].m_achMtInfo, 
					m_pdctMtInfo[nIndex].m_achMtInfo, sizeof(m_pdctMtInfo->m_achMtInfo));
				m_dctMtInfo[nIndex].m_bySubType = m_pdctMtInfo->m_bySubType;
				m_dctMtInfo[nIndex].m_wMcuIdx = m_pdctMtInfo->m_wMcuIdx;
            }
        }
    }
    DCTMtInfo* GetConfTable() {return m_dctMtInfo;}
    
    void SetConfNum(s32 nConfNum) {m_nJoinedMtNum = nConfNum;}
    u32 GetConfNum() const {return m_nJoinedMtNum;}
    
    void Print() const
    {
 //     Sdk_Printf("struct: DCTJoinedMtTable:\n");
        Sdk_Printf("JoinedMtInfo---");
        for (s32 nIndex = 0; nIndex < m_nJoinedMtNum; nIndex++)
        {
            //m_dctMtInfo[nIndex].Print();
        }
        Sdk_Printf("JoinedMtNum: %d\n\n", m_nJoinedMtNum);
    }
    void Clear()
    {
        memset(this, 0, sizeof(DCTJoinedMtTable));
    }
}
PACKED;

// 监控参数---[12/16/2014 张秋悦]
// struct DCTMonitorParam
// {
// public:
//     DCTMonitorParam()
//     {
//         memset( this, 0, sizeof (DCTMonitorParam) );
//     }
// 	void print()
// 	{
// 		Sdk_Printf("---------DCTMonitorParam---------\n");
//  		Sdk_Printf("LocalIp = %d\n", m_dwLocalIp);
// 	}
// 
// private:
//     u32             m_dwLocalIp;        //  本机IP
//     TMt             m_tVideoMt;         //  监控视频源
//     TMt             m_tAudioMt;         //  监控音频源
//     u16             m_wLocalPort;       //  接收码流端口
//     u8              m_byReal;           //  0-抽帧监控, 1-实时监控
//     u8              m_byQuiet;          //  0-不静音, 1-静音
//     u8              m_byMode;           //  MODE_BOTH/MODE_VIDEO/MODE_AUDIO
//     u8              m_byReserved;       //  保留字段
//     CConfId         m_cConfId;          //  会议号
//     TMediaEncrypt   m_tVideoMedia;      //  视频加密
//     TDoublePayload  m_tVideoPayload;    //  视频载荷
//     TMediaEncrypt   m_tAudioMedia;      //  音频加密
//     TDoublePayload  m_tAudioPayload;    //  音频载荷
//     TAudAACCap      m_tAudAACCap;       //  AAC的参数
// 	TTransportAddr  m_tVideoTransportAddr;   //  视屏RCTP端口和IP
// 	TTransportAddr  m_tAudioTransportAddr;   //  音频RCTP端口和IP
// }
// PACKED;


//监控状态---[12/16/2014 张秋悦]
struct DCTMonitorStatus
{
public:

	DCTMonitorStatus()
	{
		clear();
	}
	void clear()
	{
		m_byMonChnnl = 0;
		m_byMonMode = 0;
		m_byIsCalling = 0;
	}
	u8 GetCannel(){ return m_byMonChnnl; }
	void SetCannel(u8 byCannel){ m_byMonChnnl = byCannel; }
	u8 GetMode(){ return m_byMonMode; }
	void SetMode( u8 byMode ){ m_byMonMode = byMode; }
	u8 GetIsCalling(){ return m_byIsCalling; }
	void SetIsCalling(u8 byIsCalling){m_byIsCalling = byIsCalling;}
    
	void Print()
	{
		Sdk_Printf("---------DCTMonitorStatus---------\n");
 		//Sdk_Printf("MonChnnl = %d\n", m_byMonChnnl);
 		//Sdk_Printf("MonMode = %d\n", m_byMonMode);
 		//Sdk_Printf("IsCalling = %d\n", m_byIsCalling);
	}
private:
	u8 m_byMonChnnl;
	u8 m_byMonMode;
	u8 m_byIsCalling;
}
PACKED;


//电视墙通道配置
struct DCTHduChnlCfgInfo
{
public:
	u8		m_byChnlIdx;                //通道索引号
	u8		m_byEqpId;					//设备ID
	u8		m_byChnlVolumn;             //通道音量
	BOOL32  m_bIsChnlBeQuiet;           //通道静音
	s8		m_achEqpAlias[DC_MAXLEN_EQP_ALIAS];   //外设别名

public:
	DCTHduChnlCfgInfo() { memset(this, 0, sizeof(DCTHduChnlCfgInfo)); }

	void Print() const
	{
		Sdk_Printf("[DCTHduChnlCfgInfo]: ChnlIdx:%d, EqpId:%d, ChnlVolumn:%d, IsChnlBeQuiet:%d, EqpAlias:%s\n",
				m_byChnlIdx, m_byEqpId, m_byChnlVolumn, m_bIsChnlBeQuiet, m_achEqpAlias);
	}

}PACKED;

//电视墙预案信息
struct DCTHduStyleCfgInfo
{
public:
	u8   m_byStyleIdx;          //方案Id
	u8   m_byTotalChnlNum;      //方案需要的通道数，即界面中可配置的最大通道数
								//根据不同的方案可为1、2、4、…、56，最大56个
	DCTHduChnlCfgInfo m_atHduChnlCfgTable[DC_MAXNUM_HDUCFG_CHNLNUM];  //各通道需要的配置资源
	//m_bywidth * m_byHeight <= 56
	u8		m_byColNum;            //界面配置的宽度
	u8		m_byRowNum;            //界面配置的高度
	u8		m_byVolumn;            //所有通道统一音量大小
	BOOL32  m_bIsBeQuiet;          //所有通道是否统一静音
	s8		m_achSchemeAlias[DC_MAX_HDUSTYLE_ALIASLEN];   //预方案别名

public:
	DCTHduStyleCfgInfo() { memset(this, 0, sizeof(DCTHduStyleCfgInfo)); }
	BOOL32 IsNull(void) 
	{ 
		DCTHduStyleCfgInfo tInfo;
		return (0 == memcmp(this, &tInfo, sizeof(DCTHduStyleCfgInfo)));
	}

	//patHduChnlCfgTable  为数组指针，元素个数为DC_MAXNUM_HDUCFG_CHNLNUM
	void GetHduChnlCfgTable(DCTHduChnlCfgInfo *patHduChnlCfgTable)
	{
		memcpy(patHduChnlCfgTable, m_atHduChnlCfgTable, DC_MAXNUM_HDUCFG_CHNLNUM*sizeof(DCTHduChnlCfgInfo));
		return;
	}
	//patHduChnlCfgTable  为数组指针，元素个数为DC_MAXNUM_HDUCFG_CHNLNUM
	BOOL32 SetHduChnlCfgTable(DCTHduChnlCfgInfo *patHduChnlCfgTable)
	{
		BOOL32 bRet = TRUE;
		if (NULL == patHduChnlCfgTable)
		{
			bRet = FALSE;
		}

		memcpy(m_atHduChnlCfgTable, patHduChnlCfgTable, DC_MAXNUM_HDUCFG_CHNLNUM*sizeof(DCTHduChnlCfgInfo));
		return bRet;
	}

	u8   GetStyleIdx(void) const { return m_byStyleIdx; }
	void SetStyleIdx(u8 val) { m_byStyleIdx = val; }

	u8   GetTotalChnlNum(void) const { return m_byTotalChnlNum; }
	void SetTotalChnlNum(u8 val) { m_byTotalChnlNum = val; }

	u8   GetWidth(void) const { return m_byColNum; }
	void SetWidth(u8 val) { m_byColNum = val; }

	u8   GetHeight(void) const { return m_byRowNum; }
	void SetHeight(u8 val) { m_byRowNum = val; }

	u8   GetVolumn(void) const { return m_byVolumn; }
	void SetVolumn(u8 val) { m_byVolumn = val; }

	BOOL32 GetIsBeQuiet(void) const { return m_bIsBeQuiet; }
	void SetIsBeQuiet(BOOL32 val) { m_bIsBeQuiet = val; }

	void SetSchemeAlias(LPCSTR pchSchemeAlias)
	{
		memcpy(m_achSchemeAlias, pchSchemeAlias, sizeof(m_achSchemeAlias));
		m_achSchemeAlias[DC_MAX_HDUSTYLE_ALIASLEN-1] = '\0';
	}

	LPCSTR GetSchemeAlias(void){ return m_achSchemeAlias; }

	void Print() const 
	{
		Sdk_Printf( "[THduStyleCfgInfo]: StyleIdx:%d, TotalChnlNum:%d, Volumn:%d, Width:%d, Height:%d, IsBeQuiet:%d\n",
			GetStyleIdx(), GetTotalChnlNum(), GetVolumn(), GetWidth(), GetHeight(), GetIsBeQuiet());
		Sdk_Printf( "[THduStyleCfgInfo]: Hdu Scheme Alias is:%s \n", m_achSchemeAlias);

		for (u16 wIndex = 0; wIndex < m_byColNum*m_byRowNum; wIndex++)
		{
			m_atHduChnlCfgTable[wIndex].Print();
		}
	}

}PACKED;

//电视墙预案信息列表
struct DCTHduStyleCfgInfoList
{
public:
	DCTHduStyleCfgInfoList()
	{
		memset(this, 0, sizeof(DCTHduStyleCfgInfoList));
	}

	void SetHduStyleCfgNum(u32 dwCfgNum)
	{
		m_dwHduStyleCfgNum = MIN(dwCfgNum, DC_MAX_HDUSTYLE_NUM);
	}

	u32 GetHduStyleCfgNum()
	{
		return m_dwHduStyleCfgNum;
	}

	void SetHduStyleCfgInfo(u32 dwStyleIdx, DCTHduStyleCfgInfo tHduStyleCfgInfo)
	{
		if ( dwStyleIdx < DC_MAX_HDUSTYLE_NUM )
		{
			m_atHduStyleCfgInfo[dwStyleIdx] = tHduStyleCfgInfo;
		}
	}
	DCTHduStyleCfgInfo *GetHduStyleCfgInfo(u32 dwStyleIdx)
	{
		if ( dwStyleIdx < DC_MAX_HDUSTYLE_NUM )
		{
			return &m_atHduStyleCfgInfo[dwStyleIdx];
		}

		return NULL;
	}
	void Print()
	{
		Sdk_Printf("—————DCTHduStyleCfgInfoList<%d>—————\n", GetHduStyleCfgNum());
		for (u32 nIdx = 0; nIdx < GetHduStyleCfgNum(); nIdx++)
		{
			m_atHduStyleCfgInfo[nIdx].Print();
		}
	}
private:
	u32 m_dwHduStyleCfgNum;
	DCTHduStyleCfgInfo m_atHduStyleCfgInfo[DC_MAX_HDUSTYLE_NUM];
}
PACKED;


//开始电视墙参数
struct DCTStartHduParam
{
public:
	DCTMtInfo m_tMtInfo;		//终端信息，终端上墙时设置
	u16		m_wHduEqpId;		//电视墙外设id
	u8		m_byChanIdx;		//电视墙通道索引
	u8		m_byMemberType;		//电视墙成员类型, eg: 1-会控指定 2-发言人跟随 3-主席跟随...
	u8		m_byHduStyleID;		//电视墙预案号
	u16		m_wVmpEqpId;		//画面合成器外设id，只在选看画面合成用 

public:
	DCTStartHduParam()
	{
		memset(this, 0, sizeof(DCTStartHduParam));
	}

	void Print(void) const
	{
		Sdk_Printf("DCTStartHduParam:\n");
		Sdk_Printf("MtAlias: %s, subtype:%d, mcutype:%d\n", 
			m_tMtInfo.m_achMtInfo, m_tMtInfo.m_bySubType, m_tMtInfo.m_wMcuIdx);
		Sdk_Printf("wHduEqpId = %u\n", m_wHduEqpId);
		Sdk_Printf("byChanIdx = %d\n", m_byChanIdx);
		Sdk_Printf("byMemberType = %d\n", m_byMemberType);
		Sdk_Printf("byHduStyleID = %d\n", m_byHduStyleID);
		Sdk_Printf("wVmpEqpId = %d\n", m_wVmpEqpId);
	}

}PACKED;


struct DCTHduChnStatus
{
public:
	u8 m_byStatus;	//通道状态
	u8 m_byVolume;	//音量				
	u8 m_byMute;	//是否静音
	u8 m_byMemberType;	//通道成员类型

public:
	DCTHduChnStatus()
	{
		memset(this, 0, sizeof(DCTHduChnStatus));
	}

	void   SetStatus( u8 byStatus ) { m_byStatus = byStatus; };
	u8     GetStatus( void )  const { return m_byStatus; }

	u8     GetVolume( void ) const { return m_byVolume; }
	void   SetVolume( u8 byVolume ){ m_byVolume = byVolume; }

	BOOL32   GetIsMute( void ) const { return m_byMute; }
	void     SetIsMute( BOOL32 byIsMute ){ m_byMute = byIsMute?1:0; }

	u8     GetMemberType( void ) const { return m_byMemberType; }
	void   SetMemberType( u8 byMemberType ){ m_byMemberType = byMemberType; }

	void Print(void) const
	{
		Sdk_Printf("DCTHduChnStatus:\n");
		Sdk_Printf("byStatus = %d\n", m_byStatus);
		Sdk_Printf("byVolume = %d\n", m_byVolume);
		Sdk_Printf("byMute = %d\n", m_byMute);
		Sdk_Printf("byMemberType = %d\n", m_byMemberType);
	}
} 
PACKED;

//  [4/15/2014 panyingnan]
struct DCTHduStatusList
{
public:
	void SetOnline(BOOL32 bOnline)
	{
		m_bOnline = bOnline;
	}
	BOOL32 IsOnline()
	{
		BOOL32 bTrue = FALSE;
		m_bOnline > 0 ? bTrue = TRUE : bTrue = FALSE;
		return bTrue;
	}

	void SetHduAbsId( u16 wHduAbsId)
	{
		m_wHduAbsId = wHduAbsId;
	}
	u16 GetHduAbsId()
	{
		return m_wHduAbsId;
	}

	DCTHduChnStatus GetHduChnStatus(u8 byHduChn)
	{
		DCTHduChnStatus tHduChnStatus;
		memset(&tHduChnStatus, 0, sizeof(DCTHduChnStatus));

		if (byHduChn < DC_MAX_HDU_CHAN )
		{
			tHduChnStatus.m_byStatus = m_atHduChnStatus[byHduChn].GetStatus();
			tHduChnStatus.m_byMute   = m_atHduChnStatus[byHduChn].GetIsMute();
			tHduChnStatus.m_byVolume = m_atHduChnStatus[byHduChn].GetVolume();
			tHduChnStatus.m_byMemberType = m_atHduChnStatus[byHduChn].GetMemberType();
		}
		return tHduChnStatus;
	}
	void SetHduChnStatus(u8 byHduChn, DCTHduChnStatus tHduChnStatus)
	{
		if (byHduChn < DC_MAX_HDU_CHAN )
		{
			m_atHduChnStatus[byHduChn].SetStatus(tHduChnStatus.GetStatus());
			m_atHduChnStatus[byHduChn].SetVolume(tHduChnStatus.GetVolume());
			m_atHduChnStatus[byHduChn].SetIsMute(tHduChnStatus.GetIsMute());
			m_atHduChnStatus[byHduChn].SetMemberType(tHduChnStatus.GetMemberType());
		}
	}

	//  [6/5/2014 panyingnan]
	void SetApsId(u16 wApsId)
	{
		m_wApsServID = wApsId;
	}

	u16 GetApsId()
	{
		return m_wApsServID;
	}

    void SetIpAddr(u32 dwIpAddr)
	{
		m_dwIpAddr = dwIpAddr;
	}
	 
	u32 GetIpAddr()
	{
		return m_dwIpAddr;
	}

	BOOL32 GetIpAddrString(s8 *lpszIpaddr, u8 byLen )
	{
		if (NULL == lpszIpaddr )
		{
			return FALSE;
		}
		

		s8 achIp[MAXLEN_IP] = {'\0'};
		sprintf( achIp, "%d.%d.%d.%d", (m_dwIpAddr >> 24) & 0xff, (m_dwIpAddr >> 16) & 0xff, (m_dwIpAddr >> 8) & 0xff, m_dwIpAddr & 0xff);
		
		if ( byLen < strlen(achIp) )
		{
			return FALSE;
		}

		memcpy(lpszIpaddr, achIp, strlen(achIp));
        return TRUE;
	}
	s8 * GetAlias()
	{ 
		return m_achAlias;
	}
	
	//设置外设别名
	void SetAlias(const s8 * lpszAlias)
	{ 
        if ( NULL == lpszAlias )
        {
            memset(m_achAlias, '\0', sizeof(m_achAlias) );
        }
        else
        {
            strncpy(m_achAlias, lpszAlias, sizeof(m_achAlias));
			m_achAlias[DC_MAXLEN_EQP_ALIAS-1] = '\0';
        }
	}
	//end
	void clear()
	{
		m_bOnline = FALSE;
		m_wHduAbsId = 0;
		m_wApsServID = 0;
		m_dwIpAddr = 0;
		memset(m_achAlias, 0, strlen(m_achAlias));
		for ( s32 nIdx = 0; nIdx < DC_MAX_HDU_CHAN; nIdx++)
		{
			m_atHduChnStatus[nIdx].SetStatus(eIDLE);
			m_atHduChnStatus[nIdx].SetIsMute(FALSE);
			m_atHduChnStatus[nIdx].SetVolume(0);
			memset(&m_atMt[nIdx], 0, sizeof(DCTMtInfo));
			memset(&m_atConf[nIdx], 0, sizeof(DCTConfE164));
		}
	}

	void Print()
	{
		Sdk_Printf("HDU:%d\t Online:%s\t\n", m_wHduAbsId, IsOnline() ? "√" : "×");
		Sdk_Printf("HduApsID:%d\n", GetApsId());
		Sdk_Printf("HduAlias:%s\n", GetAlias());
		s8 achIpAddr[MAXLEN_IP] = {"\0"};
		GetIpAddrString(achIpAddr, MAXLEN_IP);
		Sdk_Printf("HduIpAddr:%s\n", achIpAddr);
		//Sdk_Printf("APSID:%d\t IP:%s Alias:%s\n", GetApsId(), achIpAddr, GetAlias());
		for (s32 nIdx = 0; nIdx < DC_MAX_HDU_CHAN; nIdx++)
		{
			Sdk_Printf("Chnnl.%d\t MtAlias:%s\t SubType:%d\t McuIdx:%u\t Conf:%s\n",
				nIdx, m_atMt[nIdx].m_achMtInfo, m_atMt[nIdx].m_bySubType, m_atMt[nIdx].m_wMcuIdx, m_atConf[nIdx].m_achConfInfo);

			m_atHduChnStatus[nIdx].Print();
		}
	}
public:
    DCTMtInfo m_atMt[DC_MAX_HDU_CHAN];// 通道对应终端 [5/22/2014 panyingnan]
	DCTConfE164 m_atConf[DC_MAX_HDU_CHAN];// 通道对应会议 [5/23/2014 panyingnan]
private:
	BOOL32 m_bOnline;//是否在线
	u16    m_wHduAbsId;//移植到8000A，此处存 EqpId [daishangwei 2014/10/30]
	u16 m_wApsServID;//绑定的APSID  [6/5/2014 panyingnan]
	u32 m_dwIpAddr;//  [6/6/2014 panyingnan]Ip地址
	s8 m_achAlias[DC_MAXLEN_EQP_ALIAS];// 电视墙别名 [6/5/2014 panyingnan]
	DCTHduChnStatus m_atHduChnStatus[DC_MAX_HDU_CHAN];//两个通道的状态
}PACKED;


//轮询成员
struct DCTMtPollParam:DCTMtInfo
{
protected:
	u16   m_wKeepTime;        //终端轮询的保留时间 单位:秒(s)(5~7200)
    //u32   m_dwPollNum;        //终端轮询的次数----轮询终端次数内部统一为会议轮询次数
public:
	void  SetKeepTime(u16 wKeepTime) { m_wKeepTime = htons(wKeepTime); } 
	u16   GetKeepTime(void) const { return ntohs(m_wKeepTime); }
    //void  SetPollNum(u32 dwPollNum) { m_dwPollNum = htonl(dwPollNum); } 
	//u32   GetPollNum(void) const { return ntohl(m_dwPollNum); }
	DCTMtInfo   GetTMt(void) const { return *(DCTMtInfo *)this; }
	//void  SetTMt(DCTMtInfo tMt) { memcpy( this, &tMt, sizeof(tMt) ); }
}
PACKED;
//轮询成员列表
struct DCTPollMemberNfy
{
public:
	DCTMtPollParam m_atMtParam[DC_MAXNUM_CONF_MT];// 不知道最多能轮询多少个终端 [5/13/2014 panyingnan]
	s8 m_achConfE164[MAXLEN_E164+1];
	u32 m_dwMemberNum;//成员个数
public:
	DCTPollMemberNfy()
	{
		memset(m_achConfE164, 0, sizeof(m_achConfE164));
	}
	void Print(void) const
	{
		Sdk_Printf("\nPollMemberNfy:\n");
		Sdk_Printf("m_achConfE164 = %s\n", m_achConfE164);
		Sdk_Printf("m_nMemberNum = %d\n", m_dwMemberNum);
		for (u32 dwIdx = 0; dwIdx < m_dwMemberNum; dwIdx++)
		{
			Sdk_Printf("PollMem[%d]:%s, keepTime = %d\n", 
				dwIdx, m_atMtParam[dwIdx].m_achMtInfo, m_atMtParam[dwIdx].GetKeepTime());
		}
	}
}
PACKED;

//轮询状态
struct DCTPollInfo
{
public:
	s8 m_achConfE164[MAXLEN_E164+1];
protected:
    u8  m_byMediaMode;           //轮询模式 MODE_VIDEO 图像  MODE_BOTH 语音图像
    u8  m_byPollState;           //轮询状态，参见轮询状态定义
    u32 m_dwPollNum;             //终端轮询的次数
    DCTMtPollParam m_tMtPollParam; //当前被轮询广播的终端及其参数

public:
    void SetMediaMode(u8 byMediaMode) { m_byMediaMode = byMediaMode; }
    u8   GetMediaMode(void) const { return m_byMediaMode; }
    void SetPollState(u8 byPollState) { m_byPollState = byPollState; }
    u8   GetPollState(void) const { return m_byPollState; }
    void SetPollNum(u32 dwPollNum) { m_dwPollNum = htonl(dwPollNum); }
    u32  GetPollNum(void) const { return ntohl(m_dwPollNum); }
    void SetMtPollParam(DCTMtPollParam tMtPollParam){ m_tMtPollParam = tMtPollParam; }
    DCTMtPollParam GetMtPollParam() const{ return m_tMtPollParam; }
    void Print(void) const
    {
        Sdk_Printf("\nDCTPollInfo:\n");
		Sdk_Printf("m_achConfE164: %s\n", m_achConfE164);
        Sdk_Printf("m_byMediaMode: %d\n", m_byMediaMode);
        Sdk_Printf("m_byPollState: %d\n", m_byPollState);
        Sdk_Printf("m_dwPollNum: %d\n", GetPollNum());
        Sdk_Printf("CurPollMt: %s\n", m_tMtPollParam.m_achMtInfo);
		Sdk_Printf("CurPollMt-KeepTime: %d\n", m_tMtPollParam.GetKeepTime());
    }
}
PACKED;

//轮询请求
struct DCTPollReq
{
public:
    s8 m_achConfE164[MAXLEN_E164+1];
    u8  m_byMediaMode;           //轮询模式 MODE_VIDEO 图像  MODE_BOTH 语音图像
    u32 m_dwPollNum;             //终端轮询的次数
    u32 m_dwMemberNum;           //成员个数
    DCTMtPollParam m_atMtParam[DC_MAXNUM_CONF_MT];//不知道最多能轮询多少个终端
public:
    DCTPollReq()
    {
        memset(m_achConfE164, 0, sizeof(m_achConfE164));
    }
    void Print(void) const
    {
        Sdk_Printf("DCTPollReq:\n");
        Sdk_Printf("m_achConfE164 = %s\n", m_achConfE164);
        Sdk_Printf("m_byMediaMode = %d\n", m_byMediaMode);
        Sdk_Printf("m_dwPollNum = %d\n", m_dwPollNum);
        Sdk_Printf("m_nMemberNum = %d\n", m_dwMemberNum);
        for (u32 dwIdx = 0; dwIdx < m_dwMemberNum; dwIdx++)
        {
            Sdk_Printf("PollMem[%d]:%s, keepTime = %d\n", 
                dwIdx, m_atMtParam[dwIdx].m_achMtInfo, m_atMtParam[dwIdx].GetKeepTime());
        }
    }
}
PACKED;

//会议列表---（平台状态上报）
struct DCTTVWallStatus
{
public:
    DCTHduStatusList m_dctHduStatusList[DC_MAX_TVWALL_NUM];   //电视墙
    s32  m_nTVWallNum;                                        //电视墙个数
    u32  m_dwReserve;                                         //保留
    
public:
    DCTTVWallStatus()
    {
        memset(this, 0, sizeof(DCTTVWallStatus));
    }
    void Clear()
    {
        memset(this, 0, sizeof(DCTTVWallStatus));
    }
    void Print() const
    {
        Sdk_Printf("struct: DCTTVWallStatus:\n");
        for (s32 nIndex = 0; nIndex < m_nTVWallNum; nIndex++)
        {
            //dctHduStatusList[nIndex].clear();
        }
        Sdk_Printf("m_nTVWallNum: %d\n", m_nTVWallNum);
    }
}
PACKED;

//会议模版列表---（平台状态上报）
struct DCTConfTemTable
{
public:
    DCTConfE164Info m_dctConfE164Info[DC_MAXNUM_MCU_TEMCONF];  //会议模版名称列表
    s32  m_nConfNum;                                        //会议个数
    u32  m_dwReserve;                                       //保留
    
public:
    DCTConfTemTable()
    {
        memset(this, 0, sizeof(DCTConfTemTable));
    }
    
    void   SetConfTable(DCTConfE164Info *ptConfE164Info, u8 byMtNum)
    {
        if (NULL != ptConfE164Info)
        {
            byMtNum = MIN(byMtNum, DC_MAXNUM_MCU_TEMCONF);
            for (s32 nIndex = 0; nIndex < byMtNum; nIndex++)
            {
                memcpy(m_dctConfE164Info[nIndex].m_achConfInfo, 
					ptConfE164Info[nIndex].m_achConfInfo, sizeof(ptConfE164Info->m_achConfInfo));
                memcpy(m_dctConfE164Info[nIndex].m_achConfName,
					ptConfE164Info[nIndex].m_achConfName, sizeof(ptConfE164Info->m_achConfName));
            }
        }
    }
    DCTConfE164Info* GetConfTable() {return m_dctConfE164Info;}
    
    void SetConfNum(s32 nConfNum) {m_nConfNum = nConfNum;}
    u32 GetConfNum() const {return m_nConfNum;}
    
    void   SetReserve(u32 dwReserve){m_dwReserve = dwReserve;}
    u32    GetReserve() const {return m_dwReserve;}
    
    void Print() const
    {
        Sdk_Printf("DCTConfTemTable:\n");
		Sdk_Printf("TemNum: %d\n", m_nConfNum);
        Sdk_Printf("TemList:\n");
		
        for (s32 nIndex = 0; nIndex < m_nConfNum; nIndex++)
        {
            m_dctConfE164Info[nIndex].Print();
        }
    }
    void Clear()
    {
        memset(this, 0, sizeof(DCTConfTemTable));
    }
}
PACKED;

//会议信息列表  在线会议信息列表和模板会议信息列表统一用此结构体
struct DCTConfInfoTable
{
public:
    u8 m_byTakeMode;                                            //会议方式
    s32  m_nConfNum;                                            //会议个数
    DCTConfE164Info m_dctConfE164Info[DC_MAX_CONF_NFY_TAB];   //会议模版名称列表
public:
    DCTConfInfoTable()
    {
        memset(this, 0, sizeof(DCTConfInfoTable));
        m_byTakeMode = CONF_TAKEMODE_ONGOING;
    }
    
    void   SetConfTable(DCTConfE164Info *ptConfE164Info, u8 byMtNum)
    {
        if (NULL != ptConfE164Info)
        {
            byMtNum = MIN(byMtNum, DC_MAX_CONF_NFY_TAB);
            for (s32 nIndex = 0; nIndex < byMtNum; nIndex++)
            {
                memcpy(m_dctConfE164Info[nIndex].m_achConfInfo, 
                    ptConfE164Info[nIndex].m_achConfInfo, sizeof(ptConfE164Info->m_achConfInfo));
                memcpy(m_dctConfE164Info[nIndex].m_achConfName,
                    ptConfE164Info[nIndex].m_achConfName, sizeof(ptConfE164Info->m_achConfName));
            }
        }
    }
    DCTConfE164Info* GetConfTable() {return m_dctConfE164Info;}
    
    void SetConfNum(s32 nConfNum) {m_nConfNum = nConfNum;}
    u32 GetConfNum() const {return m_nConfNum;}
    
    void Print() const
    {
        Sdk_Printf("DCTConfInfoTable:\n");
        Sdk_Printf("m_byTakeMode: %d\n", m_byTakeMode);
        Sdk_Printf("TemNum: %d\n", m_nConfNum);
        Sdk_Printf("TemList:\n");
        
        for (s32 nIndex = 0; nIndex < m_nConfNum; nIndex++)
        {
            m_dctConfE164Info[nIndex].Print();
        }
    }
    void Clear()
    {
        memset(this, 0, sizeof(DCTConfInfoTable));
        m_byTakeMode = CONF_TAKEMODE_ONGOING;
    }
}
PACKED;

struct DCTRecChnnlStatus
{
public:
	u8  		m_byType;		//通道类型：ERecChnnlType
	u8  		m_byState;		//通道状态：ERecChnnlState
	u8          m_byRecMode;    //录像方式:
	u32   		m_dwCurProg;	//当前进度(单位S)
	u32   		m_dwTotalTime;	//总长度，仅在放像时有效(单位S)
    DCTMtInfo   m_tMtE164Num;   //终端E164号码
	DCTConfE164 m_tConfE164Num;// 会议E164号码 [6/10/2014 panyingnan]
protected:
	char	m_achRecordName[DC_MAX_RECORDNAME_LEN];//记录名
	
public:
	//获取记录名
	LPCSTR GetRecordName( void ) const	{ return m_achRecordName; }
	//设置记录名
	void SetRecordName( LPCSTR lpszName ) 
	{
		strncpy( m_achRecordName, lpszName, sizeof( m_achRecordName ) );
		m_achRecordName[sizeof( m_achRecordName ) - 1] ='\0';
	}
	
	LPCSTR GetStatusStr( u8 eStatus )
	{
		switch(eStatus) 
		{
		case STATE_IDLE:
			return "IDLE";
			break;
		case STATE_RECREADY:
			return "REC Ready";
			break;
		case STATE_RECORDING:
			return "Recording";
			break;
		case STATE_RECPAUSE:
			return "REC Pause";
			break;
		case STATE_PLAYREADY:
			return "PLAY Ready";
			break;
		case STATE_PLAYING:
			return "Playing";
			break;
		case STATE_PLAYPAUSE:
			return "Play Pause";
			break;
		case STATE_FF:
			return "Play FF";
			break;
		case STATE_FB:
			return "Play FB";
		default:
			return "UNKOWN";
		}
	}

	void Print()
	{
	   Sdk_Printf("Type:%d\t State:%-10s\t RecMode:%d\t CurProg:%d(s)\t TotalTime:%d(s)\t MtE164Num:%-10s\t ConfE164Num:%-10s\t RecordName:%s\n",
		   m_byType, GetStatusStr(m_byState), m_byRecMode, m_dwCurProg, m_dwTotalTime, 
		   m_tMtE164Num.m_achMtInfo, m_tConfE164Num.m_achConfInfo, GetRecordName());
	}
	
}
PACKED;

//单个录像机的状态
struct DCTRecStatus
{
public:
	DCTRecStatus()
    {
        memset(this, 0, sizeof(DCTRecStatus));
	}

	void SetOnline(BOOL32 bOnline)
	{
		m_bOnline = bOnline;
	}
	BOOL32 IsOnline()
	{
		return m_bOnline;
	}

    void SetAbsId(u16 wAbsId)
	{
        m_wRecAbsID = wAbsId;
	}
	u16 GetAbsId()
	{
		return m_wRecAbsID;
	}

	void SetIpAddr(u32 dwIpAddr)
	{
		m_dwIpAddr = dwIpAddr;
	}
	u32 GetIpAddr()
	{
		return m_dwIpAddr;
	}
	
	BOOL32 GetIpAddrString(s8 *lpszIpaddr, u8 byLen )
	{
		if (NULL == lpszIpaddr )
		{
			return FALSE;
		}
		
		s8 achIp[MAXLEN_IP] = {'\0'};
		sprintf( achIp, "%d.%d.%d.%d", m_dwIpAddr >> 24, (m_dwIpAddr >> 16) & 0xff, (m_dwIpAddr >> 8) & 0xff, m_dwIpAddr & 0xff);
		
		if ( byLen < strlen(achIp) )
		{
			return FALSE;
		}
		
		memcpy(lpszIpaddr, achIp, strlen(achIp));
        return TRUE;
	}

	s8 * GetAlias()
	{ 
		return m_achAlias;
	}
	
	//设置外设别名
	void SetAlias(const s8 * lpszAlias)
	{ 
        if ( NULL == lpszAlias )
        {
            memset(m_achAlias, '\0', sizeof(m_achAlias) );
        }
        else
        {
            strncpy(m_achAlias, lpszAlias, sizeof(m_achAlias));
			m_achAlias[DC_MAXLEN_EQP_ALIAS-1] = '\0';
        }
	}

	//获取录像通道配置
	u8   GetRecChnnlNum( void ) const	{ return( m_byRecChnnlNum ); }
	//获取放像通道配置
	u8   GetPlayChnnlNum( void ) const	{ return( m_byPlayChnnlNum ); }
	//配置通道数，录像和放像通道总数必须不大于MAXNUM_RECORDER_CHNNL
	//失败返回FALSE
	BOOL32 SetChnnlNum( u8   byRecChnnlNum, u8   byPlayChnnlNum )
	{
		if( byRecChnnlNum + byPlayChnnlNum <= DC_MAX_RECCHNNL_NUM )
		{
			m_byRecChnnlNum = byRecChnnlNum;
			m_byPlayChnnlNum = byPlayChnnlNum;
			return( TRUE );
		}
		else
		{
			Sdk_Printf("TRecStatus: Exception - Wrong recorder and play channel number: %u and %u!\n", 
				byRecChnnlNum, byPlayChnnlNum );
			return( FALSE );
		}
	}
    /*====================================================================
    功能        ：设置录像机剩余磁盘空间
    输入参数说明：u32    dwFreeSpace  - 剩余空间大小(单位 Mb)
    返回值说明  ：无
	====================================================================*/
	void SetFreeSpaceSize( u32    dwFreeSpace )
	{
		m_dwFreeSpace  = htonl(dwFreeSpace);
	}
	
	/*====================================================================
    功能        ：获取录像机剩余磁盘空间
    输入参数说明：无
    返回值说明  ：剩余空间大小(单位 MB)
	====================================================================*/
	u32    GetFreeSpaceSize( void ) const	{ return ntohl( m_dwFreeSpace ); }

		/*====================================================================
    功能        ：设置录像机总磁盘空间
    输入参数说明：u32    dwTotalSpace  - 总空间大小(单位 MB)
    返回值说明  ：无
	====================================================================*/
	void SetTotalSpaceSize( u32    dwTotalSpace )
	{
		m_dwTotalSpace  = htonl( dwTotalSpace );
	}
	// 是否支持发布
	BOOL32 IsSupportPublic() const { return m_bSupportPublic;}
    // 设置是否支持发布
	void SetPublicAttribute(BOOL32 bSupportPublic ) { m_bSupportPublic = bSupportPublic;}

	/*====================================================================
    功能        ：获取录像机总磁盘空间
    输入参数说明：无
    返回值说明  ：总空间大小(单位 MB)
	====================================================================*/
	u32    GetTotalSpaceSize( void ) const	{ return ntohl( m_dwTotalSpace ); }

	//设置录像机信道状态信息，必须先配置录放像信道数再调用此函数
	BOOL32 SetChnnlStatus( u8   byChnnlIndex, u8   byChnnlType, const DCTRecChnnlStatus * ptStatus )
	{
		//record channel
		if( byChnnlType == TYPE_RECORD )
		{
			if( byChnnlIndex < m_byRecChnnlNum )
			{
				m_atChnnlStatus[byChnnlIndex] = *ptStatus;
				return( TRUE );
			}
			else
			{
				return( FALSE );
			}
		}
		else if( byChnnlType == TYPE_PLAY )	//放像信道
		{
			if( byChnnlIndex < m_byPlayChnnlNum )
			{
				m_atChnnlStatus[byChnnlIndex + m_byRecChnnlNum] = *ptStatus;
				return( TRUE );
			}
			else
			{
				return( FALSE );
			}
		}
		else
		{
			return( FALSE );
		}
	}
	//设置录像机信道状态信息，必须先配置录放像信道数再调用此函数
	BOOL32 GetChnnlStatus( u8   byChnnlIndex, u8   byChnnlType, DCTRecChnnlStatus * ptStatus ) const
	{
		if( byChnnlType == TYPE_RECORD )
		{
			if( byChnnlIndex < m_byRecChnnlNum )
			{
				*ptStatus = m_atChnnlStatus[byChnnlIndex];
				return( TRUE );
			}
			else
			{
				return( FALSE );
			}
		}
		else if( byChnnlType == TYPE_PLAY )	//放像信道
		{
			if( byChnnlIndex < m_byPlayChnnlNum )
			{
				*ptStatus = m_atChnnlStatus[byChnnlIndex + m_byRecChnnlNum];
				return( TRUE );
			}
			else
			{
				return( FALSE );
			}
		}
		else
		{
			return( FALSE );
		}
	}

	void SetRecDvcType(ERecDvcType emRecType){ m_emType = emRecType;}
	ERecDvcType GetRecDvcType(void) {return m_emType;}

	void Print()
	{
		s8 achIpAddr[MAXLEN_IP] = {0};
		GetIpAddrString(achIpAddr, MAXLEN_IP -1);
		Sdk_Printf("%s<%d><%s>, IsOnline:%s, Type:%d, IsSupportPulic:%s, Space<%dMB / %dMB>, RecChnnlNum:%d, PlayChnnlNum:%d\n", 
			GetAlias(), m_wRecAbsID, achIpAddr, IsOnline() ? "√" : "×", GetRecDvcType(), IsSupportPublic() ? "√" : "×",
			GetFreeSpaceSize(), GetTotalSpaceSize(), m_byRecChnnlNum, m_byPlayChnnlNum);
		Sdk_Printf("__________________________________________________________________________\n");
		for (u8 byRecChnnl = 0; byRecChnnl < m_byRecChnnlNum; byRecChnnl++)
		{
			DCTRecChnnlStatus dctRecChnnlStatus;
			GetChnnlStatus(byRecChnnl, TYPE_RECORD, &dctRecChnnlStatus);
			Sdk_Printf("Ch.%d", byRecChnnl);
			dctRecChnnlStatus.Print();
		}
        Sdk_Printf("            ___________________________________\n");
		for (u8 byPlayChnnl = 0; byPlayChnnl < m_byPlayChnnlNum; byPlayChnnl++)
		{
			DCTRecChnnlStatus dctPlayChnnlStatus;
			GetChnnlStatus(byPlayChnnl, TYPE_PLAY, &dctPlayChnnlStatus);
			Sdk_Printf("Ch.%d", byPlayChnnl);
			dctPlayChnnlStatus.Print();
		}
		Sdk_Printf("__________________________________________________________________________\n");
	}
private:
	BOOL32 m_bOnline;//是否在线
	u16    m_wRecAbsID;//移植到8000A，此处存 EqpId [daishangwei 2014/10/31]
	u32    m_dwIpAddr;//IP地址
	s8     m_achAlias[DC_MAXLEN_EQP_ALIAS];//录像机别名
	u8     m_byRecChnnlNum;		    //录像信道配置数
	u8     m_byPlayChnnlNum;		//放像信道配置数
	u8     m_bSupportPublic;       // 是否支持发布(TRUE: 支持, FALSE:不支持)
    u32    m_dwFreeSpace;          //录像机剩余磁盘空间(单位为MB)
    u32    m_dwTotalSpace;		    //录像机总磁盘空间(单位为MB)
	ERecDvcType m_emType;			//录像机类型（录放像机:0, vrs:1）
	DCTRecChnnlStatus m_atChnnlStatus[DC_MAX_RECCHNNL_NUM];
}
PACKED;

//录像机状态表
struct DCTRecStatusList
{
public:
	DCTRecStatusList()
    {
        memset(this, 0, sizeof(DCTRecStatusList));
    }

	void SetRecNum(u32 dwRecNum)
	{
		m_dwRecNum = MIN(dwRecNum, DC_MAX_REC_NUM);
	}

	u32 GetRecNum()
	{
		return m_dwRecNum;
	}

	void SetRecStatus(u32 dwRecIdx, DCTRecStatus tRecStatus)
	{
		if ( dwRecIdx < DC_MAX_REC_NUM )
		{
		    m_atRecStatus[dwRecIdx] = tRecStatus;
		}
	}
	DCTRecStatus *GetRecStatus(u32 dwRecIdx)
	{
		if ( dwRecIdx < DC_MAX_REC_NUM )
		{
			return &m_atRecStatus[dwRecIdx];
		}

		return NULL;
	}
	void Print()
	{
		Sdk_Printf("———————RecStatusList<%d>———————\n", GetRecNum());
		for (u32 nIdx = 0; nIdx < GetRecNum(); nIdx++)
		{
			m_atRecStatus[nIdx].Print();
		}
	}
private:
	u32 m_dwRecNum;
	DCTRecStatus m_atRecStatus[DC_MAX_REC_NUM];
}
PACKED;

// 电视墙轮询参数 [11/5/2014 panyingnan]
struct DCTTwPollInfo
{
public:
	DCTTwPollInfo()
	{
		clear();
	}
	void clear()
	{
		m_byEqpId = 0;
		m_byTwChnnl = 0;
		m_byIsStartAsPause = 0;
		m_byPollType = 0;
		m_dwPollTimes = 0;
		m_dwReserved = 0;
	}

	u8 GetTwId(){ return m_byEqpId; }
	void SetTwId(u8 byEqpId){ m_byEqpId = byEqpId; }
	u8 GetTwChnnl(){ return m_byTwChnnl; }
	void SetTwChnnl( u8 byTwChnnl ){ m_byTwChnnl = byTwChnnl; }
	u8 GetIsStartAsPause(){ return m_byIsStartAsPause; }
	void SetIsStartAsPause(u8 byIsStartAsPause){m_byIsStartAsPause = byIsStartAsPause;}
	u8 GetPollType(){ return m_byPollType; }
	void SetPollType(u8 byPollType){ m_byPollType = byPollType;}
	u32 GetPollTimes(){ return m_dwPollTimes;}
	void SetPollTimes(u32 dwPollTimes){ m_dwPollTimes = dwPollTimes; }
    
	void Print()
	{
		Sdk_Printf("---------DCTTwPollInfo---------\n");
		Sdk_Printf("EqpId = %d\n", GetTwId());
		Sdk_Printf("TwChnnl = %d\n", GetTwChnnl());
		Sdk_Printf("IsStartAsPause = %d\n", GetIsStartAsPause());
		Sdk_Printf("PollType = %d\n", GetPollType());
		Sdk_Printf("PollTimes = %d\n", GetPollTimes());
	}
private:
	u8 m_byEqpId;//电视墙ID
	u8 m_byTwChnnl;//电视墙通道ID
	u8 m_byIsStartAsPause;//一般填false
	u8 m_byPollType;//轮询类型MODE_VIDEO、MODE_BOTH
	u32 m_dwPollTimes;//轮询次数0~999, 0 为无限次
	u32 m_dwReserved;//保留
}
PACKED;


struct DCTHduChnlVolumeInfo
{
public:
	DCTHduChnlVolumeInfo()
	{
		memset(this, 0, sizeof(DCTHduChnlVolumeInfo));
		m_byVolume = 24;
	}
public:
	 u8 m_byHduId;
	 u8 m_byChnnelId;
	 u8 m_byVolume;
	 BOOL32 m_bIsMute;

	 void Print()
	 {
		 Sdk_Printf("---------DCTHduChnlVolumeInfo---------\n");
		 Sdk_Printf("HduId:%d, ChnnelId:%d, Volume:%d, IsMute: %d\n", m_byHduId, m_byChnnelId, m_byVolume, m_bIsMute);
	 }
}
PACKED;

struct DCTTwPollParam
{
public:
	DCTTwPollInfo m_tPollInfo;//轮询信息
	DCTPollMemberNfy m_tPollMember;//轮询终端
	DCTMtPollParam m_tCurPollMt;//当前被轮询的终端
	u8 m_byPollState;//轮询状态
}
PACKED;

// add [8/17/2016 liuxiaolin]
#ifndef _AFXDLL
struct DCTFrameInfo
{
public:
	DCTFrameInfo()
	{
		memset(this, 0, sizeof(DCTFrameInfo));
	}
public:
	u8     m_byMediaType; //媒体类型
	u8    *m_pData;       //数据缓冲
	u32    m_dwPreBufSize;//m_pData缓冲前预留了多少空间，用于加
							// RTP option的时候偏移指针一般为12+4+12
							// (FIXED HEADER + Extence option + Extence bit)
	u32    m_dwDataSize;  //m_pData指向的实际缓冲大小缓冲大小
	u8     m_byFrameRate; //发送帧率,用于接收端
	u32    m_dwFrameID;   //帧标识，用于接收端
	u32    m_dwTimeStamp; //时间戳, 用于接收端
	u32    m_dwSSRC;      //同步源, 用于接收端

	union
	{
		struct{
			BOOL32    m_bKeyFrame;    //频帧类型（I or P）
			u16       m_wVideoWidth;  //视频帧宽
			u16       m_wVideoHeight; //视频帧宽
			BOOL32    m_bHighProfile; // H264 HP标识 - 2012/03/01
		}m_tVideoParam;
		u8    m_byAudioMode;//音频模式
	};
	
}
PACKED;

class CMedianetRcv;

struct DCTRtpRcvObj
{
public:
	DCTRtpRcvObj()
	{
		memset(this, 0, sizeof(DCTRtpRcvObj));
	}

	CMedianetRcv	*m_pRtpRcv; //rtp接收
}
PACKED;

typedef void (*PFRAMECB)(DCTFrameInfo *pFrameInfo, uintptr_t dwContext);

struct DCTCbParamInfo
{
public:
	DCTCbParamInfo()
	{
		memset(this, 0, sizeof(DCTCbParamInfo));
	}

	uintptr_t		dwCbContext;
	PFRAMECB		pFrmCb;

}
PACKED;
#endif



//////////////////
//载荷
struct DCTDoublePayload
{
public:
	u8  m_byRealPayload;    //原媒体格式
	u8  m_byActivePayload;  //活动媒体格式

public:
	DCTDoublePayload()
	{
		memset(this, 0, sizeof(DCTDoublePayload));
	}

}PACKED;

//AAC参数
struct DCTAudAACCap
{
public:
	u8  m_bySampleFreq;		//采样率
	u8  m_byMaxFrameNum;	

public:
	DCTAudAACCap()
	{
		memset(this, 0, sizeof(DCTAudAACCap));
	}

}PACKED;


//监控参数结构
struct DCTMonitorParam
{
public:
	DCTMonitorParam()
	{
		memset(this, 0, sizeof(DCTMonitorParam));
	}

public:
	u32             m_dwLocalIp;        //  本机IP
	u16             m_wLocalPort;       //  接收码流端口
	u8              m_byReal;           //  0-抽帧监控, 1-实时监控
	u8              m_byQuiet;          //  0-不静音, 1-静音
	u8              m_byMode;           //  MODE_BOTH/MODE_VIDEO/MODE_AUDIO
	u32   			m_dwVideoIpAddr;		//视频IP地址, 网络序
	u16 			m_wVideoRtcpPort;		//视频rtcp端口,主机序
	u32				m_dwAudioIpAddr;		//音频IP地址，网络序
	u16				m_wAudioRtcpPort;		//音频rtcp端口，主机序
	u8				m_byChnnlIdx;			//监控通道索引		
	DCTMediaEncrypt		m_tVideoMediaEncrypt;	//视频加密
	DCTMediaEncrypt		m_tAudioMediaEncrypt;	//音频加密
	DCTDoublePayload	m_tVideoPayLoad;		//视频载荷
	DCTDoublePayload	m_tAudioPayLoad;		//音频载荷
	DCTAudAACCap		m_tAudioAAC;			//AAC参数


	void Print()
	{
		Sdk_Printf("---------DCTMonitorParam---------\n");
		Sdk_Printf("chanlIdx:%d, mode:%d\n", m_byChnnlIdx, m_byMode);
		Sdk_Printf("video ip:%u, video rtcp port:%d\n", m_dwVideoIpAddr, m_wVideoRtcpPort);
		Sdk_Printf("audio ip:%u, audio rtcp port:%d\n", m_dwAudioIpAddr, m_wAudioRtcpPort);
		Sdk_Printf("VideoMediaEncrypt mode:%d\n", m_tVideoMediaEncrypt.GetEncryptMode());
		Sdk_Printf("AudioMediaEncrypt mode:%d\n", m_tAudioMediaEncrypt.GetEncryptMode());
		Sdk_Printf("VideoPayLoad real:%d, activate:%d\n", m_tVideoPayLoad.m_byRealPayload, m_tVideoPayLoad.m_byActivePayload);
		Sdk_Printf("AudioPayLoad real:%d, activate:%d\n", m_tAudioPayLoad.m_byRealPayload, m_tAudioPayLoad.m_byActivePayload);
		Sdk_Printf("AudioAAC SampleFreq:%d, MaxFrameNum:%d\n", m_tAudioAAC.m_bySampleFreq, m_tAudioAAC.m_byMaxFrameNum);
	}
}
PACKED;


struct DCTRollCallNotify
{
public:
	s8	m_achConfE164[DC_MAXLEN_ConfE164+1];    //会议的E164号码
	u8  m_byMode;								//点名模式
	DCTMtInfo   m_tCaller;						//点名人
	DCTMtInfo	m_tCalled;						//被点名人

public:
	DCTRollCallNotify()
	{
		memset(this, 0, sizeof(DCTRollCallNotify));
	}

	void Print() const
	{
		Sdk_Printf("-----DCTRollCallNotify-----\n");
		Sdk_Printf("ConfE164:%s\n", m_achConfE164);
		Sdk_Printf("RollCall Mode:%d\n", m_byMode);
		Sdk_Printf("CallerInfo: alias:%s, mcuIdx:%d, subtype:%d\n", 
			m_tCaller.m_achMtInfo, m_tCaller.m_wMcuIdx, m_tCaller.m_bySubType);
		Sdk_Printf("CalledInfo: alias:%s, mcuIdx:%d, subtype:%d\n", 
			m_tCalled.m_achMtInfo, m_tCalled.m_wMcuIdx, m_tCalled.m_bySubType);
		
	}
}
PACKED;


//TODO Add by LYJ
//      Swig Used

//测试字节对齐方式
inline void SizeOfDCTMcsInfo(const DCTMcsInfo& mcsInfo)
{
	printf("****sizeof(DCTMcsInfo)=%ld, sizeof(mcsInfo)=%ld\n", sizeof(DCTMcsInfo), sizeof(mcsInfo));
    printf("****IN Param DCTMcsInfo={%s, %d, %d}\n",
                mcsInfo.m_LogPath, mcsInfo.m_byLogFileNum, mcsInfo.m_dwFileSize);
}

//计算 DCTMcsInfo 数据结构大小
inline size_t SizeofDCTMcsInfo() { return sizeof(DCTMcsInfo); }

//计算 DCTMtStatus 数据结构大小
inline size_t SizeofDCTMtStatus() { return sizeof(DCTMtStatus); }

//计算 DCTMtAudMuteNotify 数据结构大小
inline size_t SizeofDCTMtAudMuteNotify() { return sizeof(DCTMtAudMuteNotify); }

#endif