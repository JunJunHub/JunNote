#ifndef _DC_CONST_H_
#define _DC_CONST_H_

#define MAX_LEN_CALLID					32
#define MAX_LEN_CALL_ALIAS				64
#define MAX_LEN_PRODUCT_ID				128
#define MAX_LEN_VERSION_ID				128
#define MAX_AUDIO_NUM					5
#define MAX_VIDEO_NUM					5
#define MAX_ENCRYPT_KEY_LEN				128
#define MAX_LEN_EPID					64
#define MAX_ALIAS_NUM					64
#define MAX_E164_NUM					64
#define MAX_CONFMT_NUM					192
#define MAX_TERMINALID_LEN				128
#define MAX_PASSWD_LEN					128

#define DC_FLOWDISP_SEE					1				//视频码流交换选看				
#define DC_FLOWDISP_VMP					2				//视频码流交换画面合成
#define DC_FLOWDISP_MIX					2				//音频码流交换混音-->和业务统一

#define DC_FLOWDISP_MAINVID				1				//主流
#define DC_FLOWDISP_SECVID				2				//辅流

#define MAX_CONFPOLL_TIMES              999             // 最大轮询次数 [5/13/2014 panyingnan]
//最大最小轮询间隔常量
#define DC_MIN_MTPOLLTIME				    (u16)5//  [5/14/2014 panyingnan]
#define DC_MAX_MTPOLLTIME				    (u16)7200//  [5/14/2014 panyingnan]
#define DC_MAX_POLLHDU_TIME                 (u16)3600// Hdu轮询最大间隔 [11/10/2014 panyingnan]
#define DC_MAX_RECORDNAME_LEN            64//最大录像文件名长度 [6/11/2014 panyingnan]
#define DC_MAX_RECCHNNL_NUM              32//录像机最大通道数

#define		DC_CONFPOLL_MODE					1	//会议轮询模式
#define		DC_CHAIRMANPOLL_MODE				2	//主席轮询模式	

//传送图像声音参数模式
#define		DC_MODE_NONE			             0	  //音视频都不传
#define		DC_MODE_VIDEO						 1	  //只传视频（轮询视频：只给本地广播）
#define		DC_MODE_AUDIO						 2	  //只传音频
#define		DC_MODE_BOTH						 3    //音视频都传（轮询发言人：只给本地广播）
#define     DC_MODE_VIDEO_CHAIRMAN				10    //只传视频  （主席轮询）
#define     DC_MODE_BOTH_CHAIRMAN				11    //音视频都传（主席轮询）

//广播源
typedef enum
{
	emSpeaker = 0,            //发言人音视频
	emVmp     = 1,            //画面合成
	emMix     = 2             //混音
}EmBrstSrc;

/*媒体类型定义*/
#define   MEDIA_TYPE_NULL                 (u8)255  /*媒体类型为空*/
	
/*音频*/
#define	  MEDIA_TYPE_MP3	              (u8)96  /*mp3 mode 0-4*/
#define   MEDIA_TYPE_G7221C	              (u8)98  /*G722.1.C Siren14*/
#define   MEDIA_TYPE_G719	              (u8)99  /*G719 non-standard of polycom serial 22*/
#define   MEDIA_TYPE_PCMA		          (u8)8   /*G.711 Alaw  mode 5*/
#define   MEDIA_TYPE_PCMU		          (u8)0   /*G.711 ulaw  mode 6*/
#define   MEDIA_TYPE_G721		          (u8)2   /*G.721*/
#define   MEDIA_TYPE_G722		          (u8)9   /*G.722*/
#define	  MEDIA_TYPE_G7231		          (u8)4   /*G.7231*/
#define   MEDIA_TYPE_ADPCM                (u8)5   /*DVI4 ADPCM*/
#define	  MEDIA_TYPE_G728		          (u8)15  /*G.728*/
#define	  MEDIA_TYPE_G729		          (u8)18  /*G.729*/
#define   MEDIA_TYPE_G7221                (u8)13  /*G.7221*/
#define   MEDIA_TYPE_AACLC                (u8)102 /*AAC LC*/
#define   MEDIA_TYPE_AACLD                (u8)103 /*AAC LD*/

/*视频*/
#define   MEDIA_TYPE_MP4	              (u8)97  /*MPEG-4*/
#define   MEDIA_TYPE_H261	              (u8)31  /*H.261*/
#define   MEDIA_TYPE_H262	              (u8)33  /*H.262 (MPEG-2)*/
#define   MEDIA_TYPE_H263	              (u8)34  /*H.263*/
#define   MEDIA_TYPE_H263PLUS             (u8)101 /*H.263+*/
#define   MEDIA_TYPE_H264	              (u8)106 /*H.264*/
#define	  MEDIA_TYPE_FEC					(u8)107 /* fec custom define */

/*数据*/
#define   MEDIA_TYPE_H224	              (u8)100  /*H.224 Payload 暂定100*/
#define   MEDIA_TYPE_T120                 (u8)200  /*T.120媒体类型*/
#define   MEDIA_TYPE_H239                 (u8)239  /*H.239数据类型 */
#define   MEDIA_TYPE_MMCU                 (u8)120  /*级联数据通道 */
	

/*kdv约定的本地发送时使用的活动媒体类型 */
#define   ACTIVE_TYPE_PCMA		          (u8)110   /*G.711 Alaw  mode 5*/
#define   ACTIVE_TYPE_PCMU		          (u8)111   /*G.711 ulaw  mode 6*/
#define   ACTIVE_TYPE_G721		          (u8)112   /*G.721*/
#define   ACTIVE_TYPE_G722		          (u8)113   /*G.722*/
#define	  ACTIVE_TYPE_G7231		          (u8)114   /*G.7231*/
#define	  ACTIVE_TYPE_G728		          (u8)115   /*G.728*/
#define	  ACTIVE_TYPE_G729		          (u8)116   /*G.729*/
#define   ACTIVE_TYPE_G7221               (u8)117   /*G.7221*/
#define   ACTIVE_TYPE_H261	              (u8)118   /*H.261*/
#define   ACTIVE_TYPE_H262	              (u8)119   /*H.262 (MPEG-2)*/
#define   ACTIVE_TYPE_H263	              (u8)120   /*H.263*/
#define   ACTIVE_TYPE_G7221C			  (u8)121	/*G7221c*/
#define   ACTIVE_TYPE_ADPCM				  (u8)122	/*ADPCM*/	
	//  [3/5/2012 wangshengke]
#define   ACTIVE_TYPE_G719	              (u8)123   /*H.719*/
#define   ACTIVE_TYPE_AACLC					(u8)102	/*AACLC*/
#define   ACTIVE_TYPE_AACLD					(u8)103	/*AACLD*/

//设备主类定义
#define		TYPE_MCU                     	 1   //MCU
#define		TYPE_MCUPERI                     2   //MCU外设
#define		TYPE_MT                          3   //终端

//设备子类型
#define		DC_MT_TYPE_NONE                 (u8)0   //不接收也不发送
#define     DC_MT_TYPE_MT                   (u8)3	//终端
#define		DC_MT_TYPE_MMCU	                (u8)4   //上级MCU
#define     DC_MT_TYPE_SMCU                 (u8)5   //下级MCU

//设备子类定义---外设类型定义
#define		EQP_TYPE_MIXER                   1   //混音器
#define		EQP_TYPE_VMP                     2   //图像合成器
#define		EQP_TYPE_RECORDER                3   //录像机
#define		EQP_TYPE_BAS                     4   //码流适配器
#define		EQP_TYPE_TVWALL                  5   //电视墙
#define		EQP_TYPE_DCS                     6   //数据服务器
#define     EQP_TYPE_PRS                     7   //包重传
#define     EQP_TYPE_FILEENC                 8   //文件编码器
#define		EQP_TYPE_VMPTW                   9   //图像合成电视墙
					
//视频格式定义
#define     VIDEO_FORMAT_NULL               255 //无效分辨率
#define		VIDEO_FORMAT_SQCIF				1   //SQCIF(128*96)
#define		VIDEO_FORMAT_QCIF				2   //SCIF(176*144)
#define		VIDEO_FORMAT_CIF                3   //CIF(352*288)  - P制
#define     VIDEO_FORMAT_2CIF               4   //2CIF(352*576) - p
#define		VIDEO_FORMAT_4CIF               5   //4CIF(704*576) - P制(H264下此宏指代D1(720*576)   - P制（N制D1：720*480）)
#define		VIDEO_FORMAT_16CIF				6   //16CIF(1408*1152)
#define		VIDEO_FORMAT_AUTO				7   //自适应，仅用于MPEG4

#define		VIDEO_FORMAT_SIF                8   //SIF(352*240)  - N制
#define     VIDEO_FORMAT_2SIF               9   //2SIF
#define		VIDEO_FORMAT_4SIF               10  //4SIF(704*480) - N制
#define     VIDEO_FORMAT_VGA                11  //VGA(640*480)
#define		VIDEO_FORMAT_SVGA               12  //SVGA(800*600)
#define		VIDEO_FORMAT_XGA                13  //XGA(1024*768)


//仅用于终端分辨率改变
#define		VIDEO_FORMAT_SQCIF_112x96       21  //SQCIF(112*96)
#define		VIDEO_FORMAT_SQCIF_96x80        22  //SQCIF(96*80)

// 高清分辨率
#define     VIDEO_FORMAT_W4CIF              31  //Wide 4CIF(1024*576)
#define     VIDEO_FORMAT_HD720              32  //720 1280*720
#define     VIDEO_FORMAT_SXGA               33  //SXGA 1280*1024
#define     VIDEO_FORMAT_UXGA               34  //UXGA 1600*1200
#define     VIDEO_FORMAT_HD1080             35  //1080  1920*1088(p) 1920*544(i)
//#define     VIDEO_FORMAT_WXGA               36  //WXGA 1280*800

// FROM KDV-HD

//非标分辨率（1080p底图）－用于终端分辨率改变
#define     VIDEO_FORMAT_1440x816           41  //1440×816(3/4)
#define     VIDEO_FORMAT_1280x720           42  //1280×720(2/3)
#define     VIDEO_FORMAT_960x544            43  // 960×544(1/2)
#define     VIDEO_FORMAT_640x368            44  // 640×368(1/3)
#define     VIDEO_FORMAT_480x272            45  // 480×272(1/4)

//非标分辨率（720p底图） －用于终端分辨率改变
#define     VIDEO_FORMAT_720_960x544        51  //960×544(3/4)
#define     VIDEO_FORMAT_720_864x480        52  //864×480(2/3)
#define     VIDEO_FORMAT_720_640x368        53  //640×368(1/2)
#define     VIDEO_FORMAT_720_432x240        54  //432×240(1/3)
#define     VIDEO_FORMAT_720_320x192        55  //320×192(1/4)

//上层视频帧率定义
#define     VIDEO_FPS_2997_1                1   //30 帧/s
#define     VIDEO_FPS_25                    2   //25 帧/s(底层按30帧处理)
#define     VIDEO_FPS_2997_2                3   //15 帧/s
#define     VIDEO_FPS_2997_3                4   //10 帧/s
#define     VIDEO_FPS_2997_4                5   //7.5帧/s
#define     VIDEO_FPS_2997_5                6   //6  帧/s
#define     VIDEO_FPS_2997_6                7   //5  帧/s
#define     VIDEO_FPS_2997_30               8   //1  帧/s
#define     VIDEO_FPS_2997_7P5              9   //4  帧/s
#define     VIDEO_FPS_2997_10               10  //3  帧/s
#define     VIDEO_FPS_2997_15               11  //2  帧/s
#define     VIDEO_FPS_20                    12  //20 帧/s
#define     VIDEO_FPS_USRDEFINED            128 //自定义帧率(>=128,减去128即为实际帧率)

//自定义帧率
#define     VIDEO_FPS_USRDEFINED_ERROR      255

#define     VIDEO_FPS_USRDEFINED_1          1   //1 帧/s
#define     VIDEO_FPS_USRDEFINED_2          2   //2 帧/s
#define     VIDEO_FPS_USRDEFINED_3          3   //3 帧/s
#define     VIDEO_FPS_USRDEFINED_4          4   //4 帧/s
#define     VIDEO_FPS_USRDEFINED_5          5   //5 帧/s
#define     VIDEO_FPS_USRDEFINED_6          6   //6 帧/s
#define     VIDEO_FPS_USRDEFINED_7P5        7   //7.5 帧/s
#define     VIDEO_FPS_USRDEFINED_10         10  //10 帧/s
#define     VIDEO_FPS_USRDEFINED_15         15  //15 帧/s
#define     VIDEO_FPS_USRDEFINED_20         20  //20 帧/s
#define     VIDEO_FPS_USRDEFINED_25         25  //25 帧/s(底层按30帧处理)
#define     VIDEO_FPS_USRDEFINED_30         30  //30 帧/s
#define     VIDEO_FPS_USRDEFINED_60         60  //60 帧/s

//视频双流类型定义
#define		VIDEO_DSTREAM_H263PLUS			0   //H263＋
#define		DC_VIDEO_DSTREAM_MAIN			1   //与主视频格式一致
#define		VIDEO_DSTREAM_H263PLUS_H239     2   //H263＋的H239
#define		VIDEO_DSTREAM_H263_H239         3   //H263的H239
#define		VIDEO_DSTREAM_H264_H239         4   //H264的H239
#define     VIDEO_DSTREAM_H264              5   //H264

//会议创建方式
#define		DC_CONF_CREATE_MT                  251 //会议由终端创建
#define		DC_CONF_CREATE_SCH                 252 //会议由预约会议创建
#define		CONF_CREATE_MCS                 0   //会议由会控创建
#define     DC_CONF_CREATE_NPLUS               253 //会议由N+1备份创建，此标识在mcu创会时不保存到文件，即不进行会议恢复

//会议开放方式定义
#define		CONF_OPENMODE_CLOSED             0  //不开放,拒绝列表以外的终端
#define		CONF_OPENMODE_NEEDPWD            1  //根据密码加入
#define		CONF_OPENMODE_OPEN               2  //完全开放 

//会议加密方式定义
#define     CONF_ENCRYPTMODE_NONE            0 //不加密
#define     CONF_ENCRYPTMODE_DES             1 //des加密
#define     CONF_ENCRYPTMODE_AES             2 //aes加密

//会议码流转发时是否支持归一化整理方式定义, 与丢包重传方式以及加密方式互斥
#define     CONF_UNIFORMMODE_NONE            0 //不归一化重整
#define     CONF_UNIFORMMODE_VALID           1 //  归一化重整

#define     SWITCHCHANNEL_UNIFORMMODE_NONE   0 //不归一化重整
#define     SWITCHCHANNEL_UNIFORMMODE_VALID  1 //  归一化重整

#define     INVALID_PAYLOAD                  0xFF

//数据会议方式定义
#define		CONF_DATAMODE_VAONLY             0  //不包含数据的视音频会议
#define		CONF_DATAMODE_VAANDDATA          1  //包含数据的视音频会议
#define		CONF_DATAMODE_DATAONLY           2  //不包含视音频的数据会议

//会议结束方式定义
#define     CONF_RELEASEMODE_NONE            0  //不会自动结束
#define     CONF_RELEASEMODE_NOMT            1  //无终端时自动结束

//会议进行方式
#define     CONF_TAKEMODE_SCHEDULED          0  //预约会议
#define     CONF_TAKEMODE_ONGOING            1  //即时会议
#define     CONF_TAKEMODE_TEMPLATE           2  //会议模板

//会议保护方式
#define		CONF_LOCKMODE_NONE               0  //未保护
#define		CONF_LOCKMODE_NEEDPWD            1  //根据密码操作
#define		CONF_LOCKMODE_LOCK               2  //独享 

//发言人的源的定义
#define		CONF_SPEAKERSRC_SELF             0  //看自己
#define		CONF_SPEAKERSRC_CHAIR            1  //看主席
#define		CONF_SPEAKERSRC_LAST             2  //看上一次发言人

//呼叫终端方式定义
#define		CONF_CALLMODE_NONE               0  //手动呼叫
#define		CONF_CALLMODE_TIMER              2  //定时呼叫

//定时呼叫终端时间间隔定义
#define		DEFAULT_CONF_CALLINTERVAL        20 //缺省的定时呼叫间隔（秒）
#define		MIN_CONF_CALLINTERVAL            10 //最小的定时呼叫间隔（秒）

//定时呼叫终端呼叫次数定义
#define		DEFAULT_CONF_CALLTIMES           0  //无穷次定时呼叫次数
#define		MIN_CONF_CALLTIMES               2  //最小的定时呼叫次数
//chenwc[2011/05/10] 取消无限次呼叫
#define		DEFAULT_MAX_CONF_CALLTIMES		 11

//画面合成方式定义
#define		CONF_VMPMODE_NONE                0  //不进行画面合成
#define		CONF_VMPMODE_CTRL                1  //会控或主席选择成员合成
#define		CONF_VMPMODE_AUTO                2  //MCU自动选择成员合成

//复合电视墙合成方式定义
#define		CONF_VMPTWMODE_NONE              0  //不进行画面合成
#define		CONF_VMPTWMODE_CTRL              1  //会控或主席选择成员合成
#define		CONF_VMPTWMODE_AUTO              2  //MCU自动选择成员合成

//会议录像方式定义 
#define		CONF_RECMODE_NONE                0  //不录像
#define		CONF_RECMODE_REC                 1  //录像
#define		CONF_RECMODE_PAUSE               2  //暂停

//发布方式定义
#define     REC_PUBLISH_MODE_NONE				0	//不发布
#define     REC_PUBLISH_MODE_IMMED				1	//立即发布,新录播直播标志
#define     REC_PUBLISH_MODE_FIN				2	//录像完毕之后发布，新录播发布标志
#define     REC_PUBLISH_MODE_BOTH				3	//直播+发布

//会议放像方式定义
#define		CONF_PLAYMODE_NONE               0  //不放像
#define		CONF_PLAYMODE_PLAY               1  //放像
#define		CONF_PLAYMODE_PAUSE              2  //暂停
#define		CONF_PLAYMODE_FF                 3  //快进
#define		CONF_PLAYMODE_FB                 4  //快退
#define		CONF_PLAYMODE_PLAYREADY			 5	//准备放像

//会议轮询方式定义
#define		CONF_POLLMODE_NONE               0  //不轮询广播 
#define		CONF_POLLMODE_VIDEO              1  //仅图像轮询广播
#define		CONF_POLLMODE_SPEAKER            2  //轮流发言

//码率适配方式定义 -- modify bas 2
#define		CONF_BASMODE_NONE                0  //不进行码率适配
#define		CONF_BASMODE_AUD                 1  //音频适配
#define		CONF_BASMODE_VID                 2  //视频适配
#define		CONF_BASMODE_BR                  3  //码率适配
#define		CONF_BASMODE_CASDAUD             4  //级联回传音频适配
#define		CONF_BASMODE_CASDVID             5  //级联回传视频适配

//会议混音方式的定义
#define     CONF_MIXMODE_NONE                0  //不混音
#define     CONF_MIXMODE_DISC                1  //全体混音
#define     CONF_MIXMODE_SPEC                2  //定制混音
#define     CONF_MIXMODE_VAC                 3  //语音激励

//会议双流发起方式定义
#define		CONF_DUALMODE_SPEAKERONLY		 0	//只能发言人发起
#define		CONF_DUALMODE_EACHMTATWILL		 1	//任意终端都能发起

//轮询状态定义
#define		POLL_STATE_NONE                  0  //未轮询 
#define		POLL_STATE_NORMAL                1  //轮询正常
#define		POLL_STATE_PAUSE                 2  //轮询暂停

//画面合成状态定义
#define     VMP_STATE_START                  1  //开始
#define     VMP_STATE_CHANGE                 2  //改变
#define     VMP_STATE_STOP                   3  //停止

//复合电视墙合成状态定义
#define     VMPTW_STATE_START                1  //开始
#define     VMPTW_STATE_CHANGE               2  //改变
#define     VMPTW_STATE_STOP                 3  //停止

//画面合成状态定义
#define     TW_STATE_START                  1  //开始
#define     TW_STATE_CHANGE                 2  //改变
#define     TW_STATE_STOP                   3  //停止

//电视墙成员类型定义
#define		TW_MEMBERTYPE_MCSSPEC            1  //会控指定 
#define		TW_MEMBERTYPE_SPEAKER            2  //发言人跟随
#define		TW_MEMBERTYPE_CHAIRMAN           3  //主席跟随
#define		TW_MEMBERTYPE_POLL               4  //轮询视频跟随
#define		TW_MEMBERTYPE_TWPOLL             5	//电视墙轮询
#define     TW_MEMBERTYPE_SWITCHVMP          6  //选看vmp
#define     TW_MEMBERTYPE_BATCHPOLL          7  //批量轮询
#define     TW_MEMBERTYPE_VCSAUTOSPEC        8  //VCS自动指定 
#define		TW_MEMBERTYPE_VCSSPEC			 9	//VCS指定
#define     TW_MEMBERTYPE_DOUBLESTREAM       10 //双流进电视墙

//画面合成成员类型定义
#define		VMP_MEMBERTYPE_NULL				 0  //没有指定成员
#define		VMP_MEMBERTYPE_MCSSPEC           1  //会控指定 
#define		VMP_MEMBERTYPE_SPEAKER           2  //发言人跟随
#define		VMP_MEMBERTYPE_CHAIRMAN          3  //主席跟随
#define		VMP_MEMBERTYPE_POLL              4  //轮询视频跟随
#define		VMP_MEMBERTYPE_VAC               5	//语音激励(会控不要用此类型)
#define		VMP_MEMBERTYPE_VIP				 6	//VIP终端(行业版本需要用到)

//画面合成风格定义
#define		VMP_STYLE_DYNAMIC                0   //动态分屏(仅自动合成时有效)
#define		VMP_STYLE_ONE                    1   //一画面
#define		VMP_STYLE_VTWO                   2   //两画面：左右分 
#define		VMP_STYLE_HTWO                   3   //两画面: 一大一小
#define		VMP_STYLE_THREE                  4   //三画面
#define		VMP_STYLE_FOUR                   5   //四画面
#define		VMP_STYLE_SIX                    6   //六画面 
#define		VMP_STYLE_EIGHT                  7   //八画面
#define		VMP_STYLE_NINE                   8   //九画面
#define		VMP_STYLE_TEN                    9   //十画面(左2右10)
#define		VMP_STYLE_THIRTEEN               10  //十三画面
#define		VMP_STYLE_SIXTEEN                11  //十六画面
#define		VMP_STYLE_SPECFOUR               12  //特殊四画面 
#define		VMP_STYLE_SEVEN                  13  //七画面
#define		VMP_STYLE_TWENTY				 14  //二十画面
#define		VMP_STYLE_TEN_H  				 15  //水平分割的十画面(上2下8)
#define     VMP_STYLE_SIX_L2UP_S4DOWN        16  //特殊六画面(上2下4)  
#define     VMP_STYLE_FOURTEEN               17  //十四画面
#define     VMP_STYLE_TEN_M                  18  //十画面(上4中2下4)
#define     VMP_STYLE_THIRTEEN_M             19  //十三画面(一大在中间)
#define     VMP_STYLE_FIFTEEN                20  //十五画面
#define     VMP_STYLE_SIX_DIVIDE             21  //六画面(等分)
#define     VMP_STYLE_AUTO                   22  //自动画面合成（根据终端数自动选择）
#define		DC_VMPSTYLE_NUMBER				(VMP_STYLE_SIX_DIVIDE+1)
#define     VMP_STYLE_TWENTYFIVE			 27  //二十五画面
#define     VMP_STYLE_NONE                  0xff //不支持的格式



//复合电视墙合成成员类型定义
#define		VMPTW_MEMBERTYPE_MCSSPEC         1  //会控指定 
#define		VMPTW_MEMBERTYPE_SPEAKER         2  //发言人跟随
#define		VMPTW_MEMBERTYPE_CHAIRMAN        3  //主席跟随
#define		VMPTW_MEMBERTYPE_POLL            4  //轮询视频跟随
#define		VMPTW_MEMBERTYPE_VAC             5	//语音激励(会控不要用此类型)

#define		MAXLEN_ALIAS			        128  //MCU或终端假名最多127个字母，63个汉字
#define     VALIDLEN_ALIAS                  16   //有效别名它度
#define		MAXLEN_CONFNAME                 64   //会议名最大长度
#define		MAXLEN_PWD                      32   //最大密码长度  
#define		MAXLEN_IP						32	 //最大IP长度
#define		PORT							60000	//端口号默认值
 
#define		MAXLEN_E164                     16   //最大E164号码长度 
#define     MAXLEN_KEY                      16   //最大的加密key长度
#define		LEN_E164PRE						6	 //E164号固定前缀长度（3位区号+三位TUIID）
//conf id len
#define     MAXLEN_CONFID                   16
#define     LOCAL_MCUID                     192  //本地MCU ID 

#define     MAXNUM_PERIEQP_CHNNL			16	//电视墙通道最大数
#define     MAXNUM_MIXER_DEPTH				10  //混音器最大混音深度
#define     MAXNUM_MIXER_DEPTH_8000B        8   //8000B混音器最大混音深度
#define     MAXNUM_MIXER_DEPTH_8000B_G729   4   //8000B G.729混音器最大混音深度


//双流百分比最大最小值
#define     MAXNUM_DSTREAM_SCALE            90
#define     MINNUM_DSTREAM_SCALE            10
#define     DEF_DSTREAM_SCALE               30


// 终端视频源个数及视频源别名长度
const int    DC_MT_MAXNUM_VIDSOURCE        =   10;            // 最大视频源数
const int    DC_MT_MAX_PORTNAME_LEN        =   16;            // 视频矩阵端口名最大长度

// GK用户名和密码长度宏定义
#define     MAX_LEN_GK_USRNAME              (u8)16
#define     MAX_LEN_GK_PWD                  (u8)16

// 音量类型宏定义
#define     VOLUME_TYPE_OUT                 (u8)0   //终端输出音量
#define     VOLUME_TYPE_IN                  (u8)1   //终端输入音量


//摄像头控制参数定义
#define     CAMERA_CTRL_UP					1   //上
#define     CAMERA_CTRL_DOWN				2   //下
#define     CAMERA_CTRL_LEFT				3   //左
#define     CAMERA_CTRL_RIGHT				4   //右
#define     CAMERA_CTRL_UPLEFT				5   //上左
#define     CAMERA_CTRL_UPRIGHT				6   //上右
#define     CAMERA_CTRL_DOWNLEFT			7   //下左
#define     CAMERA_CTRL_DOWNRIGHT			8   //下右
#define     CAMERA_CTRL_ZOOMIN				9   //视野小
#define     CAMERA_CTRL_ZOOMOUT				10  //视野大
#define     CAMERA_CTRL_FOCUSIN				11  //调焦短
#define     CAMERA_CTRL_FOCUSOUT			12  //调焦长
#define     CAMERA_CTRL_BRIGHTUP			13  //亮度加
#define     CAMERA_CTRL_BRIGHTDOWN			14  //亮度减
#define     CAMERA_CTRL_AUTOFOCUS			15  //自动调焦
// MCU前向纠错能力集类型, zgc, 2007-09-26
#define		FECTYPE_NONE					(u8)(0x00)
#define		FECTYPE_RAID5					(u8)(0x01)
#define		FECTYPE_RAID6					(u8)(0x02)

// 开关常量
enum DCSwitchConstant
{
	emturn_on,		//开启
	emturn_off		//关闭
};

// 轮询类型
enum DCPollType
{
	empoll_none,		//没有轮询
	empoll_vcb,		//轮流广播
	empoll_vcs		//轮流选看
};

enum DCPollStatus
{
	empoll_status_none,    //未轮询
	empoll_status_normal,  //轮询进行中
	empoll_status_pause    //轮询暂停
};

//操作类型宏定义
enum DCOprType
{
    emopr_start,
    emopr_stop
};

enum DCDsRcvType
{
	emDCPresent = 0,				//静态双流
	emDCLive,						//动态双流
	emDCDsRcvTypeEnd
};

// H264画质属性(HP/BP)// [7/17/2012 xliang] support HP
enum DCProfileAttrb
{
	emDCBpAttrb,	//BP
	emDCHpAttrb,	//HP
};

//视频类型
enum DCVideoType
{
	emDCMainVideo,  //主视频
	emDCSecondVideo //辅视频
};

//码流交换动作类型
enum DCFlowDispType
{
	emStartFlowDisp, //开始码流交换
	emStopFlowDisp   //停止码流交换
};

//画面合成类型
enum DCVmpStyle
{
	emAutoVmp,   //自动画面合成
	emManualVmp  //手动画面合成
};

//混音类型
enum DCMixerStyle
{
	emAutoMixer,   //自动混音
	emManualMixer  //手动混音
};

enum DCBroadcastStyle
{
	emStartBrdcast = 1, //开始广播
	emStopBrdcast       //停止广播
};

#ifdef WIN32
    #pragma comment( lib, "ws2_32.lib" ) 
    #pragma pack( push )
    #pragma pack( 1 )
    #define window( x )	x
    #define PACKED
    #pragma pack( pop )  //Add by wq[2013-6-14] 这段代码中无结构体，可以不需要使用该字节对齐
#else
    #include <netinet/in.h>
    #define window( x )
#if defined(__ETI_linux__)
    #define PACKED
#else
    //TODO
    //add by lyj
    //SWIG 转换不支持 __attribute__((__packed__)), 通过 #pragma pack(1) 设置1字节对齐
    #pragma pack(1)
	#define PACKED
    //#define PACKED __attribute__((__packed__))	// 取消编译器字节对齐优化
#endif
#endif

// 终端滚动消息定义
//////////////////////////////////////////////////////////////////////////

// 滚动消息类型
#define ROLLMSG_TYPE_SMS		0	// 短消息
#define ROLLMSG_TYPE_PAGETITLE	1	// 翻页字幕
#define ROLLMSG_TYPE_ROLLTITLE	2	// 滚动字幕
#define ROLLMSG_TYPE_STATICTEXT	3	// 静态文本

// 滚动消息内容
#define MAX_ROLLMSG_LEN		2048	// 最大2K字节

// 滚动速度
#define ROLL_SPEED_1	1	// 最慢
#define ROLL_SPEED_2	2	// 稍慢
#define ROLL_SPEED_3	3	// 中速
#define ROLL_SPEED_4	4	// 稍快
#define ROLL_SPEED_5	5	// 最快

// 无限制滚动
#define ROLL_INFINIT	0xFF

// 消息头结构: 消息类型(1)+滚动次数(1)+滚动速度(1)+源终端(2)+目的终端个数(2)+滚动消息长度(2)+整个消息长度(2)
// 消息体: 用户给出的目的终端列表+滚动消息内容
#define ROLLMSG_MSGHEAD_LEN					11
#define ROLLMSG_MSGHEAD_ROLLTYPE_OFFSET		0
#define ROLLMSG_MSGHEAD_ROLLTYPE_LEN		1
#define ROLLMSG_MSGHEAD_ROLLTIME_OFFSET		(ROLLMSG_MSGHEAD_ROLLTYPE_OFFSET + ROLLMSG_MSGHEAD_ROLLTYPE_LEN)
#define ROLLMSG_MSGHEAD_ROLLTIME_LEN		1
#define ROLLMSG_MSGHEAD_ROLLRATE_OFFSET		(ROLLMSG_MSGHEAD_ROLLTIME_OFFSET + ROLLMSG_MSGHEAD_ROLLTIME_LEN)
#define ROLLMSG_MSGHEAD_ROLLRATE_LEN		1
#define ROLLMSG_MSGHEAD_SRCMT_OFFSET		(ROLLMSG_MSGHEAD_ROLLRATE_OFFSET + ROLLMSG_MSGHEAD_ROLLRATE_LEN)
#define ROLLMSG_MSGHEAD_SRCMT_LEN			2
#define ROLLMSG_MSGHEAD_DSTMTNUM_OFFSET		(ROLLMSG_MSGHEAD_SRCMT_OFFSET + ROLLMSG_MSGHEAD_SRCMT_LEN)
#define ROLLMSG_MSGHEAD_DSTMTNUM_LEN		2
#define ROLLMSG_MSGHEAD_ROLLMSGLEN_OFFSET	(ROLLMSG_MSGHEAD_DSTMTNUM_OFFSET + ROLLMSG_MSGHEAD_DSTMTNUM_LEN)
#define ROLLMSG_MSGHEAD_ROLLMSGLEN_LEN		2
#define ROLLMSG_MSGHEAD_MSGLEN_OFFSET		(ROLLMSG_MSGHEAD_ROLLMSGLEN_OFFSET + ROLLMSG_MSGHEAD_ROLLMSGLEN_LEN)
#define ROLLMSG_MSGHEAD_MSGLEN_LEN			2
#define ROLLMSG_MSGBODY_OFFSET				ROLLMSG_MSGHEAD_LEN

//消息长度相关
#define      DC_SERV_MSG_LEN					0x7000  //消息长度
#define      DC_SERV_MSGHEAD_LEN				0x10    //消息头长度

//modify by wq[2013-5-13]
#define		DC_MAXLEN_CONFNAME                  64   //会议名最大长度
#define		DC_MAXLEN_ConfE164                  16   //最大E164号码长度 
#define		DC_MAXLEN_ALIAS			            128  //MCU或终端假名最多127个字母，63个汉字
#define		DC_MAXNUM_CONF_MT				    192  //单个会议中最大MT数//扩容后支持248个  [5/14/2014 panyingnan]
#define     DC_MAXNUM_BUFFER                    512  //最大Buffer容量
#define     DC_LOCAL_MCUIDX						19200   //本地MCU IDX				
#define		DC_INVALID_MCUIDX					0xffff	//非法mcuidx号

//会议开放方式定义
#define		DC_CONF_OPENMODE_CLOSED             0  //不开放,拒绝列表以外的终端
#define		DC_CONF_OPENMODE_NEEDPWD            1  //根据密码加入
#define		DC_CONF_OPENMODE_OPEN               2  //完全开放 

//会议双流发起方式定义
#define		DC_CONF_DUALMODE_SPEAKERONLY	    0  //只能发言人发起
#define		DC_CONF_DUALMODE_EACHMTATWILL	    1  //任意终端都能发起

//视频双流类型定义
#define		DC_VIDEO_DSTREAM_H263PLUS			0   //H263＋
#define		DC_VIDEO_DSTREAM_MAIN				1   //与主视频格式一致
#define		DC_VIDEO_DSTREAM_H263PLUS_H239      2   //H263＋的H239
#define		DC_VIDEO_DSTREAM_H263_H239          3   //H263的H239
#define		DC_VIDEO_DSTREAM_H264_H239          4   //H264的H239
#define     DC_VIDEO_DSTREAM_H264               5   //H264

//有关发布方式定义
#define      DC_PUBLISH_MODE_NONE				0	//不发布
#define      DC_PUBLISH_MODE_IMMED				1	//立即发布
#define      DC_PUBLISH_MODE_FIN				2	//录像完毕之后发布

//双流百分比最大最小值
#define     DC_MAXNUM_DSTREAM_SCALE             90
#define     DC_MINNUM_DSTREAM_SCALE             10
#define     DC_DEF_DSTREAM_SCALE                30

//媒体类型定义
#define     DC_MEDIA_TYPE_NULL                  (u8)255  /*媒体类型为空*/

//视频格式定义
#define     DC_VIDEO_FORMAT_NULL                255 //无效分辨率

#define     DC_MAXNUM_VMP_MEMBER			    25  //最大画面合成成员数

#define     MAXNUM_MPUSVMP_MEMBER			    20  //SVMP最大画面合成成员数(针对mpu外设)

#define     MAXNUM_MPU2VMP_MEMBER			    25  //MPU2VMP最大画面合成成员数(针对mpu2外设)

//定义最大路径长度
#define     DC_MAX_PATH                         (u16)256

//mcu名称最大长度
#define     DC_MAXLEN_MCU_NAME                  (s32)64

#define     DC_MAXNUM_MIXER_CHNNL               32  //最大混音通道数
#define     DC_MAXNUM_MIXING_MEMBER             10  //混音器最大混音深度
#define		DC_MAXNUM_MCU_CONF					64  //一个MCU内部同时进行的会议数目//会商支持最多会议128[5/13/2014 panyingnan]
#define     DC_MAXNUM_MCU_TEMCONF               1024//最大模版个数  [5/13/2014 panyingnan]
#define     DC_MAXLEN_CONFID                    16  //会议ID
#define     DC_MAX_SWITCH_CHANNEL				500	//最大交换通道数
#define     DC_MCS_MONITOR_BASE_PORT            (u16)7200// 起始侦听端口
#define     DC_MAX_TVWALL_NUM                   70  //最大电视墙数目
#define     DC_MAX_CONF_NFY_TAB                 350  //最大上报会议列表  因为OSP消息长度不能超过32K 所以不能超过350个

#define     DC_PORTSPAN                         (u16)10     // 端口的间隔
// 每个session占的端口数
#define     DC_MCS_SESSION_PORT_NUM             ((u16)(DC_PORTSPAN*11))
//  会议控制台连接MCU最大数
#define     DC_MAXNUM_MCS_MCU                   (s32)16
// 结束侦听端口
#define     DC_MCS_MONITOR_END_PORT             (u16)65535
#define		DC_MCU_LISTEN_PORT					60000	//缺省外设/会控TCP侦听端口号

// 发送短消息的最大长度 [5/3/2013 yinyujie]
#define		DC_SENDMSG_MAX_LEN					1024

#define     DC_MAX_CONF_BITRATE                 8128    //最大会议码率
#define     DC_MIN_CONF_BITRATE                 64      //最小会议码率

//modify end wq[2013-5-13]

#define     DC_SEE_VMP                          1       //选看VMP
#define     DC_SEE_MIX                          2       //选看MIXER

#define     DC_MAX_REC_NUM                      16      //最大REC数量
#define		DC_MAX_HDUSTYLE_NUM					16		//HDU预案最大方案个数
#define		DC_MAX_HDUSTYLE_ALIASLEN            32		//HDU预案别名最大长度
#define		DC_MAXNUM_HDUCFG_CHNLNUM            56		//界面中HDU可配置的最大通道数
			
#define     DC_DISCONNECT_TIME                  10      //断链检测的时间（s）
#define     DC_DISCONNECT_TIMES                  3      //断链检测的次数

#define     DC_CONNECT_AGAIN_TIMES               3      //断链重连次数
#define     DC_CONNECT_AGAIN_INTERVAL            500    //断链重连间隔时间

#define		DC_MAXLEN_EQP_ALIAS                  16     //外设别名最大长度
#define     DC_DATA_LENGTH                       1024 * 32  //数据长度
#define     DC_MIN_TIMES                         1      //最小滚动次数
#define     DC_MAX_TIMES                         255    //最大滚动次数
#define     DC_MAX_HDU_CHAN                      2// HDU最大通道数 [4/15/2014 panyingnan]

#define		DC_MAX_VMP_NUM						16		//最大VMP数量


#define			INVALID_SESSION_INDEX               ((s32)(-1)) 


// add [8/16/2016 liuxiaolin]
#define MAX_VIDEO_FRAME_SIZE	((s32)512*1024)		//512K
#define MCU_PROT_SPAN			(u16)500	

//终端板类型
//注意：该部分定义永远只能增加，且必须保持行业/企业流一致
#define     DC_MT_BOARD_UNKNOW                 255
#define     DC_MT_BOARD_WIN                    0

// KDV系列终端：1-49
#define     DC_MT_BOARD_8010                   1
#define     DC_MT_BOARD_8010A                  2
#define     DC_MT_BOARD_8018                   3
#define     DC_MT_BOARD_IMT                    4
#define     DC_MT_BOARD_8010C                  5

#define     DC_MT_BOARD_8010A_2                7
#define     DC_MT_BOARD_8010A_4                8
#define     DC_MT_BOARD_8010A_8                9

#define     DC_MT_BOARD_7210                   10
#define     DC_MT_BOARD_7610                   11
#define     DC_MT_BOARD_7810                   12
#define     DC_MT_BOARD_7910                   13

#define		DC_MT_BOARD_5610_KDV			   14
#define		DC_MT_BOARD_6610_KDV			   15

//KDV-T3系列
#define     DC_MT_BOARD_7620_A                 16
#define     DC_MT_BOARD_7620_B                 17


//KDV-二代高清系列
#define     DC_MT_BOARD_7820_A_NOSDI           18
#define     DC_MT_BOARD_7820_B_NOSDI           19
#define     DC_MT_BOARD_7920_A_NOSDI           20
#define     DC_MT_BOARD_7920_B_NOSDI           21
#define     DC_MT_BOARD_7820_A_SDIINOUT        22
#define     DC_MT_BOARD_7820_B_SDIINOUT        23
#define     DC_MT_BOARD_7920_A_SDIINOUT        24
#define     DC_MT_BOARD_7920_B_SDIINOUT        25
#define     DC_MT_BOARD_7820_A_SDIININ         26
#define     DC_MT_BOARD_7820_B_SDIININ         27
#define     DC_MT_BOARD_7920_A_SDIININ         28
#define     DC_MT_BOARD_7920_B_SDIININ         29

#define     DC_MT_BOARD_7820_A					DC_MT_BOARD_7820_A_NOSDI
#define     DC_MT_BOARD_7820_B					DC_MT_BOARD_7820_B_NOSDI
#define     DC_MT_BOARD_7920_A					DC_MT_BOARD_7920_A_NOSDI
#define     DC_MT_BOARD_7920_B					DC_MT_BOARD_7920_B_NOSDI

#define     DC_MT_BOARD_KDVx_END               50
// TS系列：在 51-99 范围中
#define     DC_MT_BOARD_6610                   51
#define     DC_MT_BOARD_6610E                  52
#define     DC_MT_BOARD_6210                   53
#define     DC_MT_BOARD_5210                   54
#define     DC_MT_BOARD_3210                   55 
#define     DC_MT_BOARD_V5                     56
#define     DC_MT_BOARD_3610                   57
#define     DC_MT_BOARD_5610                   58
#define     DC_MT_BOARD_6210E                  59
#define     DC_MT_BOARD_TSx_END                100
#define     DC_MT_BOARD_Vx_END                 150

//终端离线原因
#define		DC_MTLEFT_REASON_NONE				0	 //没有异常
#define     DC_MTLEFT_REASON_EXCEPT             1   //异常：网络或接入或转发
#define     DC_MTLEFT_REASON_NORMAL             2   //正常挂断
#define     DC_MTLEFT_REASON_RTD                3   //RTD超时
#define     DC_MTLEFT_REASON_DRQ                4   //DRQ
#define     DC_MTLEFT_REASON_UNMATCHTYPE        5   //类型不匹配
#define		DC_MTLEFT_REASON_DELETE			    s6   //正常删除
#define     DC_MTLEFT_REASON_UNKNOW             0xff   //未知错误

//终端未加入原因
#define		DC_MTCALLFAILED_REASON_NONE				0	 //没有异常
#define     DC_MTCALLFAILED_REASON_BUSY               6   //终端忙
#define     DC_MTCALLFAILED_REASON_REJECTED           7   //终端主动挂断
#define     DC_MTCALLFAILED_REASON_UNREACHABLE        8   //终端不可达
#define     DC_MTCALLFAILED_REASON_LOCAL              9   //
#define     DC_MTCALLFAILED_REASON_BUSYEXT            10  //终端忙,带终端目前所在会议的级别及会议名称
#define     DC_MTCALLFAILED_REASON_REMOTERECONNECT    11  //本端行政级别低，由远端自动发起重连
#define     DC_MTCALLFAILED_REASON_REMOTECONFHOLDING  12  // 呼叫下级MCU失败，该MCU正在召开其它会议
#define     DC_MTCALLFAILED_REASON_REMOTEHASCASCADED  13  // 呼叫下级MCU失败，该MCU已经被其它高级别MCU呼叫
#define     DC_MTCALLFAILED_REASON_UNKNOW             0xff   //未知错误

#endif
