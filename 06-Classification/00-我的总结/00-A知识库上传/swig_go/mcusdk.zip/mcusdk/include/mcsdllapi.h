/*=======================================================================
模块名      : mcsdll头文件
文件名      : mcsdllapi.h
相关文件    : 
文件实现功能: 声明
作者        : czy
版本        : V1.0  Copyright(C) 1997-2003 KDC, All rights reserved.
-------------------------------------------------------------------------
修改记录:
日  期      版本        修改人      修改内容
2013/12/25	1.0         czy			create
=======================================================================*/
#ifndef MCSDLLAPI_H
#define MCSDLLAPI_H

#ifdef _WIN32
#ifdef MCSDLL_EXPORTS
#define MCSDLL_API	extern "C" __declspec(dllexport)
#else 
#define MCSDLL_API  extern "C" __declspec(dllimport)
#endif
#else
#define MCSDLL_API	extern "C"
#endif

#include "mcsdllstruct.h"

class CMcsCBHandler
{
public:
    //virtual ~CMcsCBHandler() {}
	
	/*=============================================================================
	函 数 名： CBHandle
    功    能： 
    算法实现： 
    全局变量： 
    参    数： u32 dwEventId      消息号;
		       u32 dwMsgBody      消息体;
		       u32 dwMsgLength    消息体大小;
		       u32 nMcuIndex      MCU索引号;
	=============================================================================*/
	virtual u16 CBHandle(u32 dwEventId, uintptr_t dwMsgBody, u32 dwMsgLength, u32 nMcuIndex) = 0;
};

//TODO ADD By LYJ 
//     Swig Used
class CMcsCBCaller {
private:
	CMcsCBHandler *_callback;
public:
	CMcsCBCaller(): _callback(0) {}
	~CMcsCBCaller() { delCallback(); }
	void delCallback() { delete _callback; _callback = 0; }
	void setCallback(CMcsCBHandler *cb) { delCallback(); _callback = cb; }
	u16 call(u32 dwEventId, uintptr_t dwMsgBody, u32 dwMsgLength, u32 nMcuIndex) {
	    if (_callback) {
	        return _callback->CBHandle(dwEventId, dwMsgBody, dwMsgLength, nMcuIndex);
	    } else {
	        return 0;
	    }
	}
};



typedef u16 (*PCBHandle)(u32 dwEventId, uintptr_t dwMsgBody, u32 dwMsgLength, u32 nMcuIndex);

//初始化MCS
MCSDLL_API u16 McsdllInit(const DCTMcsInfo& mcsinfo, u16 wMonitorBasePort = DC_MCS_MONITOR_BASE_PORT);
	
//销毁MCS
MCSDLL_API u16 McsdllQuit();

/************************************************************

  1.连接操作
  
************************************************************/	
// ConnectMcsServerReq接口add nIndex, 取值情况: [9/21/2015 liuxiaolin]
// 1.当mcu未连接，且接口正常返回时，index置-1；
// 2.当mcu未连接，且有异常时，返回错误码，index置-1；
// 3.当mcu已连接，index置 实际分配值，且返回OK；
//[lbl, 20150911, 去掉服务器类型，默认为mcu]
//连接MCS服务器
MCSDLL_API u16 ConnectMcsServerReq(const s8* pchServerIP, const s8* pchUserName, const s8* pchPwd, 
									CMcsCBHandler *pCBHanlder, s32 &nIndex);

//连接MCS服务器
MCSDLL_API u16 ConnectMcsSvrReq(const s8* pchServerIP, const s8* pchUserName, const s8* pchPwd, 
	PCBHandle pCBHanlder, s32 &nIndex);

//断开MCS服务器
MCSDLL_API u16 DisconnectMcsServerReq(s32 nIndex);
	

/************************************************************

  2.会议操作
  
************************************************************/
//创建会议、创建模版//增加参数召开模式以兼容会议模版的创建[5/15/2014 panyingnan]
//CONF_TAKEMODE_ONGOING    1  //即时会议 
//CONF_TAKEMODE_TEMPLATE   2  //会议模板  
MCSDLL_API u16 CreateConfReqbyMCS(const DCTConfInfo &dctConfInfo, u8 byTakeMode, s32 nIndex);

//结束会议、删除模版//增加参数召开模式以兼容会议模版的删除[5/15/2014 panyingnan]
//CONF_TAKEMODE_ONGOING    1  //即时会议 
//CONF_TAKEMODE_TEMPLATE   2  //会议模板  
MCSDLL_API u16 ReleaseConfReqbyMCS(const s8* pchConfE164ID, u8 byTakeMode, s32 nIndex);

//获取会议信息
MCSDLL_API u16 GetConfInfobyMCS(const s8 * pchConfE164ID, 
								DCTConfInfoInConfTable &dctConfInfoInConfTable, s32 nIndex);

//获取会议模式
MCSDLL_API u16 GetConfMode(const s8* pchConfE164ID, 
						   DCTConfMode& dctConfMode, s32 nIndex);

//获取会议模版列表[5/15/2014 panyingnan]
MCSDLL_API u16 GetConfTemTablebyMCS(DCTConfTemTable &dctConfTable, s32 nIndex);

//获取单个会议模版信息[5/15/2014 panyingnan]
MCSDLL_API u16 GetConfTemInfobyMCS(const s8 * pchConfE164ID, 
								   DCTConfInfoInConfTable &dctConfInfoInConfTable, s32 nIndex);
//通过个人模板创会[7/20/2016 wangli]
MCSDLL_API u16 CreateTemConfbyMCS(const s8* pchConfE164ID, s32 nIndex);

// 获取录像机状态列表 [6/10/2014 panyingnan]
MCSDLL_API u16 GetRecStatusListbyMCS(DCTRecStatusList *ptRecStatusList, s32 nIndex);

//获取画面合成状态
MCSDLL_API u16 GetConfVmpStatusbyMCS(const s8* pchConfE164ID,
									 DCTConfVmpStatus &dctConfVmpStatus, s32 nIndex);

//获取会议画面合成状态列表
MCSDLL_API u16 GetConfVmpStatusListbyMCS(const s8* pchConfE164ID,  DCTVmpStatusList *ptVmpStatusList, s32 nIndex);

//获取会议MIX状态
MCSDLL_API u16 GetConfMixStatusbyMCS(const s8* pchConfE164ID, 
									 DCTConfMixStatus &dctConfMixStatus, s32 nIndex);


//获取会议录像进度信息 [daishangwei 2014/10/31] 接口暂时没用
MCSDLL_API u16 GetConfRecProgStatusbyMCS(const s8* pchConfE164ID,
						  		    DCTConfRecProgStatus &dctConfRecProgStatus, s32 nIndex);


//开始、停止会议轮询、获取轮询参数
/*
const s8* pchConfE164ID             [in]    会议号
u8 byPollType                       [in]    轮循类型(会议轮询：DC_MODE_VIDEO、DC_MODE_BOTH；主席轮询：DC_MODE_VIDEO_CHAIRMAN、DC_MODE_BOTH_CHAIRMAN)
u32 dwPollTimes                     [in]    轮询次数(0~999 MAX_CONFPOLL_TIMES, 0表示不自动停止)
DCTMtPollParam atMtInfo[DC_MAXNUM_CONF_MT]                [in]    轮循终端数组
u16 wMtNum                          [in]    轮循终端数
u8 byPollMode						[in]	1:会议轮询 2:主席轮询
s32 nIndex                          [in]    索引
*/
MCSDLL_API u16 StartConfPollCmd(const s8* pchConfE164ID, u8 byPollType, u32 dwPollTimes, 
								DCTMtPollParam atMtInfo[DC_MAXNUM_CONF_MT], u16 wMtNum, u8 byPollMode, s32 nIndex);
MCSDLL_API u16 PauseConfPollCmd(const s8* pchConfE164ID, s32 nIndex);
MCSDLL_API u16 ResumeConfPollCmd(const s8* pchConfE164ID, s32 nIndex);
MCSDLL_API u16 StopConfPollCmd(const s8* pchConfE164ID, s32 nIndex);
MCSDLL_API u16 GetConfPollParamReq(const s8* pchConfE164ID, s32 nIndex);
//修改会议轮询参数 add [2019.4.3]
MCSDLL_API u16 ChangeConfPollParamCmd(const s8* pchConfE164ID, u8 byPollType, u32 dwPollTimes, 
								DCTMtPollParam atMtInfo[DC_MAXNUM_CONF_MT], u16 wMtNum, u8 byPollMode, s32 nIndex);

//指定当前轮询终端
MCSDLL_API u16 SpecPollMtReq(const s8* pchConfE164ID, DCTMtInfo* pMtInfo, s32 nIndex);

//开始点名 [daishangwei 2014/11/03]
MCSDLL_API u16 StartRollCallReq(const s8* pchConfE164ID, u8 byType, s32 nIndex);

//改变点名人和被点名人 [daishangwei 2014/11/03]
MCSDLL_API u16 ChangeRollCallReq(const s8* pchConfE164ID, DCTMtInfo* pchMtCaller, DCTMtInfo *pchMtCalled, s32 nIndex);

//停止点名 [daishangwei 2014/11/03]
MCSDLL_API u16 StopRollCallReq(const s8* pchConfE164ID, s32 nIndex);


//获取会议列表[张秋悦 2014/12/18]
MCSDLL_API u16 GetConfTablebyMCS(DCTConfTable &dctConfTable, s32 nIndex);

//获取与会成员[张秋悦 2014/12/18]
MCSDLL_API u16 GetJoinedMtbyMCS(const s8 * pchConfE164ID, DCTJoinedMtTable &dctJoinedMtTable, s32 nIndex, DCTMtInfo *ptMcuInfo);

//获取会议当前广播源[张秋悦 2014/12/18]
MCSDLL_API u16 GetConfCurBrdstbyMCS(const s8 * pchConfE164ID, DCTMtInfo &dctMtInfo, s32 nIndex);

//是否强制广播
MCSDLL_API u16 ForceSeeCurBrdstCmd(const s8* pchConfE164ID, BOOL32 bForce, s32 nIndex);

//开始语音激励
MCSDLL_API u16 StartVacReqbyMCS(const s8* pchConfE164ID, s32 nIndex);

//停止语音激励
MCSDLL_API u16 StopVacReqbyMCS(const s8* pchConfE164ID, s32 nIndex);

/************************************************************

  3.终端操作
  
************************************************************/
//获取终端状态
MCSDLL_API u16 GetMtStatus(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
						   DCTMtStatus &dctMtStatus, s32 nIndex);

//增加终端
MCSDLL_API u16 AddMtReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
							 u16 wCallRate, u8 byCallMode, s32 nIndex, DCTMtInfo *ptMcuInfo);
	
//删除终端
MCSDLL_API u16 DelMtReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, s32 nIndex);
	
//呼叫终端 
MCSDLL_API u16 CallMtReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, s32 nIndex);
	
//挂断终端 
MCSDLL_API u16 DropMtReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, s32 nIndex);

// add [9/18/2015 liuxiaolin]
//设置终端呼叫模式, byCallMode: 0(手动)/1(自动, 定时)
MCSDLL_API u16 SetMtCallModeReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, u8 byCallMode, s32 nIndex);


// start add [3/27/2014 panyingnan]
//设置、取消发言人
MCSDLL_API u16 SetSpeaker(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, s32 nIndex);
MCSDLL_API u16 CancelSpeaker(const s8* pchConfE164ID, s32 nIndex);
//设置、取消主席
MCSDLL_API u16 SetChairMan(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, s32 nIndex); 
MCSDLL_API u16 CancelChairMan(const s8* pchConfE164ID, s32 nIndex); 
//end add
//modify by ZGL 修改函数参数 2015-9-1
//短消息
MCSDLL_API u16 SendMsgCmdbyMCS(const s8* pchConfE164ID,  DCTMtInfo atMtInfo[DC_MAXNUM_CONF_MT],
							   u16 wMtNum, const s8* pMsgContent, u8 byMsgType,
							   u8 byRate, u8 byTimes, s32 nIndex);
//停止短消息
MCSDLL_API u16 StopMsgCmdbyMCS(const s8* pchConfE164ID, 
							   DCTMtInfo atMtInfo[DC_MAXNUM_CONF_MT],
							   u16 wMtNum, s32 nIndex);
//单个终端静音
MCSDLL_API u16 MtQuietReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
							   BOOL32 bQuiet, s32 nIndex);

//全场终端静音
MCSDLL_API u16 ALLMtQuietReqbyMCS(const s8* pchConfE164ID, BOOL32 bQuiet, s32 nIndex);

//单个终端哑音
MCSDLL_API u16 MtDumbReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
							  BOOL32 bDumb, s32 nIndex);

//全场终端哑音
MCSDLL_API u16 ALLMtDumbReqbyMCS(const s8* pchConfE164ID, BOOL32 bDumb, s32 nIndex);

//调节音量
MCSDLL_API u16 SetMtVolumeCmdbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
								   const u8 byVolumeTypeIn, const u8 byVolume, s32 nIndex);
//开始遥控摄像头
MCSDLL_API u16 CameraCtrlStartCmdbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
									   u8 byCtrlType, s32 nIndex);

//停止遥控摄像头
MCSDLL_API u16 CameraCtrlStopCmdbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
									  u8 byCtrlType, s32 nIndex);

//执行预置位
MCSDLL_API u16 CameraMoveToPosCmdbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
									   u8 byPos, s32 nIndex);

//保存预置位
MCSDLL_API u16 CameraSaveToPosCmdbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
									   u8 byPos, s32 nIndex);

//获取终端单板类型
MCSDLL_API u16 GetMtTypebyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, u8 &byMtType, s32 nIndex);

//设置终端视频源
MCSDLL_API u16 SetMtVedioSrcbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, u8 byMtVedioSrc, s32 nIndex);

//获取终端码率 add [4/15/2019]
MCSDLL_API u16 GetMtBitrate(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, s32 nIndex);


/************************************************************

  4.外设操作
  
************************************************************/	
//开始画面合成
MCSDLL_API u16 StartVmpReqbyMCS(const s8* pchConfE164ID, const DCTVMPParam &dctVMPParam, s32 nIndex);
	
//停止画面合成
MCSDLL_API u16 StopVmpReqbyMCS(const s8* pchConfE164ID, s32 nIndex);
	
//追加画面合成
MCSDLL_API u16 ChgVmpParamReqbyMCS(const s8* pchConfE164ID, const DCTVMPParam &dctVMPParam, s32 nIndex);
	
//开始/停止双流失败
MCSDLL_API u16 SendDualStreambyMCS(const s8* pchConfE164ID, DCTMtInfo *pchMtInfo, BOOL32 bSend, s32 nIndex);
	
//智能混音	//[20140328 mod by KB]参数bBroadcast无效
MCSDLL_API u16 StartEntireMixReqbyMCS(const s8* pchConfE164ID, BOOL32 bBroadcast, s32 nIndex);
	
//定制混音	//[20140328 mod by KB]参数bBroadcast无效
MCSDLL_API u16 StartPartMixReqbyMCS(const s8 * pchConfE164ID, DCTMtInfo atMtInfo[DC_MAXNUM_MIXER_CHNNL],
									u8 byMtNum, BOOL32 bBroadcast, s32 nIndex);
//停止混音
MCSDLL_API u16 StopMixReqbyMCS(const s8* pchConfE164ID, s32 nIndex);
    
//增加混音成员
MCSDLL_API u16 AddMixMemberCmdbyMCS(const s8 * pchE164ID, DCTMtInfo* pchMtInfo, s32 nIndex);
    
//删除混音成员
MCSDLL_API u16 RemoveMixMemberCmdbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, s32 nIndex);
	
//开始录像	//[20140328 mod by KB]参数byVideoSrc无效
MCSDLL_API u16 StartRecReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, const s8* pchRecName, 
					const s8* pchFileName, u8 byPublishMode, BOOL32 bRecDual, BOOL32 bRecordConf, s32 nIndex);
    
//暂停录像	//[20140328 mod by KB]参数byVideoSrc无效
MCSDLL_API u16 PauseRecReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, u8 byVideoSrc, BOOL32 bRecordConf, s32 nIndex);
	
//恢复录像	//[20140328 mod by KB]参数byVideoSrc无效
MCSDLL_API u16 ResumeRecReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, u8 byVideoSrc, BOOL32 bRecordConf, s32 nIndex);
    
//停止录像	//[20140328 mod by KB]参数byVideoSrc无效
MCSDLL_API u16 StopRecReqbyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,u8 byVideoSrc, BOOL32 bRecordConf, s32 nIndex);
    
//建立码流交换	//[20140328 mod by KB]参数byMtSrcChan和byMtDstChan无效
MCSDLL_API u16 StartStreamExchangebyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtSrcInfo, 
										u8 byMtSrcChan, DCTMtInfo* pchMtDstInfo,
										u8 byMtDstChan, u8 byMode, s32 nIndex);	
//拆除码流交换	//[20140328 mod by KB]参数byMtSrcChan和byMtDstChan无效
MCSDLL_API u16 StopStreamExchangebyMCS(const s8* pchConfE164ID, DCTMtInfo* pchMtDstInfo, 
									   u8 byMtSrcChan, u8 byMtDstChan, u8 byMode, s32 nIndex);
//开始/停止画面合成广播
MCSDLL_API u16 BroadcastVmpReqbyMCS(const s8* pchConfE164ID, u8 byVmpEqpId, BOOL32 bBroadcast, s32 nIndex);

//获取外设状态
MCSDLL_API u16 GetPeriEqpReqbyMCS(const s8* pchPeriName, EmEqpType emEqpType,
								  BOOL32 &bOnline, s32 nIndex);
 
//选看/取消选看VMP
MCSDLL_API u16 MtSelVmpReq(const s8* pchConfE164ID, DCTMtInfo* pchMtDstInfo, BOOL32 bStart, s32 nIndex);
	
//选看MIXER	//[20140328 mod by KB]接口无效
MCSDLL_API u16 StartSeeMixer(const s8* pchConfE164ID, DCTMtInfo* pchMtDstInfo,
							 BOOL32 bStart, s32 nIndex);
	
//获取在线REC别名 [daishangwei 2014/10/31] 接口暂时没用
MCSDLL_API u16 GetOnlineRecName(const s8* pchConfE164ID, DCTRecName* ptRecName,
								s32& nRecNum, s32 nIndex);

//获取可用的录像机别名 [daishangwei 2014/10/31] 接口暂时没用
MCSDLL_API u16 GetUsefullRec(DCTRecName* ptRecOnlineName, s32 nRecOnlineNum,
							 DCTRecName& dctUsefullRecName, s32 nIndex);

//获取电视墙预案信息
MCSDLL_API u16 GetHDTVWallStyleCfgInfo(DCTHduStyleCfgInfoList *ptTvWallStyleCfgInfo, s32 nIndex);

//终端进、出电视墙
MCSDLL_API u16 StartHDTVWallSwitch(const s8* pchConfE164ID, DCTStartHduParam tStartHduParam, s32 nIndex);
MCSDLL_API u16 StopHDTVWallSwitch(const s8* pchConfE164ID, u16 wEqpAbsId, u8 byChanIdx, s32 nIndex);
MCSDLL_API u16 GetHDTVWALLListbyMCS(DCTHduStatusList* ptHDTVWallStatusList, s32& nHduNum, s32 nIndex);

//获取会议锁定信息,pchUser 最长33字节, pchIp最长16字节
MCSDLL_API u16 GetConfLockInfo(const s8* pchConfE164ID, BOOL32& bLocked, char* pchUser, char* pchIP, s32 nIndex);


// 电视墙轮询 [11/4/2014 panyingnan]

MCSDLL_API u16 StartTwPollCmd(const s8* pchConfE164ID, DCTTwPollInfo &dctTwPollInfo,
							  DCTMtPollParam atMtInfo[DC_MAXNUM_CONF_MT], u16 wMtNum, s32 nIndex);//开始
MCSDLL_API u16 PauseTwPollCmd(const s8* pchConfE164ID, u8 byTwId, u8 byTwChnnlId, s32 nIndex);//暂停
MCSDLL_API u16 ResumeTwPollCmd(const s8* pchConfE164ID, u8 byTwId, u8 byTwChnnlId, s32 nIndex);//恢复
MCSDLL_API u16 StopTwPollCmd(const s8* pchConfE164ID, u8 byTwId, u8 byTwChnnlId, s32 nIndex);//停止
MCSDLL_API u16 GetTwPollParamCmd(const s8* pchConfE164ID, u8 byTwId, u8 byTwChnnlId, s32 nIndex);//获取某个轮询通道的轮询参数

//电视墙通道音量调节
MCSDLL_API u16 SetHduVolumeInfoReq(const s8* pchConfE164ID, DCTHduChnlVolumeInfo dctHduVolumeInfo, s32 nIndex);

#ifdef MCSDLL_USE_DECODER
//开始、停止监控
MCSDLL_API u16 StartMonitor(HWND hWnd, const s8* pchConfE164ID, DCTMtInfo* pchMtInfo,
							u8 byCannel, u8 byMode,  u8 byReal, s32 nIndex);
//监控画面合成
MCSDLL_API u16 StartMonitorVmp(HWND hWnd, const s8* pchConfE164ID, u8 byChnnl, u8 byReal, s32 nIndex);

//监控截图
MCSDLL_API u16  MonitorScreenshot(const wchar_t* pchFilePath, u8 byChnnlId);

//设置监控模式（实时/抽帧）
MCSDLL_API u16 SetMonitorMode(u8 byMonitorChnnl, u8 byReal, s32 nIndex);
#else
MCSDLL_API u16 StartMonitor(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, 
	u8 byCannel, u8 byMode, s32 nIndex);

typedef void (*PFRAMECB)(DCTFrameInfo *pFrameInfo, uintptr_t dwContext);
MCSDLL_API u16 StartMonitorReq(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, 
							u8 byCannel, u8 byMode,  PFRAMECB pFrameCB, uintptr_t dwContext, s32 nIndex);
//请求终端关键帧
MCSDLL_API u16 KeyFrameReq(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, u8 byMode, s32 nIndex);

//请求画面合成关键帧
MCSDLL_API u16 ReqVmpKeyFrameCmd(const s8* pchConfE164ID, s32 nIndex);

//监控画面合成
MCSDLL_API u16 StartMonitorVmpReq(const s8* pchConfE164ID, u8 byChnnl, PFRAMECB pFrameCB, uintptr_t dwContext, s32 nIndex);

#endif

MCSDLL_API u16 StopMonitor(const s8* pchConfE164ID, u8 byCannel, u8 byMode, s32 nIndex);

MCSDLL_API u16 GetMcuMonitorPort(u16 &wMcuMonitorPort, s32 nIndex);		

MCSDLL_API u16 GetMcuCodePage(u32 &dwMcuCodePage, s32 nIndex);

//设置上传源
MCSDLL_API u16 SetOutViewReq(const s8* pchConfE164ID, DCTMtInfo* pchMtInfo, s32 nIndex);
//取消上传源
MCSDLL_API u16 CancelOutViewReq(const s8* pchConfE164ID, s32 nIndex);

#endif