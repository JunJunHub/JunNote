/*=======================================================================
模块名      : mcslib适配消息号定义
文件名      : evmcslibadp.h
相关文件    : 
文件实现功能: 声明
作者        : 王强
版本        : V1.0  Copyright(C) 1997-2003 KDC, All rights reserved.
-----------------------------------------------------------------------------
修改记录:
日  期      版本        修改人      修改内容
2013/4/18	1.0         王强		创建
=======================================================================*/
#ifndef EVMCSLIBADP_H
#define EVMCSLIBADP_H

#define MCS_MSG_BGN                         0
//Osp断链, 内容: s8[DC_MAXLEN_MCU_NAME](MCU名称) + u8(MCU名长度)
#define MCS_OSP_DISCONNECT                  MCS_MSG_BGN+1  
//会议基本状态通知,内容:DCTConfGeneralStatus(会议基本状态) 
#define MCS_CONF_GENERAL_STATUS_NOTIF       MCS_MSG_BGN+2 
//会议VMP状态通知,内容:DCTConfVmpStatus(会议画面合成器状态)
#define MCS_CONF_VMP_STATUS_NOTIF           MCS_MSG_BGN+3
//会议MIX状态通知,内容:DCTConfMixStatus(会议混音器状态)
#define MCS_CONF_MIX_STATUS_NOTIF           MCS_MSG_BGN+4
//会议录像进度状态通知,内容:DCTConfRecProgStatus(会议录像状态)
#define MCS_CONF_RECPROG_STATUS_NOTIF       MCS_MSG_BGN+5
//外设状态通知，消息体：DCTRecStatus（单个录像机的状态）
#define MCS_RECSTATUS_NOTIF                 MCS_MSG_BGN+6
//即时会议完整信息通知, 内容: DCTConfInfoInConfTable(会议信息)
#define MCS_CONFINFO_NOTIF                  MCS_MSG_BGN+7
//MCU给会议控制台的查询终端状态通知, num*DCTMtStatus(终端状态数组), num*sizeof(DCTMtStatus)
#define MCS_MTSTATUS_NOTIF                  MCS_MSG_BGN+8
//CPS准入应答，无消息体
#define CPS_CONNECT_ACK                     MCS_MSG_BGN+9
//CPS拒绝应答，消息体：错误号
#define CPS_CONNECT_NACK                    MCS_MSG_BGN+10
//会议控制台在MCU上创建一个会议成功应答，消息体：s8[DC_MAXLEN_ConfE164],会议E164号
#define MCS_CREATECONF_ACK                  MCS_MSG_BGN+15
//会议控制台在MCU上创建一个会议失败，消息体：DCTConfError
#define MCS_CREATECONF_NACK                 MCS_MSG_BGN+16
//MCU成功结束会议应答，消息体：s8[DC_MAXLEN_ConfE164],会议E164号
#define MCS_RELEASECONF_ACK                 MCS_MSG_BGN+17
//MCU拒绝结束会议，消息体：DCTConfError
#define MCS_RELEASECONF_NACK                MCS_MSG_BGN+18
//MCU结束会议通知，消息体：u8 类型（即时、模板、预约）+ s8 [MAXLEN_E164]会议E164
#define MCS_RELEASECONF_NOTIF               MCS_MSG_BGN+19
//MCU同意会议控制台增加终端，无消息体
#define MCS_ADDMT_ACK                       MCS_MSG_BGN+20
//MCU拒绝会议控制台增加终端，消息体：错误号
#define MCS_ADDMT_NACK                      MCS_MSG_BGN+21
//终端被成功驱逐，无消息体
#define MCS_DELMT_ACK                       MCS_MSG_BGN+22
//消息描述：拒绝驱逐终端，消息体：错误号
#define MCS_DELMT_NACK                      MCS_MSG_BGN+23
//MCU同意画面合成请求，无消息体
#define MCS_STARTVMP_ACK                    MCS_MSG_BGN+24
//MCU不同意画面合成请求，消息体：错误号
#define MCS_STARTVMP_NACK                   MCS_MSG_BGN+25
//画面合成成功开始通知，无消息体
#define MCS_STARTVMP_NOTIF                  MCS_MSG_BGN+26
//MCU同意视频结束复合请求，无消息体
#define MCS_STOPVMP_ACK                     MCS_MSG_BGN+27
//MCU不同意结束画面合成请求，消息体：错误号
#define MCS_STOPVMP_NACK                    MCS_MSG_BGN+28
//画面合成成功结束通知，消息体:s8[DC_MAXLEN_ConfE164]
#define MCS_STOPVMP_NOTIF                   MCS_MSG_BGN+29
//MCU同意会议控制台的改变画面合成参数请求，无消息体
#define MCS_CHANGEVMPPARAM_ACK              MCS_MSG_BGN+30
//MCU拒绝会议控制台的改变画面合成参数请求，消息体：错误号
#define MCS_CHANGEVMPPARAM_NACK             MCS_MSG_BGN+31
//MCU成功添加/删除画面合成成员，无消息体
#define MCS_CHANGEVMPPARAM_NOTIF            MCS_MSG_BGN+32
//终端发送双流成功
#define MCS_MTDUALSTREAM_ACK                MCS_MSG_BGN+33
//终端发送双流失败
#define MCS_MTDUALSTREAM_NACK               MCS_MSG_BGN+34
//开始本级混音(智能/定制)
//MCU同意开始本级混音，无消息体
#define MCS_STARTMIX_ACK                    MCS_MSG_BGN+35
//MCU拒绝开始本级混音，消息体：错误号
#define MCS_STARTMIX_NACK                   MCS_MSG_BGN+36
//MCU开始本级混音通知，无消息体
#define MCS_STARTMIX_NOTIF                  MCS_MSG_BGN+37
//MCU同意会议控制台结束本级混音的请求，无消息体
#define MCS_STOPMIX_ACK                     MCS_MSG_BGN+38
//MCU拒绝会议控制台结束本级混音的请求，消息体：错误号
#define MCS_STOPMIX_NACK                    MCS_MSG_BGN+39
//MCU给会议控制台结束本级混音的通知，无消息体
#define MCS_STOPMIX_NOTIF                   MCS_MSG_BGN+40
//MCU同意会控放像请求，无消息体
#define MCS_STARTREC_ACK                    MCS_MSG_BGN+41
//MCU拒绝会控放像请求，消息体：错误号
#define MCS_STARTREC_NACK                   MCS_MSG_BGN+42
//MCU同意会控停止放像请求，无消息体
#define MCS_STOPREC_ACK                     MCS_MSG_BGN+43
//MCU拒绝会控停止放像请求，消息体：错误号
#define MCS_STOPREC_NACK                    MCS_MSG_BGN+44
//MCU同意会控暂停放像请求，无消息体
#define MCS_PAUSEREC_ACK                    MCS_MSG_BGN+45
//MCU拒绝会控暂停放像请求，消息体：错误号
#define MCS_PAUSEREC_NACK                   MCS_MSG_BGN+46
//MCU同意会控恢复放像请求，无消息体
#define MCS_RESUMEREC_ACK                   MCS_MSG_BGN+47
//MCU拒绝会控恢复放像请求，消息体：错误号
#define MCS_RESUMEREC_NACK                  MCS_MSG_BGN+48
//MCU应答会控强制目的终端选看源终端，消息体：u8 byMode（交换模式：MODE_VIDEO, MODE_AUDIO, MODE_BOTH）
#define MCS_STARTMTSEE_ACK                  MCS_MSG_BGN+49
//拒绝会控强制目的终端选看源终端，消息体：错误号
#define MCS_STARTMTSEE_NACK                 MCS_MSG_BGN+50
//MCU应答会控取消目的终端选看源终端，无消息体
#define MCS_STOPMTSEE_ACK                   MCS_MSG_BGN+51
//MCU拒绝会控取消目的终端选看源终端，消息体：错误号
#define MCS_STOPMTSEE_NACK                  MCS_MSG_BGN+52
//MCU成功指定发言者，消息体:s8[DC_MAXLEN_ConfE164]
#define MCS_SPECSPEAKER_ACK                 MCS_MSG_BGN+53
//MCU指定发言者失败，消息体：错误号
#define MCS_SPECSPEAKER_NACK                MCS_MSG_BGN+54
//指定发言通知，无消息体
#define MCS_SPECSPEAKER_NOTIF               MCS_MSG_BGN+55
//MCU应答会议控制台设置终端静音，消息体: MtNum*DCTMtAudMuteNotify
#define MCS_MTAUDMUTE_ACK                   MCS_MSG_BGN+56
//MCU拒绝会议控制台设置终端静音，消息体：DCTMtAudMuteNotify
#define MCS_MTAUDMUTE_NACK                  MCS_MSG_BGN+57
//MCU通知会议控制台设置终端静音，无消息体
#define MCS_MTAUDMUTE_NOTIF                 MCS_MSG_BGN+58
//操作超时，无消息体
#define MCS_OPERATE_TIMEOUT                 MCS_MSG_BGN+59
//画面合成器参数通知,消息体：DCTConfVmpStatus（会议画面合成状态）
#define MCS_VMPPARAM_NOTIF                  MCS_MSG_BGN+60
//终端选看VMP成功
//#define MCS_MTSELVMP_ACK                    MCS_MSG_BGN+60
//终端选看VMP失败
//#define MCS_MTSELVMP_NACK                   MCS_MSG_BGN+61
//终端选看混音成功
//#define MCS_MTSELMIXER_ACK                  MCS_MSG_BGN+62
//终端选看混音失败
//#define MCS_MTSELMIXER_NACK                 MCS_MSG_BGN+63
//终端申请插话，消息体：DCTMtApplyInfo
#define MCS_MTAPPLYMIX_NOTIF                MCS_MSG_BGN+64
//选看VMP成功
#define MCS_SEEVMP_ACK                      MCS_MSG_BGN+65
//选看VMP失败
#define MCS_SEEVMP_NACK                     MCS_MSG_BGN+66
//选看MIXER成功
#define MCS_SEEMIXER_ACK                    MCS_MSG_BGN+67
//选看MIXER失败
#define MCS_SEEMIXER_NACK                   MCS_MSG_BGN+68
//取消发言人成功，无消息体
#define MCS_CANCELSPEAKER_ACK               MCS_MSG_BGN+69
//取消发言人失败，消息体：错误号
#define MCS_CANCELSPEAKER_NACK              MCS_MSG_BGN+70
//取消发言人通知，无消息体
#define MCS_CANCELSPEAKER_NOTIF             MCS_MSG_BGN+71
//终端成功加入/退出混音组，消息体：DCTConfMixStatus(会议混音状态)
#define MCS_MIXPARAM_NOTIF                  MCS_MSG_BGN+72

// start add
//申请主席成功，无消息体
#define MCS_SPECCHAIRMAN_ACK                MCS_MSG_BGN + 74
//申请主席失败，消息体：错误号
#define MCS_SPECCHAIRMAN_NACK               MCS_MSG_BGN + 75
//申请主席通知，无消息体
#define MCS_SPECCHAIMAN_NOTIF               MCS_MSG_BGN + 76
//终端申请主席通知，无消息体
#define MCS_MTAPPLAYCHAIRMAN_NOTIF          MCS_MSG_BGN + 77
//取消主席成功，无消息体
#define MCS_CANCELCHAIRMAN_ACK              MCS_MSG_BGN + 78
//取消主席失败，消息体：错误号
#define  MCS_CANCELCHAIRMAN_NACK            MCS_MSG_BGN + 79
//取消主席通知，无消息体
#define  MCS_CANCELCHAIRMAN_NOTIF           MCS_MSG_BGN + 80
//终端进电视墙成功，无消息体
#define MCS_STARTHDTVWALL_ACK               MCS_MSG_BGN + 81
//终端进电视墙失败，消息体：错误号
#define MCS_STARTHDTVWALL_NACK              MCS_MSG_BGN + 82
//终端出电视墙成功，无消息体
#define MCS_STOPHDTVWALL_ACK                MCS_MSG_BGN + 83
//终端出电视墙失败，消息体：错误号
#define MCS_STOPHDTVWALL_NACK               MCS_MSG_BGN + 84
//会议轮询状态通知, 消息体DCTPollInfo
#define MCS_CONFPOLLSTATUS_NOTIF            MCS_MSG_BGN + 85
//会议轮询参数通知， 消息体DCTPollMemberNfy
#define MCS_CONFPOLLPARAM_NOTIF             MCS_MSG_BGN + 86
//获取轮询参数成功，无消息体
#define MCS_GETCONFPOLLPARAM_ACK            MCS_MSG_BGN + 87
//获取轮询参数失败，消息体：错误号
#define MCS_GETCONFPOLLPARAM_NACK           MCS_MSG_BGN + 88
//会议模版基本状态通知,消息体：DCTConfTemTable
#define MCS_CONFTEM_GENERAL_STATUS_NOTIF    MCS_MSG_BGN + 89
//单个会议模版信息通知，消息体DCTConfInfoInConfTable
#define  MCS_CONFTEMINFO_NOTIF              MCS_MSG_BGN + 90
//Hdu状态上报，消息体DCTHduStatusList
#define MCS_HDUSTATUS_NOTIF                 MCS_MSG_BGN + 91
//Hdu列表上报 消息体：DCTTVWallStatu-------不通知无用
#define MCS_HDUSTATUSLIST_NOTIF             MCS_MSG_BGN + 92
//end add

//点名消息 
//开始点名成功，无消息体
#define MCS_STARTROLLCALL_ACK			MCS_MSG_BGN + 93
//开始点名失败,消息体：错误号
#define MCS_STARTROLLCALL_NACK			MCS_MSG_BGN + 94
//开始点名通知，消息体:DCTRollCallNotify
#define MCS_STARTROLLCALL_NOTIF			MCS_MSG_BGN + 95
//改变点名成功，无消息体
#define MCS_CHANGEROLLCALL_ACK			MCS_MSG_BGN + 96
//改变点名失败,消息体：错误号
#define MCS_CHANGEROLLCALL_NACK			MCS_MSG_BGN + 97
//改变点名通知，消息体:DCTRollCallNotify
#define MCS_CHANGEROLLCALL_NOTIF		MCS_MSG_BGN + 98
//停止点名成功，无消息体
#define MCS_STOPROLLCALL_ACK			MCS_MSG_BGN + 99
//停止点名失败,消息体：错误号
#define MCS_STOPROLLCALL_NACK			MCS_MSG_BGN + 100
//停止点名通知，消息体:s8[DC_MAXLEN_ConfE164]
#define MCS_STOPROLLCALL_NOTIF			MCS_MSG_BGN + 101

// 电视墙轮询 消息体：DCTTwPollParam
#define MCS_GETTWPOLLPARAM_ACK          MCS_MSG_BGN + 102
//消息体：错误号
#define MCS_GETTWP0LLPARAM_NACK         MCS_MSG_BGN + 103
//消息体：DCTTwPollParam
#define MCS_TWPOLLPARAM_NOTIF           MCS_MSG_BGN + 104

//开始监控成功，无消息体
#define MCS_STARTMONITOR_ACK			MCS_MSG_BGN + 105
//开始监控失败，消息体：错误号
#define MCS_STARTMONITOR_NACK			MCS_MSG_BGN + 106
//开始监控通知, 消息体:DCTMonitorParam
#define MCS_STARTMONITOR_NOTIF			MCS_MSG_BGN + 107

//停止监控成功，消息体:u8
#define MCS_STOPMONITOR_ACK				MCS_MSG_BGN + 108
//停止监控失败，消息体：错误号
#define MCS_STOPMONITOR_NACK			MCS_MSG_BGN + 109
//停止监控通知，消息体:u8
#define MCS_STOPMONITOR_NOTIF			MCS_MSG_BGN + 110

// add
//设置终端呼叫模式成功，消息体：DCTMtInfo
#define MCS_SETMTCALLMODE_ACK           MCS_MSG_BGN + 112
//设置终端呼叫模式失败，消息体：错误号
#define MCS_SETMTCALLMODE_NACK          MCS_MSG_BGN + 113
//呼叫终端成功，无消息体
#define MCS_CALLMT_ACK					MCS_MSG_BGN + 114
//呼叫终端失败，消息体：错误号
#define MCS_CALLMT_NACK					MCS_MSG_BGN + 115
//删除终端成功，无消息体
#define MCS_DROPMT_ACK				    MCS_MSG_BGN + 116
//删除终端失败,消息体：错误号
#define MCS_DROPMT_NACK					MCS_MSG_BGN + 117
//呼叫终端失败通知，消息体: DCTMtCallFailedReason
#define MCS_CALLMT_FAILED_NOTIFY		MCS_MSG_BGN + 118
//录像列表更新通知，消息体：DCTRecStatusList
#define MCS_RECSTATUSLIST_NOTIFY		MCS_MSG_BGN + 119

//设置电视墙通道音量成功，消息体：DCTHduChnlVolumeInfo
#define MCS_SET_HDUVOLUMEINFO_ACK		MCS_MSG_BGN + 120
//设置电视墙通道音量失败，消息体：错误号
#define MCS_SET_HDUVOLUMEINFO_NACK		MCS_MSG_BGN + 121
//开始语音激励成功，消息体：s8[DC_MAXLEN_ConfE164]，会议164号
#define	MCS_START_VAC_ACK				MCS_MSG_BGN + 122
//开始语音激励失败，消息体：错误号
#define MCS_START_VAC_NACK				MCS_MSG_BGN + 123
//停止语音激励成功，消息体：s8[DC_MAXLEN_ConfE164]，会议164号
#define	MCS_STOP_VAC_ACK				MCS_MSG_BGN + 124
//停止语音激励失败，消息体：错误号
#define	MCS_STOP_VAC_NACK				MCS_MSG_BGN + 125
//指定轮询终端成功，消息体：s8[DC_MAXLEN_ConfE164]，会议164号
#define	MCS_SPECPOLLMT_ACK				MCS_MSG_BGN + 126
//指定轮询终端失败，消息体：错误号
#define	MCS_SPECPOLLMT_NACK				MCS_MSG_BGN + 127
//vrs状态列表通知，消息体：DCTRecStatusList
#define MCS_VRS_STATUS_NOTIF			MCS_MSG_BGN + 128
//录放像异常消息通知，消息体：错误号
#define MCS_RECORDER_ABNORMAL_NOTIF		MCS_MSG_BGN + 129
//告警消息，消息体：错误号
#define MCS_ALARMINFO_NOTIF				MCS_MSG_BGN + 130
//开始画面合成广播成功，消息体：s8[DC_MAXLEN_ConfE164]，会议164号
#define MCS_START_VMPBRDST_ACK			MCS_MSG_BGN + 131
//开始画面合成广播失败，消息体：错误号
#define MCS_START_VMPBRDST_NACK			MCS_MSG_BGN + 132
//取消画面合成广播成功，消息体：s8[DC_MAXLEN_ConfE164]，会议164号
#define MCS_STOP_VMPBRDST_ACK			MCS_MSG_BGN + 133
//取消画面合成广播失败，消息体：错误号
#define MCS_STOP_VMPBRDST_NACK			MCS_MSG_BGN + 134
//通过模板创会成功 消息体：s8[DC_MAXLEN_ConfE164],会议E164号
#define MCS_CREATECONFBYTEMPLATE_ACK	MCS_MSG_BGN + 135
//通过模板创会失败 消息体：错误号
#define MCS_CREATECONFBYTEMPLATE_NACK	MCS_MSG_BGN + 136
//终端上下线通知，消息体: DCTMtOnlineInfo
#define MCS_MTONLINECHANGE_NOTIFY		MCS_MSG_BGN + 137

//add
//终端申请发言人，消息体：DCTMtApplyInfo
#define MCS_MTAPPLYSPEAKER_NOTIF		MCS_MSG_BGN + 138
//终端申请主席，消息体：DCTMtApplyInfo
#define MCS_MTAPPLYCHAIRMAN_NOTIF		MCS_MSG_BGN + 139
//录像进度通知，消息体：DCTRecProg
#define MCS_RECPROG_NOTIF				MCS_MSG_BGN + 140
//终端码率通知，消息体：DCTMtBitrateInfo
#define MCS_MTBITRATE_NOTIF				MCS_MSG_BGN + 141
#endif
