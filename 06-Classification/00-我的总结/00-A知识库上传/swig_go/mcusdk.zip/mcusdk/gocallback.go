package mcusdk

import "C"
import (
	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/os/glog"
	"mpuaps/app/common/global"
	"unsafe"
)

//pFuncHandleCBMsg 回调消息处理函数
type pFuncHandleCBMsg func(mcuIdx uint, args ...interface{})

//mapCBEventHandle 通知事件处理接口
//                 key=EventId value=pFuncHandleCBMsg
type typeMapCBEventHandle map[int]pFuncHandleCBMsg

//mcuHandleFuncMap MCU对应的通知事件处理接口, 每台MCU都对应一组不同的处理接口(一个MCU连接实例一组处理接口)
//                 key=MCUTag value=typeMapCBEventHandle
var mcuHandleFuncMap map[string]typeMapCBEventHandle

//SetCBMsgHandleFunc 上层业务设置回调消息处理接口
func SetCBMsgHandleFunc(mcuTag string, eventId int, handleFunc pFuncHandleCBMsg) {
	if mcuHandleFuncMap == nil {
		mcuHandleFuncMap = make(map[string]typeMapCBEventHandle)
	}

	if _, ok := mcuHandleFuncMap[mcuTag]; !ok {
		mapCBEventHandle := make(map[int]pFuncHandleCBMsg)
		mcuHandleFuncMap[mcuTag] = mapCBEventHandle
	}

	if _, ok := mcuHandleFuncMap[mcuTag][eventId]; ok {
		logger().Warningf("MCU[%s] reset eventId=%d handleFunc", mcuTag, eventId)
	} else {
		logger().Infof("MCU[%s] set eventId=%d handleFunc", mcuTag, eventId)
	}
	mcuHandleFuncMap[mcuTag][eventId] = handleFunc
}

//DelCBMsgHandleFunc 上层业务取消回调消息处理接口
//                   MCU连接对象销毁时调用,释放
func DelCBMsgHandleFunc(mcuTag string) {
	if _, ok := mcuHandleFuncMap[mcuTag]; ok {
		delete(mcuHandleFuncMap, mcuTag)
	}
}

//handleCBMsg 通知消息回传
//            给每个MCU对接实例广播通知消息, 对接实例根据 mcuIdx 判断是否需要处理
func handleCBMsg(mcuIdx, eventId uint, args ...interface{}) {
	if len(mcuHandleFuncMap) == 0 {
		logger().Warningf("mcusdk unset handleFunc", eventId)
	}

	for mcuTag, mapCBEventHandle := range mcuHandleFuncMap {
		if pHandleFunc, ok := mapCBEventHandle[int(eventId)]; ok {
			if pHandleFunc != nil {
				go pHandleFunc(mcuIdx, args...)
			}
		} else {
			logger().Warningf("MCU[%s] unset eventId=%d  handleFunc", mcuTag, eventId)
		}
	}
}

//logger
//@summary 本模块使用的日志对象
func logger() *glog.Logger {
	return g.Log(global.LoggerAccessMCUAdapter)
}

//GoMcsCallback MCUSDK异步通知回调
type GoMcsCallback interface {
	CMcsCBHandler
	deleteCallback()
	IsGoCallback()
}

//goMcsCallback MCUSDK回调异步通知业务对象
type goMcsCallback struct {
	CMcsCBHandler
}

func (p *goMcsCallback) deleteCallback() {
	//TODO C++回调类 CMcsCBHandler 未声明析构函数, SWIG 转换时会报警告
	//     若声明析构函数 ConnectMcsServerReq 连接成功，收到通知会触发销毁 CMcsCBHandler 对象, 原因未知. 因此注释掉了析构函数
	//     -- 全局共用一个回调对象, 不用重复New Del, 不存在内存泄露
	//DeleteDirectorCMcsCBHandler(p.CMcsCBHandler)
}

func (p *goMcsCallback) IsGoCallback() {}

//NewGoMcsCallback 创建GOLANG实现的CallBack
func NewGoMcsCallback() GoMcsCallback {
	om := &overwrittenMethodsOnCallback{}
	p := NewDirectorCMcsCBHandler(om)
	om.p = p

	return &goMcsCallback{CMcsCBHandler: p}
}

//DeleteGoMcsCallback 销毁GOLANG实现的CallBack
func DeleteGoMcsCallback(p GoMcsCallback) {
	p.deleteCallback()
}

//overwrittenMethodsOnCallback 重写回调接口
type overwrittenMethodsOnCallback struct {
	p CMcsCBHandler
}

// CBHandle
// TODO
// 接收并解析MCUSDK通知消息,转换为golang数据类型. MCUSDK通知协议定义参见 evmcslibadp.h
// 注意: 此接口仅将接收到的 C 内存数据转换为 golang 数据结构并回传给上层业务. 不做业务逻辑
//      - C 数据结构转换为 Golang 数据结构
//      - 转换后的数据回调给上层业务
func (p *overwrittenMethodsOnCallback) CBHandle(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) (retCode uint16) {
	switch int(dwEventId) {
	case MCS_OSP_DISCONNECT: //1 Osp断链
		parseCXXCBMsgOSPDisconnectNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
		return
	case MCS_CONF_GENERAL_STATUS_NOTIF: //2 会议基本状态通知
		parseCXXCBMsgConfGeneralStatusNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_CONF_VMP_STATUS_NOTIF: //3 会议VMP状态通知
		parseCXXCBMsgConfVmpStatusNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_CONF_MIX_STATUS_NOTIF: //4 会议MIX状态通知
		parseCXXCBMsgConfMixStatusNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_CONFINFO_NOTIF: //7 会议完整信息通知
		parseCXXCBMsgConfInfoNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_MTSTATUS_NOTIF: //8 MCU给会议控制台的查询终端状态通知
		parseCXXCBMsgMTStatusNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	//连接MCU异步应答结果
	case CPS_CONNECT_ACK: //9 CPS准入应答
		parseCXXCBMsgConnectAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case CPS_CONNECT_NACK: //10 CPS拒绝应答
		parseCXXCBMsgConnectNAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	//case MCS_CREATECONF_ACK: //15 会议控制台在MCU上创建一个会议成功应答
	//	parseCXXCBMsgCreateConfAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	//case MCS_CREATECONF_NACK: //16 会议控制台在MCU上创建一个会议失败
	//	parseCXXCBMsgCreateConfNAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	case MCS_RELEASECONF_ACK: //17 MCU成功结束会议应答
		parseCXXCBMsgReleaseConfAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_RELEASECONF_NACK: //18 MCU拒绝结束会议
		parseCXXCBMsgReleaseConfNAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_RELEASECONF_NOTIF: //19 MCU结束会议通知
		parseCXXCBMsgReleaseConfNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	//case MCS_STARTVMP_ACK: //24 MCU同意画面合成请求
	//	parseCXXCBMsgStartVmpAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	//case MCS_STARTVMP_NACK: //25 MCU不同意画面合成请求
	//	parseCXXCBMsgStartVmpNAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	//case MCS_STARTVMP_NOTIF: //26 画面合成成功开始通知
	//	parseCXXCBMsgStartVmpNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	//case MCS_STOPVMP_ACK: //27 MCU同意结束画面合成请求
	//	parseCXXCBMsgStopVmpAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	//case MCS_STOPVMP_NACK: //28 MCU不同意结束画面合成请求
	//	parseCXXCBMsgStopVmpNAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	//case MCS_STOPVMP_NOTIF: //29 画面合成成功结束通知
	//	parseCXXCBMsgStopVmpNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	//case MCS_CHANGEVMPPARAM_ACK: //30 MCU同意会议控制台的改变画面合成参数请求
	//case MCS_CHANGEVMPPARAM_NACK: //31 MCU拒绝会议控制台的改变画面合成参数请求
	//case MCS_CHANGEVMPPARAM_NOTIF: //32 MCU成功添加/删除画面合成成员

	//case MCS_STARTMIX_ACK: //35 MCU同意开始本级混音
	//case MCS_STARTMIX_NACK: //36 MCU拒绝开始本级混音
	//case MCS_STARTMIX_NOTIF: //37 MCU开始本级混音通知
	//case MCS_STOPMIX_ACK: //38 MCU同意会议控制台结束本级混音的请求
	//case MCS_STOPMIX_NACK: //39 MCU拒绝会议控制台结束本级混音的请求
	//case MCS_STOPMIX_NOTIF: //40 MCU给会议控制台结束本级混音的通知

	//case MCS_STARTMTSEE_ACK: //41 MCU应答会控强制目的终端选看源终端
	//case MCS_STARTMTSEE_NACK: //42 拒绝会控强制目的终端选看源终端
	//case MCS_STOPMTSEE_ACK: //43 MCU应答会控取消目的终端选看源终端
	//case MCS_STOPMTSEE_NACK: //44 MCU拒绝会控取消目的终端选看源终端

	//case MCS_SPECSPEAKER_ACK: //53 MCU成功指定发言者
	//case MCS_SPECSPEAKER_NACK: //54 MCU指定发言者失败
	//case MCS_SPECSPEAKER_NOTIF: //55 指定发言通知

	case MCS_VMPPARAM_NOTIF: //60 MCS_VMPPARAM_NOTIF
		parseCXXCBMsgVmpParamNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	//case MCS_CANCELSPEAKER_ACK: //69 取消发言人成功
	//case MCS_CANCELSPEAKER_NACK: //70 取消发言人失败
	//case MCS_CANCELSPEAKER_NOTIF: //71 取消发言人通知

	case MCS_MIXPARAM_NOTIF: //72 终端成功加入/退出混音组
		parseCXXCBMsgMixParamNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	//case MCS_SPECCHAIRMAN_ACK: //74 申请主席成功
	//case MCS_SPECCHAIRMAN_NACK: //75 申请主席失败
	//case MCS_SPECCHAIMAN_NOTIF: //76 申请主席通知
	//case MCS_MTAPPLAYCHAIRMAN_NOTIF: //77 终端申请主席通知

	//case MCS_CANCELCHAIRMAN_ACK: //78 取消主席成功
	//case MCS_CANCELCHAIRMAN_NACK: //79 取消主席失败
	//case MCS_CANCELCHAIRMAN_NOTIF: //80 取消主席通知

	case MCS_CONFPOLLSTATUS_NOTIF: //85 会议轮询状态通知
	case MCS_CONFPOLLPARAM_NOTIF: //86 会议轮询参数通知

	case MCS_CALLMT_ACK: //114 呼叫终端成功
		parseCXXCBMsgCallMTAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_CALLMT_NACK: //115 呼叫终端失败
		parseCXXCBMsgCallMTNAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_DROPMT_ACK: //116 删除终端成功
		parseCXXCBMsgDropMTAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_DROPMT_NACK: //117 删除终端失败
		parseCXXCBMsgDropMTNAck(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)
	case MCS_CALLMT_FAILED_NOTIFY: //118 呼叫终端失败通知
		parseCXXCBMsgCallMTFailedNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	//case MCS_START_VAC_ACK: //122 开始语音激励成功
	//case MCS_START_VAC_NACK: //123 开始语音激励失败
	//case MCS_STOP_VAC_ACK: //124 停止语音激励成功
	//case MCS_STOP_VAC_NACK: //125 停止语音激励失败

	//case MCS_SPECPOLLMT_ACK://126 指定轮询终端成功
	//case MCS_SPECPOLLMT_NACK://127 指定轮询终端失败

	case MCS_ALARMINFO_NOTIF: //130 告警消息

	//case MCS_START_VMPBRDST_ACK: //131 开始画面合成广播成功
	//case MCS_START_VMPBRDST_NACK: //132 开始画面合成广播失败
	//case MCS_STOP_VMPBRDST_ACK: //133 取消画面合成广播成功
	//case MCS_STOP_VMPBRDST_NACK: //134 取消画面合成广播失败

	case MCS_CREATECONFBYTEMPLATE_ACK: //135 通过模板创会失败
	case MCS_CREATECONFBYTEMPLATE_NACK: //136 通过模板创会失败

	case MCS_MTONLINECHANGE_NOTIFY: //137 终端上下线通知[添加删除]
		parseCXXCBMsgAddDelMTNty(dwEventId, pMsgBody, dwMsgLength, nMcuIdx)

	//case MCS_MTAPPLYSPEAKER_NOTIF: //138 终端申请发言人
	//case MCS_MTAPPLYCHAIRMAN_NOTIF: //139 终端申请主席
	default:
		logger().Debugf("Don't care MCUSDK CallBack dwEvent=%d, McuIdx=%d", dwEventId, nMcuIdx)
		return
	}
	logger().Debugf("MCUSDK CallBack dwEvent=%d, McuIdx=%d", dwEventId, nMcuIdx)
	return
}

//1 MCS_OSP_DISCONNECT
func parseCXXCBMsgOSPDisconnectNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//Osp断链, 内容: s8[DC_MAXLEN_MCU_NAME](MCU名称) + u8(MCU名长度)
	pData := (S8)(SwigcptrS8(pMsgBody))
	pMcuNameLen := ByteArray_getitem(pData, DC_MAXLEN_ALIAS)
	mcuNameLen := *(*byte)(unsafe.Pointer(pMcuNameLen.Swigcptr()))
	mcuName := string((*[0x7fffffff]byte)(unsafe.Pointer(pData.Swigcptr()))[:mcuNameLen])
	logger().Warning("MCUSDK MCS_OSP_DISCONNECT:", mcuName, mcuNameLen)
}

//2 MCS_CONF_GENERAL_STATUS_NOTIF
func parseCXXCBMsgConfGeneralStatusNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//会议基本状态通知, 内容: DCTConfGeneralStatus(会议基本状态)
	pData := (DCTConfGeneralStatus)(SwigcptrDCTConfGeneralStatus(pMsgBody))
	pData.Print()
	logger().Debugf("MCUSDK MCS_CONF_GENERAL_STATUS_NOTIF: confE164=%s", pData.GetConfE164())

	handleCBMsg(nMcuIdx, dwEventId, pData)
}

//3 MCS_CONF_VMP_STATUS_NOTIF
func parseCXXCBMsgConfVmpStatusNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//会议VMP状态通知, 内容: DCTConfVmpStatus(会议画面合成器状态)
	pData := (DCTConfVmpStatus)(SwigcptrDCTConfVmpStatus(pMsgBody))
	pData.Print()
	logger().Debugf("MCUSDK MCS_CONF_VMP_STATUS_NOTIF: confE164=%s", pData.GetConfE164())

	handleCBMsg(nMcuIdx, dwEventId, pData)
}

//4 MCS_CONF_MIX_STATUS_NOTIF
func parseCXXCBMsgConfMixStatusNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//会议MIX状态通知, 内容: DCTConfMixStatus(会议混音器状态)
	pData := (DCTConfMixStatus)(SwigcptrDCTConfMixStatus(pMsgBody))
	pData.Print()
	logger().Debugf("MCUSDK MCS_CONF_MIX_STATUS_NOTIF: confE164=%s", pData.GetConfE164())

	handleCBMsg(nMcuIdx, dwEventId, pData)
}

//7 MCS_CONFINFO_NOTIF
func parseCXXCBMsgConfInfoNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//即时会议完整信息通知, 内容: DCTConfInfoInConfTable(会议信息)
	pData := (DCTConfInfoInConfTable)(SwigcptrDCTConfInfoInConfTable(pMsgBody))
	pData.Print()
	logger().Debug("MCUSDK MCS_CONFINFO_NOTIF: ", pData.GetConfId(), pData.GetConfE164(), pData.GetConfName(), pData.GetM_byForceRcvSpeaker())

	handleCBMsg(nMcuIdx, dwEventId, pData)
}

//8 MCS_MTSTATUS_NOTIF
func parseCXXCBMsgMTStatusNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//MCU给会议控制台的查询终端状态通知, num*DCTMtStatus(终端状态数组), num = dwMsgLength / sizeof(DCTMtStatus)
	mtNum := int(dwMsgLength / uint(SizeofDCTMtStatus()))
	pMtStatus := (DCTMtStatus)(SwigcptrDCTMtStatus(pMsgBody))
	for idx := 0; idx < mtNum; idx++ {
		mtStatus := DCTMtStatusArray_getitem(pMtStatus, idx)
		online := mtStatus.GetM_byMtStatus()
		quiet := mtStatus.GetM_byQuiet()
		dumb := mtStatus.GetM_byDumb()
		mtInfo := mtStatus.GetM_dctMtInfo()
		mtId := mtInfo.GetM_achMtInfo()
		mtSubType := mtInfo.GetM_bySubType()
		mix := mtStatus.GetM_byInMixing()
		logger().Debugf("MCS_MTSTATUS_NOTIF online:%d quiet:%d dumb:%d mtId:%s mtSubType:%d mix:%d",
			online, quiet, dumb, mtId, mtSubType, mix)
	}
	handleCBMsg(nMcuIdx, dwEventId, pMtStatus, mtNum)
}

//9 CPS_CONNECT_ACK
func parseCXXCBMsgConnectAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//CPS准入应答，无消息体
	logger().Debugf("MCUSDK CPS_CONNECT_ACK, mcuIdx=%d", nMcuIdx)
	handleCBMsg(nMcuIdx, dwEventId, 0)
}

//10 CPS_CONNECT_NACK
func parseCXXCBMsgConnectNAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//CPS拒绝应答，消息体：错误号
	//TODO 解析返回的错误码异常??  dwMsgLength=4
	//mcuErrCode := *(*C.short)(unsafe.Pointer(uintptr(pMsgBody)))
	logger().Debugf("MCUSDK CPS_CONNECT_NACK, mcuIdx=%d, dwEventId=%d, pMsgBody=%d, dwMsgLength=%d",
		nMcuIdx, dwEventId, pMsgBody, dwMsgLength)

	//默认返回无效的账户信息
	const EMCUUserInvalid = 5
	handleCBMsg(nMcuIdx, dwEventId, EMCUUserInvalid)
}

//15 MCS_CREATECONF_ACK
func parseCXXCBMsgCreateConfAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//会议控制台在MCU上创建一个会议成功应答，消息体：s8[DC_MAXLEN_ConfE164], 会议E164号
	pData := (S8)(SwigcptrS8(pMsgBody))
	confNameLen := DC_MAXLEN_ConfE164
	confName := string((*[0x7fffffff]byte)(unsafe.Pointer(pData.Swigcptr()))[:confNameLen])
	logger().Debug("MCUSDK MCS_CREATECONF_ACK:", confName)

	handleCBMsg(nMcuIdx, dwEventId, confName)
}

//16 MCS_CREATECONF_NACK
func parseCXXCBMsgCreateConfNAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//会议控制台在MCU上创建一个会议失败，消息体：DCTConfError
	pData := (DCTConfError)(SwigcptrDCTConfError(pMsgBody))
	pData.Print()
	logger().Debug("MCUSDK MCS_CREATECONF_NACK: ", pData.GetM_achConfE164(), pData.GetM_dwErrorCode())

	handleCBMsg(nMcuIdx, dwEventId, pData)
}

//17 MCS_RELEASECONF_ACK
func parseCXXCBMsgReleaseConfAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//MCU成功结束会议应答，消息体：s8[DC_MAXLEN_ConfE164],会议E164号
	pData := (S8)(SwigcptrS8(pMsgBody))
	confNameLen := DC_MAXLEN_ConfE164
	confName := string((*[0x7fffffff]byte)(unsafe.Pointer(pData.Swigcptr()))[:confNameLen])
	logger().Debug("MCUSDK MCS_RELEASECONF_ACK:", confName)

	handleCBMsg(nMcuIdx, dwEventId, confName)
}

//18 MCS_RELEASECONF_NACK
func parseCXXCBMsgReleaseConfNAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//MCU拒绝结束会议，消息体：DCTConfError
	pData := (DCTConfError)(SwigcptrDCTConfError(pMsgBody))
	pData.Print()
	logger().Debug("MCUSDK MCS_RELEASECONF_NACK: ", pData.GetM_achConfE164(), pData.GetM_dwErrorCode())

	handleCBMsg(nMcuIdx, dwEventId, pData)
}

//19 MCS_RELEASECONF_NOTIF
func parseCXXCBMsgReleaseConfNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//MCU结束会议通知，消息体：u8 类型（即时、模板、预约）+ s8 [MAXLEN_E164]会议E164
	logger().Debug("MCUSDK MCS_RELEASECONF_NOTIF, dwMsgLength=%d", dwMsgLength)
	sizeU8 := uintptr(1)
	pConfType := (S8)(SwigcptrS8(pMsgBody))
	pConfName := (S8)(SwigcptrS8(uintptr(pMsgBody) + sizeU8))
	confNameLen := MAXLEN_E164
	confName := string((*[0x7fffffff]byte)(unsafe.Pointer(pConfName.Swigcptr()))[:confNameLen])
	logger().Debug("MCUSDK MCS_RELEASECONF_NOTIF: ", pConfType, confName)

	handleCBMsg(nMcuIdx, dwEventId, confName)
}

//24 MCS_STARTVMP_ACK
func parseCXXCBMsgStartVmpAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//MCU同意画面合成请求，无消息体
	logger().Debug("MCUSDK MCS_STARTVMP_ACK, mcuIdx=", nMcuIdx)

	handleCBMsg(nMcuIdx, dwEventId)
}

//25 MCS_STARTVMP_NACK
func parseCXXCBMsgStartVmpNAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	logger().Debugf("MCUSDK MCS_STARTVMP_NACK, mcuIdx=%d, dwEventId=%d, pMsgBody=%d, dwMsgLength=%d",
		nMcuIdx, dwEventId, pMsgBody, dwMsgLength)
	//MCU不同意画面合成请求，消息体：错误号

	mcuErrCode := *(*uint16)(unsafe.Pointer(uintptr(pMsgBody)))
	logger().Debug("MCUSDK MCS_STARTVMP_NACK, mcuIdx=%d, sdkErrCode=%d", nMcuIdx, mcuErrCode)

	handleCBMsg(nMcuIdx, dwEventId, mcuErrCode)
}

//26 MCS_STARTVMP_NOTIF
func parseCXXCBMsgStartVmpNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//画面合成成功开始通知，无消息体
	logger().Debug("MCUSDK MCS_STARTVMP_NOTIF, mcuIdx=", nMcuIdx)
	handleCBMsg(nMcuIdx, dwEventId)
}

//27 MCS_STOPVMP_ACK
func parseCXXCBMsgStopVmpAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//MCU同意视频结束复合请求，无消息体
	logger().Debug("MCUSDK MCS_STOPVMP_ACK, mcuIdx=", nMcuIdx)
	handleCBMsg(nMcuIdx, dwEventId)
}

//28 MCS_STOPVMP_NACK
func parseCXXCBMsgStopVmpNAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//MCU不同意结束画面合成请求，消息体：错误号
	mcuErrCode := *(*uint16)(unsafe.Pointer(uintptr(pMsgBody)))
	logger().Debug("MCUSDK MCS_STOPVMP_NACK, mcuIdx=%d, sdkErrCode=%d", nMcuIdx, mcuErrCode)

	handleCBMsg(nMcuIdx, dwEventId, mcuErrCode)
}

//29 MCS_STOPVMP_NOTIF
func parseCXXCBMsgStopVmpNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//画面合成成功结束通知，消息体:s8[DC_MAXLEN_ConfE164]
	pData := (S8)(SwigcptrS8(pMsgBody))
	confNameLen := DC_MAXLEN_ConfE164
	confName := string((*[0x7fffffff]byte)(unsafe.Pointer(pData.Swigcptr()))[:confNameLen])
	logger().Debug("MCUSDK MCS_STOPVMP_NOTIF:", confName)

	handleCBMsg(nMcuIdx, dwEventId, confName)
}

//60 MCS_VMPPARAM_NOTIF
func parseCXXCBMsgVmpParamNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//画面合成器参数通知,消息体：DCTConfVmpStatus（会议画面合成状态）
	pData := (DCTConfVmpStatus)(SwigcptrDCTConfVmpStatus(pMsgBody))
	logger().Debugf("MCUSDK MCS_VMPPARAM_NOTIF: confE164=%s", pData.GetConfE164())
	handleCBMsg(nMcuIdx, dwEventId, pData)
}

//72 MCS_MIXPARAM_NOTIF
func parseCXXCBMsgMixParamNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//终端成功加入/退出混音组，消息体：DCTConfMixStatus(会议混音状态)
	pData := (DCTConfMixStatus)(SwigcptrDCTConfMixStatus(pMsgBody))
	logger().Debugf("MCUSDK MCS_MIXPARAM_NOTIF: confE164=%s", pData.GetConfE164())
	handleCBMsg(nMcuIdx, dwEventId, pData)
}

//114 MCS_CALLMT_ACK
func parseCXXCBMsgCallMTAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//呼叫终端成功，无消息体
	logger().Debugf("MCUSDK MCS_CALLMT_ACK")
	handleCBMsg(nMcuIdx, dwEventId)
}

//115 MCS_CALLMT_NACK
func parseCXXCBMsgCallMTNAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//呼叫终端失败，消息体：错误号
	mcuErrCode := *(*uint16)(unsafe.Pointer(uintptr(pMsgBody)))
	logger().Debug("MCUSDK MCS_CALLMT_NACK, mcuIdx=%d, sdkErrCode=%d", nMcuIdx, mcuErrCode)
	handleCBMsg(nMcuIdx, dwEventId, mcuErrCode)
}

//116 MCS_DROPMT_ACK
func parseCXXCBMsgDropMTAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//删除终端成功，无消息体    -- 挂断
	logger().Debugf("MCUSDK MCS_DROPMT_ACK")
	handleCBMsg(nMcuIdx, dwEventId)
}

//117 MCS_DROPMT_NACK
func parseCXXCBMsgDropMTNAck(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//删除终端失败,消息体：错误号 -- 挂断
	mcuErrCode := *(*uint16)(unsafe.Pointer(uintptr(pMsgBody)))
	logger().Debug("MCUSDK MCS_DROPMT_NACK, mcuIdx=%d, sdkErrCode=%d", nMcuIdx, mcuErrCode)
	handleCBMsg(nMcuIdx, dwEventId, mcuErrCode)
}

//118 MCS_CALLMT_FAILED_NOTIFY
func parseCXXCBMsgCallMTFailedNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//呼叫终端失败通知，消息体: DCTMtCallFailedReason
	pData := (DCTMtCallFailedReason)(SwigcptrDCTMtCallFailedReason(pMsgBody))
	logger().Debugf("MCUSDK MCS_CALLMT_FAILED_NOTIFY: confE164=%s mtInfo=%s",
		pData.GetM_achConfInfo(), pData.GetM_tMtInfo().GetM_achMtInfo())

	handleCBMsg(nMcuIdx, dwEventId, pData)
}

//137 MCS_MTONLINECHANGE_NOTIFY
func parseCXXCBMsgAddDelMTNty(dwEventId uint, pMsgBody uint, dwMsgLength uint, nMcuIdx uint) {
	//终端上下线通知，消息体: DCTMtOnlineInfo      -- 会议添加删除终端
	pData := (DCTMtOnlineInfo)(SwigcptrDCTMtOnlineInfo(pMsgBody))
	logger().Debugf("MCUSDK MCS_MTONLINECHANGE_NOTIFY: confE164=%s mtInfo=%s",
		pData.GetM_achConfInfo(), pData.GetM_tMtInfo().GetM_achMtInfo())
	handleCBMsg(nMcuIdx, dwEventId, pData)
}
