#SWIG CONVERT
swig -c++ -go -intgosize 64 -cgo mcusdk.i
if [ $? -ne 0 ]; then
    echo "convert failed"
    exit -1
fi
echo "convert ok"


#注释代码 
#未实现的接口 DcTconfBrdststatus::SetconfE164(char const*)
#mcusdk_wrap.cxx:9399

#cgo CXXFLAGS: -std=c++0x
#cgo CPPFLAGS: -Wno-unused-result -Wno-write-strings -Wno-attributes
#cgo CFLAGS:   -I${SRCDIR}/include/ -I${SRCDIR}/
#cgo LDFLAGS:  -L${SRCDIR}/lib/ubuntu_amd64/release/ -lmcsdll_64 -lkdvmedianet -lkdvlog -losp -lkprop -lpthread -lrt -Wl,-rpath,/msp/mpuaps/lib
sed -i '/#undef intgo/ a\#cgo LDFLAGS:  -L${SRCDIR}/lib/ubuntu_amd64/release/ -lmcsdll_64 -lkdvmedianet -lkdvlog -losp -lkprop -lpthread -lrt -Wl,-rpath,/msp/mpuaps/lib' mcusdk.go
sed -i '/#undef intgo/ a\#cgo CFLAGS:   -I${SRCDIR}/include/ -I${SRCDIR}/' mcusdk.go
sed -i '/#undef intgo/ a\#cgo CPPFLAGS: -Wno-unused-result -Wno-write-strings -Wno-attributes' mcusdk.go
sed -i '/#undef intgo/ a\#cgo CXXFLAGS: -std=c++0x' mcusdk.go
if [ $? -ne 0 ]; then
    echo "edit mcusdk.go err"
    exit -1
fi
echo "edit mcusdk.go ok"


#BUILD TEST
echo "test build start"
go mod init mcusdk
go build .
if [ $? -ne 0 ]; then
    rm go.mod
    echo "test build err"
    exit -1
fi
rm go.mod
echo "convert end"
